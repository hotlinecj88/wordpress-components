<?php 


/*
	TEMPLATE NAME: Casting Call Page
*/

get_header();


/**
*	@access ACCESS ONLY FOR THIS PAGE
*/

$page_cat = get_terms( array(
		'taxonomy'		=> 'category',
		'slug'			=> 'casting-call',
		'hide_empty'	=> true,
) );

function list_category_child( $tax = '' ){
	
	if( $tax == '' || empty( $tax ) ){
		return 0;
	}

	$id_parent = $tax[0]->term_id;

	if( empty( $id_parent ) ){
		return 0;
	}

	$loop_child = get_terms( array(
		'taxonomy'		=> 'category',
		'parent'			=> $id_parent,
		/**
			DEMO FEATURE 
		*/
		'hide_empty'	=> false
	) );


	if( empty( $loop_child ) ){
		return 0;
	}

	echo '
		<nav class="list-category-casting-call">
		<div class="nav nav-tabs" id="nav-tab" role="tablist">
	';

	

	// storage child loop
	$loop_sub_child = []; 

	foreach( $loop_child as $child_key => $child_val ){

		// >> display parent first 
		$slug 		= 'category-' . $child_val->slug;
		$child_id 	= $child_val->term_id;
		$name 		= $child_val->name;

		$loop_sub_child[$child_key] = [ 
			'slug' 	=> $slug, 
			'id'		=> $child_id 
		];

		// add class active		
		$active_html_btn = '';
		if( $child_key == 0 ){
			$active_html_btn = 'active';	
		}
		
 		?>
			<a class='nav-item nav-link <?php echo $active_html_btn; ?>' role='tab' href='#<?php echo $slug; ?>' data-toggle='tab' aria-selected="<?php echo $active_html_btn; ?>"> 
				<?php echo $name; ?> 
			</a>
		<?php

	}

	echo '
		</div>
		<div class="tab-content" id="nav-tabContent">
	';

	 $sub_child = [];

	// loop sub child
	for( $x = 0 ; $x < count( $loop_sub_child ) ; $x++ ){

		$lll = get_terms( array(
			'taxonomy'		=> 'category',
			'parent'			=> $loop_sub_child[$x]['id'],
			'hide_empty'	=> false
		) );

		$id_html_label = $loop_sub_child[$x]['slug'];
		
		?>
			<div class="tab-pane fade <?php echo ( $x == 0 ) ? 'show active' : ''; ?>" id="<?php echo $id_html_label; ?>" role="tabpanel" aria-labelledby="<?php echo $id_html_label; ?>">
				<?php 
					foreach( $lll as $lk => $vl ){
					
						$lll_slug = $loop_sub_child[$x]['slug'] . ' category-' . $vl->slug;


					?>

					<button class='<?php echo $lll_slug; ?> btn btn-primary'>
						<?php echo $vl->name; ?>
					</button>
						<?php
						
					}

				?>
			</div>
		<?php
	}


	echo '</div>';
	echo '</nav>';

}

 

/**
*	@access CHANGE POST QUERY
*/	

$args =  array(
	// 'numberposts'      => 5,
	'orderby'          => 'date',
	'order'            => 'DESC',
	'post_type'        => 'post',
	'category_name'	 => 'casting-call'
	// 'suppress_filters' => true
);

if( ! empty( $page_cat[0]->term_id ) ){
	$args['category']   = $page_cat[0]->term_id;
}else{
	// return query to normal
	$args['category']   = 0;
}


$column = 'col-12 col-md-6 col-xl-3 col-lg-4';

$isotope_selector = 'isotope-category-page-selector';

$data_isotope = '{ "itemSelector":".'.$isotope_selector.'","layoutMode":"masonry"}';

$class_post = $column . ' ' . $isotope_selector;

$the_post = new WP_Query( $args );

?>


<div class='page-category'>

	<div class='container'>
		<div class='row'>
			<div class='col-12 text-center'>
				<?php list_category_child( $page_cat );  ?>
			</div>
		</div>
	</div>


	<div class='container'>
		<div class='row' data-isotope='<?php echo $data_isotope; ?>'>
	<?php if( $the_post->have_posts() ){ while( $the_post->have_posts() ){ 
					$the_post->the_post(); 

			$post_format = get_post_format( get_the_ID()) ;

			$embed = ($post_format == 'video') ? get_the_content() : '';
			$id_embed = 'video-embed-light-gallery-'.get_the_ID();
		?>	

	<div class='<?php post_class($class_post); ?>'>
		<div class='entry-post entry-post-format-<?php echo $post_format; ?>'>

			<div id='<?php echo $id_embed; ?>' class='entry-thumbnail'>
					
				<?php 
				
				if($post_format == 'video'){ 
					$video_thumb = wp_get_attachment_image_url( get_post_thumbnail_id(get_the_ID()) ,'full');
					?>
					<a href='<?php echo esc_url($embed); ?>'>
						<img data-src='<?php echo $video_thumb; ?>' src='<?php echo $video_thumb; ?>'>
					</a>
				<?php }else{
					the_post_thumbnail('large');
				} 

				?>

			</div>

			<div class='entry-wrapper'>
				<div class='entry-title'>
					<a href='<?php echo the_permalink(); ?>'>
						<h2><?php the_title(); ?></h2>
					</a>
				</div>
			</div>

			<div class='entry-components'>
				<div class='entry-follow'>
					<?php 
						get_template_part('components/content/content','share');
					?> 
				</div>
			</div>

		</div>
	</div>

	<?php if( $post_format == 'video' ){ ?>
	<script type='text/javascript'>
	(function($){$(document).on('ready',function(){

		$('#<?php echo $id_embed;  ?>').lightGallery({
			thumbnail : true
		});

		});
	;})(jQuery);
	</script>
	<?php } ?>

	<script type='text/javascript'>
		(function($){$(document).on('ready',function(){
			// add Filter Category
				$('.isotope-category-page-selector').isotope({ 
					filter: '*,.category-year-2020' 
				});
			});
		})(jQuery);
	</script>

	<?php }
		wp_reset_postdata();
	}?>
			</div>
	</div>

	<div class='container'><div class='row'><div class='col-12 mx-auto'>
		<?php Helper::ahlu_pagination(); ?>
	</div></div></div>

</div>


<?php 

get_footer();
?>