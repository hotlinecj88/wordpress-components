<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset='utf-8'>
	<meta name='viewport' content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel='profile' href='http://gmpg.org/xfn/11'>
	<link rel='pingback' href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	
	<!-- EXTEND FONT GOOGLE -->
	<link href="https://fonts.googleapis.com/css?family=Crimson+Text:600,700&display=swap" rel="stylesheet" media='all'>

	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800&display=swap" rel="stylesheet" media='all'>

	<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.min.css'>

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?> >

<header id='header' class='<?php ColdFire::header_layout(); ?>'>
	<?php ColdFire::header_template_part(); ?>
</header>

<?php ColdFire::menu_mobile(); ?>


<?php  if( ! is_home() ){  ColdFire::header_banner(); } ?>

<div id='site' class='page'>

	
	