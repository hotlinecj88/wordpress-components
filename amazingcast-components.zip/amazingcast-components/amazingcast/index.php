<?php
get_header();

$template = current_template_name();

 if ( have_posts() ) :
	while ( have_posts() ) : the_post();
		get_template_part( 'components/content/content',$template);
      
	endwhile;
	wp_reset_postdata();
else :
	get_template_part( 'components/content/content-none');
endif;

get_footer();
?>
