<?php 
get_header();

/**
*	@access CALL SHORTCODE -> ahlu_portfolio
*/
?>

<div id='single-model' class='single-model'>
	<div class='container'>

			<?php
					
				if(have_posts()){
					while(have_posts()){
						the_post();the_content();
					}
					
				}else{
					get_template_part('components/content/content','none');
				}
			?>

	</div>
</div>
<?php
get_footer();
