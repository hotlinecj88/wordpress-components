<?php 
get_header();


$column_post = 'col-12 col-md-12 col-xl-10 mx-auto';

// $id_job 		= 185;
// job dang chay
$job_undone = 186;
// job da hoan thanh
$job_done   = 187;
// fix lai column thumbnail
?>
<div id='page-singular' class='page-singular'>
	<div class='container'>
		<div class='row'>

			
				<?php
						
				if(have_posts()){
					while(have_posts()){
						the_post(); ?>

					<div class='col-12 col-md-12 col-xl-10 mx-auto'>
						<div class='entry-thumbnail'><?php echo the_post_thumbnail('full'); ?></div>
					</div>
						
					<div class='<?php echo $column_post; ?>'>
						<div class='entry-title'><h1><?php the_title(); ?></h1></div>
						<div class='entry-content'><p><?php echo the_content(); ?></p></div>
					</div>
				<?php 
				}}else{
					get_template_part('components/content/content','none');}
				?>	

		</div>
		<div class='row'>
			<div class='<?php echo $column_post; ?>'>
			<div class='entry-meta'>
				<div class='entry-follow'>
				<?php get_template_part('components/content/content','share');
				?> 
				</div>

				<?php get_template_part('components/content/content-singular','category');
				?>
			</div>
			</div>
		</div>

		<div class='row'>
	
			<?php if($job_undone == $term_id){ ?>
				<div class='<?php echo $column_post; ?>'>
					<?php comments_template(); ?>
				</div>
			<?php } ?>

			<div class='<?php echo $column_post; ?>'>
				<div class='entry-navpost'>
					<?php ColdFire::nav_post(); ?>
				</div>
			</div>
		</div>


	</div>
</div>

<?php
get_footer();
