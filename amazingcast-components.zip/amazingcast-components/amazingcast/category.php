<?php 


get_header();

$column = 'col-12 col-md-6 col-xl-3 col-lg-4';

$isotope_selector = 'isotope-category-page-selector';

$data_isotope = '{ "itemSelector":".'.$isotope_selector.'","layoutMode":"masonry"}';

$class_post = $column . ' ' . $isotope_selector;


?>

<div class='page-category'>
	<div class='container'>
		<div class='row' data-isotope='<?php echo $data_isotope; ?>'>
	<?php if(have_posts()){ while(have_posts()){the_post(); 

			$post_format = get_post_format(get_the_ID());

			$embed = ($post_format == 'video') ? get_the_content() : '';
			$id_embed = 'video-embed-light-gallery-'.get_the_ID();
		?>	

	<div class='<?php post_class($class_post); ?>'>
		<div class='entry-post entry-post-format-<?php echo $post_format; ?>'>
			


			<div id='<?php echo $id_embed; ?>' class='entry-thumbnail'>
					
				<?php 
				
				if($post_format == 'video'){ 
					$video_thumb = wp_get_attachment_image_url( get_post_thumbnail_id(get_the_ID()) ,'full');
					?>
					<a href='<?php echo esc_url($embed); ?>'>
						<img data-src='<?php echo $video_thumb; ?>' src='<?php echo $video_thumb; ?>'>
					</a>
				<?php }else{
					the_post_thumbnail('large');
				} 

				?>

			</div>

			<div class='entry-wrapper'>
				<div class='entry-title'>
					<a href='<?php echo the_permalink(); ?>'>
						<h2><?php the_title(); ?></h2>
					</a>
				</div>
			</div>

			<div class='entry-components'>
				<div class='entry-follow'>
					<?php 
						get_template_part('components/content/content','share');
					?> 
				</div>
			</div>

		</div>
	</div>
	<?php if( $post_format == 'video' ){ ?>
	<script>
	(function($){$(document).on('ready',function(){

		
		$('#<?php echo $id_embed;  ?>').lightGallery({
			thumbnail : true
		});



		});
	;})(jQuery);
	</script>
	<?php } ?>

	<?php }}?>
			</div>
	</div>

	<div class='container'><div class='row'><div class='col-12 mx-auto'>
		<?php Helper::ahlu_pagination(); ?>
	</div></div></div>

</div>

<?php

get_footer();