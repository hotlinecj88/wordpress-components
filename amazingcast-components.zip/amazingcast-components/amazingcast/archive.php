<?php 

get_header();

get_posts(array(
'post_type' => 'model',
'order'     => 'DESC',
));
?>

<div class='page-archive'>
	<div class='container'>
	<div class='archive-container grid-isotope' data-isotope='{ "itemSelector": ".grid-item", "layoutMode": "fitRows" }'>
	<?php 
		// for($i = 0 ; $i <= 5; $i++){
		if(have_posts()){
			while(have_posts()){
				the_post();
				?>
					<a class='grid-item' href='<?php echo get_permalink(); ?>'>
						<div class='entry-model'>
							<div class='entry-thumbnail'>
								<?php the_post_thumbnail('large'); ?>
								<div class='entry-icon-link'>
									<i class="fas fa-link"></i>
									<div class='entry-icon-link-title'>
										<?php the_title(); ?>
											
										</div>
								</div>
							</div>
							<div class='entry-name'><?php the_title(); ?></div>
						</div>
					</a>
				
				<?php
			}
			// RESET POST TO NORMAL
			wp_reset_postdata();
		}else{
			get_template_part('components/content','none');
		}
	// }
	?>
	</div>
	</div>
	<div class='container'>
		<div class='row'>
			<div class='col-12 mx-auto'>
				<?php Helper::ahlu_pagination(); ?>
			</div>
		</div>
	</div>
</div>

<?php

get_footer();

?>