<div class='left'>

	<a href='<?php echo get_bloginfo('url'); ?>' class='navbar-brand header-logo'>
		<?php ColdFire::header_logo(); ?>
		<h1 class='header-logo-title'>
			<div class='logo-title'>Amazing</div>
			<div class='logo-tag-line'>Casting Agency</div>
		</h1>
	</a>
	
</div>

<div class='right'>

	<div class='menu-wrapper'>
		<?php ColdFire::header_menu(); ?>
	</div>
	
	<div class='header-components'>
		<div class='header-social'>
			<?php 
				$link_fb 		= CustomSetting::setting('social_fb');
				$link_tw 		= CustomSetting::setting('social_tw');
				$link_ins		= CustomSetting::setting('social_ins');
				$link_videmo	= CustomSetting::setting('social_vimeo');
				$link_youtube 	= CustomSetting::setting('social_utube');
				$link_feed 		= CustomSetting::setting('social_feed');

			?>

			<ul class='social-list'>
				<?php if(!empty($link_fb)){ ?>
				<li>
					<a href='<?php echo esc_url($link_fb); ?>'><i class='fa fa-facebook'></i></a>
				</li>
				<?php } ?>
				<?php if(!empty($link_tw)){?>
				<li>
					<a href='<?php echo esc_url($link_tw); ?><'><i class='fa fa-twitter'></i></a>
				</li>
				<?php } ?>
				<?php if(!empty($link_ins)){?>
				<li>
					<a href='<?php echo esc_url($link_ins); ?>'><i class='fa fa-instagram'></i></a>
				</li>
				<?php } ?>
				<?php if(!empty($link_vimeo)){?>
				<li>
					<a href='<?php echo esc_url($link_vimeo); ?>'><i class='fa fa-vimeo'></i></a>
				</li>
				<?php } ?>
				<?php if(!empty($link_youtube)){ ?>	
				<li>
					<a href='<?php echo esc_url($link_youtube); ?>'><i class='fa fa-youtube'></i></a>
				</li>
				<?php } ?>
				<?php if(!empty($link_feed)){ ?>
				<li>
					<a href='<?php echo esc_url($link_feed); ?>'><i class='fa fa-feed'></i></a>
				</li>
				<?php } ?>
				
				<li>
					<button type='button' class='form-popup-button'><i class='fa fa-search'></i></button>
				</li>
			</ul>
		</div>
	</div>
</div>