<?php 

/**
*	@access SHARE API

TWITTER 
https://twitter.com/intent/tweet?text= &url=

FACEBOOK
https://www.facebook.com/share.php?u=

GOOGLE
https://plus.google.com/share?url=

PINTEREST
https://pinterest.com/pin/create/button/?url= &media

LINKEDIN
http://www.linkedin.com/shareArticle?mini=true&url=&title=

disabled
<div class='entry-google'>
	<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class='fab fa-google'></i></a>
</div>

<div class='entry-pinterest'>
	<a href='https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php the_post_thumbnail('thumbnail'); ?>'><i class='fab fa-pinterest'></i></a>
</div>

<div class="zalo-share-button" data-href="" data-oaid="579745863508352884" data-layout="2" data-color="blue" data-customize=false></div>

*/

/**
* @var $url 
* @var $color
* @var $oaid
* @var $href
* @var $layout
* @var $customize
* @var $callback
* @var $id
* @var $domain
* @var $android
* @var $ios
*/



?>

<div class='entry-share'>
		
	<div class='entry-share-title'>Share on</div>

	<div class='entry-share-wrapper'>
		<div class='entry-link entry-twitter'>
			<a target='_blank' href="https://twitter.com/intent/tweet?text=<?php the_title(); ?>&url=<?php the_permalink(); ?>"><i class='fab fa-twitter'></i></a>
		</div>
		<div class='entry-link entry-facebook'>
			<a target='_blank' href="https://www.facebook.com/share.php?u=<?php the_permalink(); ?>"><i class='fab fa-facebook'></i></a>
		</div>
		<div class='entry-link entry-google'>
			<a target='_blank' href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class='fab fa-google'></i></a>
		</div>

		<div class='entry-link entry-linkedin'>
			<a target='_blank' href="http://www.linkedin.com/shareArticle?mini=true&url=<?php the_permalink(); ?>&title=<?php the_title(); ?>"><i class='fab fa-linkedin'></i></a>
		</div>

	</div>

</div>