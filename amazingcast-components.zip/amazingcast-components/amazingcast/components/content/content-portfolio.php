<div id='content-<?php the_ID(); ?>' class='content-wrapper content-portfolio '>
	<div class='entry-wrapper'>
		<div class='entry-thumbnail'>
			<?php echo the_post_thumbnail('post-grid'); ?>

			<div class='entry-category'>
				<?php 
					$terms = get_the_terms(get_the_ID(),'category-portfolio');
					if(!empty($terms)){
						foreach($terms as $k => $val){
						?>
							<span id='cat-<?php echo $val->term_id; ?>' class='cat-item cat-item-<?php echo $val->term_id; ?>'><?php echo $val->name; ?></span>
						<?php
						}
					}
				?>

			</div>
		</div>

		<?php get_template_part('components/content/content-meta'); ?>
		
		<div class='entry-details'>
			<div class='entry-title'>
				<a href='<?php echo get_permalink(); ?>'>
					<?php the_title(); ?>
				</a>
			</div>
			<div class='entry-content'>
				<?php the_content(); ?>
			</div>
		</div>
	</div>
</div>