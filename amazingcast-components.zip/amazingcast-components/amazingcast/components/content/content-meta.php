<div class="entry-meta">

	<span class="author">
		<span class='avatar'>
		<?php echo get_avatar(get_the_author_meta('ID'),30);?>
		</span>
	  	<a class='avatar-name' href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"
			 title="<?php the_author(); ?>"><?php $author = ucfirst(get_the_author_meta( 'user_nicename' ));echo esc_html($author); ?></a>
	</span>

</div>
