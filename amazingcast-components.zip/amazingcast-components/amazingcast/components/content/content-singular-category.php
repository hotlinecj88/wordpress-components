<?php 

	$job_undone = 186;
	$job_done   = 187;
	$term_id 	= 0;
	$term_name 	= '';

	if(has_term($job_undone,'category',get_the_ID())){
		$term_name = 'Job Đang Chạy';
		$term_id   = $job_undone;
		$term_class = 'job-undone';
	}

	if(has_term($job_done,'category',get_the_ID())){
		$term_name = 'Job Đã Hoàn Thành';
		$term_id   = $job_done;
		$term_class = 'job-done';
	}

	if(has_term($job_undone,'category',get_the_ID()) || 
		has_term($job_done,'category',get_the_ID()) ){
?>
<div class='entry-category'>
	<a class='<?php echo $term_class; ?>' href='<?php echo get_category_link($term_id); ?>'><?php echo $term_name; ?><i class='fas fa-long-arrow-alt-right'></i></a>
</div>
<?php } ?>