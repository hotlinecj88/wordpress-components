

<div class="entry-meta">
	<span class="author">
		<span class='avatar'>
		<?php echo get_avatar(get_the_author_meta('ID'),30);?>
		</span>
	  	<a class='avatar-name' href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"
			 title="<?php the_author(); ?>"><?php $author = ucfirst(get_the_author_meta( 'user_nicename' ));echo esc_html($author); ?></a>
	</span>

</div>

<div class='entry-category'>
<?php 
   $terms = get_the_terms(get_the_ID(),'category-portfolio');
   if(!empty($terms)){
      foreach($terms as $k => $val){
      ?>
      	<span id='cat-<?php echo $val->term_id; ?>' class='cat-item cat-item-<?php echo $val->term_id; ?>'>
      		<?php echo $val->name; ?>
      	</span>
      <?php
      }
   }
?>

</div>