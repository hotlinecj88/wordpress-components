<li class='portfolio-item grid-sizer'>
	<a id='post-<?php the_ID(); ?>' class='portfolio-item-box' href='<?php the_permalink(); ?>'>
		<?php the_post_thumbnail('post'); ?>

		<div class='entry-content'>
			<div class='entry-title'><?php the_title(); ?></div>

				<?php

					$terms = get_the_terms(get_the_ID(),'category-portfolio');
					
					if(!empty($terms)){

					echo "<div class='entry-category'>";

					foreach($terms as $k => $term){

					?>
						<span id='category-<?php echo $term->term_id; ?>' class='entry-category-item'><?php echo $term->name; ?></span>
					<?php 

					}

					echo '</div>';	

					}
				?>

		</div>
	</a>
</li>
