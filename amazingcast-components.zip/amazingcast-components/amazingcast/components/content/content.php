<div id='content-<?php the_ID(); ?>' class='content-wrapper'>
	<div class='entry-wrapper'>
		<div class='entry-thumbnail'>
			<?php echo the_post_thumbnail('full'); ?>
			<div class='entry-category'>
				<?php 
					$terms = get_the_category();
					if(!empty($terms)){
						foreach($terms as $k => $val){
						?>
							<span id='cat-<?php echo $val->term_id; ?>' class='cat-item cat-item-<?php echo $val->term_id; ?>'><?php echo $val->name; ?></span>
						<?php
						}
					}
				?>
			</div>
		</div>

		<?php get_template_part('components/content-meta'); ?>

		<div class='entry-title'>
			<a href='<?php echo get_permalink(); ?>'>
				<?php the_title(); ?>
			</a>
		</div>
		<div class='entry-content'>
			<?php the_content(); ?>
		</div>
	</div>
</div>