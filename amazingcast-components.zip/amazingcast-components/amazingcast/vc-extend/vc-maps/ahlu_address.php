<?php 

class WPBakeryShortCode_Ahlu_Address extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_address',
	'name'	=> 'Box Address Infomation',
	'description'	=> __('Hiển thị địa chỉ thông tin công ty',TEXTDOMAIN),
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01')	=> 'style-01',
			)
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Address',
			'param_name'	=> 'address'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Email',
			'param_name'	=> 'email'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Telephone',
			'param_name'	=> 'tel'
		)

	)
));