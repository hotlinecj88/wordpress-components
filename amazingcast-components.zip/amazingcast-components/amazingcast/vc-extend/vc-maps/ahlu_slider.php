<?php 



class WPBakeryShortCode_Ahlu_Slider extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'					=> 'ahlu_slider',
	'name'					=> 'Slider',
	'template_default'	=> true,
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Version',TEXTDOMAIN),
			'param_name'	=> 'version',
			'value'			=> array(
				'Carousel'				=> 'carousel',
				// 'Master Slider'		=> 'master_slider',
				'Slider Revolution'	=> 'slider_revolution'
			),
			'std'							=> 'carousel',
			'admin_label'				=> true
		),

		// optional => add style
		array(
			'type'			=> 'checkbox',
			'heading'		=> __('Add Style',TEXTDOMAIN),
			'param_name'	=> 'add_style',
			'default'		=> false,
			'dependency'	=> array('element' => 'version', 'value' => 'carousel')
		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
				'Style 03'	=> 'style-03',
				'Style Porfolio 01' => 'style-portfolio-01',
				'Style Porfolio 02' => 'style-portfolio-02',
			),
			'dependency'	=> 
				array('element' => 'add_style', 'value' => array('true'))
		),

		// active revolution slider
		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Revolution Slider',TEXTDOMAIN),
			'param_name'	=> 'rev_slider',
			'dependency'	=> array('element' => 'version','value' => 'slider_revolution'),
			'value'			=> Helper::get_rev_sliders(),
		),

		// active carousel slider normal
		Helper::get_param('carousel-control','version'),
		// param group
		array(
			'type'			=> 'param_group',
			'heading'		=> __('Carousel Item',TEXTDOMAIN),
			'param_name'	=> 'carousel_items',
			'dependency'	=> array('element' => 'version', 'value' => 'carousel'),
			'params'			=> array(

				array(
					'type'			=> 'attach_image',
					'heading'		=> __('Pick Image From Library',TEXTDOMAIN),
					'param_name'	=> 'image',
				),

				array(
					'type'			=> 'textfield',
					'heading'		=> __('Title',TEXTDOMAIN),
					'param_name'	=> 'title',
				),

				array(
					'type'			=> 'textarea',
					'heading'		=> __('Contents',TEXTDOMAIN),
					'param_name'	=> 'content'
				)

			)
		),

	)
));