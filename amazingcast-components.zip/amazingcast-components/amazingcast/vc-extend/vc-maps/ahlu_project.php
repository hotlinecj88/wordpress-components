<?php 

class WPBakeryShortCode_Ahlu_Project extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_project',
	'name'	=> 'Project - Box Dự Án - Portfolio',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01'	=> 'style-01'
			)
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Title - Tên Bài Viết',TEXTDOMAIN),
			'param_name'	=>	'title'
		),

		array(
			'type'			=> 'attach_image',
			'heading'		=> __('Picture Demo - Ảnh Demo',TEXTDOMAIN),
			'param_name'	=> 'picture_demo'
		),

		array(
			'type'			=> 'textarea_html',
			'heading'		=> __('Content - Nội Dung Bài Viết',TEXTDOMAIN),
			'param_name'	=> 'content'
		)

	)
));