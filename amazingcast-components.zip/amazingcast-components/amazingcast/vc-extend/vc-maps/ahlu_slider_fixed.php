<?php 

class WPBakeryShortCode_Ahlu_Slider_Fixed extends WPBakeryShortCode{}

ahlu_vcmap(array(

	'base'	=> 'ahlu_slider_fixed',
	'name'	=> 'Slider Fixed',
	'params'	=> array(

		array(
			'type'		=> 'dropdown',
			'heading'	=> __('Style',TEXTDOMAIN),
			'param_name'=> 'style',
			'value'		=> array(
				__('Style 01')	=> 'style-01',
				__('Style 02')	=> 'style-02',
			)
		),

		// images 
		array(
			'type'			=> 'attach_images',
			'heading'		=> __('Pick image from library'),
			'param_name'	=> 'images',
		),

	)
));