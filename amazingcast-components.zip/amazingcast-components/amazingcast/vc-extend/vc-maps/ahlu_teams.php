<?php 


class WPBakeryShortCode_Ahlu_Teams extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'		=> 'ahlu_teams',
	'name'		=> 'Team',
	'params'		=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01 '	=> 'style-01'
			),
			'std'				=> 'style-01'
		),

		array(
			'type'			=> 'attach_image',
			'heading'		=> __('Pick image from gallery',TEXTDOMAIN),
			'param_name'	=> 'image',
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Name',TEXTDOMAIN),
			'param_name'	=> 'name',
			'admin_label'	=> true
		)


	),
));
