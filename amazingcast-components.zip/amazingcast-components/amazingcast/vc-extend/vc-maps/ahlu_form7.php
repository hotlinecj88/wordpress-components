<?php 


class WPBakeryShortCode_Ahlu_Form7 extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_form7',
	'name'	=> 'Contact Form 7',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01',TEXTDOMAIN) => 'style-01',
				__('Style 02 - Become a Model',TEXTDOMAIN) => 'style-02',
			)

		),

		Helper::get_cf7_forms(),

	)
));