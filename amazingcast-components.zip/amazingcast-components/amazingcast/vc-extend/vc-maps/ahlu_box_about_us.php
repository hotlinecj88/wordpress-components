<?php 


class WPBakeryShortCode_Ahlu_Box_About_Us extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_box_about_us',
	'name'	=> 'Box About Us',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01')	=> 'style-01',
			)
		),

		// avatar
		array(
			'type'			=> 'attach_image',
			'heading'		=> __('Tải ảnh avatar',TEXTDOMAIN),
			'param_name'	=> 'avatar'
		),

		// name
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Nhập tên',TEXTDOMAIN),
			'param_name'	=> 'name'
		),


		//content
		array(
			'type'			=> 'textarea',
			'heading'		=> __('Nhập nội dung',TEXTDOMAIN),
			'param_name'	=> 'content'
		),
		

	)
));




