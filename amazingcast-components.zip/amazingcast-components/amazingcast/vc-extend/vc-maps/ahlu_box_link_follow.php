<?php 

class WPBakeryShortCode_Ahlu_Box_Link_Follow extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_box_link_follow',
	'name'	=> 'Box Link Follow',
	'params'	=> array(
		

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01',TEXTDOMAIN) => 'style-01',
			)
		),

		array(
			'type'			=> 'param_group',
			'heading'		=> __('Box Item',TEXTDOMAIN),
			'param_name'	=> 'items',
			'params'			=> array(

				array(
					'type'			=> 'textfield',
					'heading'		=>	__('Field',TEXTDOMAIN),
					'param_name'	=> 'field',
					'admin_label'	=> true
				),

				array(
					'type'			=> 'textfield',
					'heading'		=>	__('Value',TEXTDOMAIN),
					'param_name'	=> 'value',
					'admin_label'	=> true
				),
				
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Link Box',TEXTDOMAIN),
					'param_name'	=> 'link_value',
				)

			)
		)

	)
));