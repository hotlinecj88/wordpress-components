<?php 

/**
*	@access UPDATE -> SINGLE DATA
*/

class WPBakeryShortCode_Ahlu_Counter extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_counter',
	'name'	=> 'Counter',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01',TEXTDOMAIN)	=> 'style-01',
			)
		),


		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Type Data',TEXTDOMAIN),
			'param_name'	=> 'type_data',
			'value'			=> array(
				'Single'		=> 'single',
				'Multiple'	=> 'multiple'
			),
			'std'				=> 'single',
			'admin_label'	=> true
		),

		// TYPE SINGLE
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Label',TEXTDOMAIN),
			'param_name'	=> 'label',
			'dependency'	=> array(
				'element'	=> 'type_data' , 'value'	=> 'single'
			),
			'admin_label'	=> true
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Number',TEXTDOMAIN),
			'param_name'	=> 'number',
			'dependency'	=> array(
				'element'	=> 'type_data' , 'value'	=> 'single'
			),
			'admin_label'	=> true
		),


		// TYPE MULTIPLE
		array(
			'type'			=> 'param_group',
			'heading'		=> __('Items',TEXTDOMAIN),
			'param_name'	=> 'items',
			'dependency'	=> array(
				'element'	=> 'type_data' , 'value'	=> 'multiple'
			),
			'params'			=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Label',TEXTDOMAIN),
					'param_name'	=> 'label',
					'admin_label'	=> true
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Number',TEXTDOMAIN),
					'param_name'	=> 'number',
					'admin_label'	=> true
				)
			)
		)

	)
));




















