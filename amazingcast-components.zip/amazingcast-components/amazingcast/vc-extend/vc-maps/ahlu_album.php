<?php 

class WPBakeryShortCode_Ahlu_Album extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_album',
	'name'	=> 'Album - Photo - Gallery',
	'description'	=> 'Tạo Album Ảnh',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01')	=> 'style-01',
				__('Style 01')	=> 'style-01'
			)
		),

		array(
			'type'			=> 'attach_images',
			'heading'		=> __('Pick Image From Galleries',TEXTDOMAIN),
			'param_name'	=> 'albums'
		)

	)
));