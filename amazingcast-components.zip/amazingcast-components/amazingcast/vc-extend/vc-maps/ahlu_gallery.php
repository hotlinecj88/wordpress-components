<?php 


class WPBakeryShortCode_Ahlu_Gallery extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_gallery',
	'name'	=> 'Image Gallery',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style ',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01',TEXTDOMAIN)	=> 'style-01'
			),
			'admin_label'	=> true
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title - Nhập Tiêu Đề',
			'param_name'	=> 'title',
		),

		array(
			'type'			=> 'attach_images',
			'heading'		=> __('Pick image from galleries',TEXTDOMAIN),
			'param_name'	=> 'images'
		)

	)
));