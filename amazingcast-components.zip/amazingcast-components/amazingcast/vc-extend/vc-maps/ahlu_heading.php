<?php 

class WPBakeryShortCode_Ahlu_Heading extends WPBakeryShortCode{}


ahlu_vcmap(array(
	'name'	=> 'Heading',
	'base'	=> 'ahlu_heading',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'	=> array(
				__('No Style',TEXTDOMAIN)		  					=> 'no-style',
				__('Style 01 - Title Footer',TEXTDOMAIN) 		=> 'style-01',
				__('Style 02 - Title Brands',TEXTDOMAIN) 		=> 'style-02',
				__('Style 03 - Content Address',TEXTDOMAIN) 	=> 'style-03',
				__('Style 04 - Title For Page (Become a Model)',TEXTDOMAIN)						=> 'style-04',
				__('Style 05 - ',TEXTDOMAIN)	=> 'style-05',

			),
			'std'	=> 'no-style',
		),

		Helper::get_param('element_tag'),

		array(
			'type'			=> 'textarea',
			'heading'		=> __('Title',TEXTDOMAIN),
			'param_name'	=> 'title',
			'admin_label'	=> true
		),

		Helper::get_param('color'),
		Helper::get_param('font_size'),
		Helper::get_param('font_weight'),
		Helper::get_param('letter_spacing'),
		Helper::get_param('text_transform'),
		Helper::get_param('text_align'),
		Helper::get_param('opacity')
		// OPTIONS

	)

));