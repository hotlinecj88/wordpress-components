<?php 

class WPBakeryShortCode_Ahlu_Porfolio_Custom extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'name'			=> 'Portfolio Model Custom',
	'description'	=> __('Dữ liệu tạo thêm',TEXTDOMAIN),
	'base'			=> 'ahlu_portfolio_custom',
	'params'			=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array('Style 01 '	=> 'style-01'),
			'std'				=> 'style-01'
		),

		array(
			'type'			=> 'param_group',
			'heading'		=> __('Portfolio Details',TEXTDOMAIN),
			'param_name'	=> 'portfolio_details_custom',
			'params'			=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> __('Field',TEXTDOMAIN),
					'param_name'	=> 'field',
				),
				array(
					'type'			=> 'textfield',	
				)
			)

		)

	)
));