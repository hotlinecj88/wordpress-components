<?php 


class WPBakeryShortCode_Ahlu_Map extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_map',
	'name'	=> 'Map Location',
	'params'	=> array(

	)
));