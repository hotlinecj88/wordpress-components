<?php 


class WPBakeryShortCode_Ahlu_Social extends WPBakeryShortCode{}


ahlu_vcmap(array(
	'base'	=> 'ahlu_social',
	'name'	=> 'Social Network - Mạng Xã Hội',
	'params'	=> array(
		
		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'	=> array(
				__('Style 01',TEXTDOMAIN) 		=> 'style-01',
			)
		),

		// FACEBOOK 
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Facebook Link',TEXTDOMAIN),
			'param_name'	=> 'social_facebook'
		),
		// GOOGLE 
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Google+ Link',TEXTDOMAIN),
			'param_name'	=> 'social_google'
		),
		// YOUTUBE
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Youtube Link',TEXTDOMAIN),
			'param_name'	=> 'social_youtube'
		),
		// VIMEO
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Vimeo Link',TEXTDOMAIN),
			'param_name'	=> 'social_vimeo'
		),
		// INSTAGRAM
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Instagram Link',TEXTDOMAIN),
			'param_name'	=> 'social_instagram'
		),
		// LINKEDIN
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Linkedin Link',TEXTDOMAIN),
			'param_name'	=> 'social_linkedin'
		),
		// TWITTER
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Twitter Link',TEXTDOMAIN),
			'param_name'	=> 'social_twitter'
		),


	)
));