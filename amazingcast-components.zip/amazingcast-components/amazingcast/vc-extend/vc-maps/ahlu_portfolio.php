<?php 

/**
*	@var style
*	@var name_model
*	@var picture_primary
*	@var height
*	@var suit
*	@var chest
*	@var bust
*	@var waist
*	@var hips
*	@var hair
*	@var shoe
*	@var eyes
*
*/
class WPBakeryShortCode_Ahlu_Portfolio extends WPBakeryShortCode{}

ahlu_vcmap(array(

	'name'			=> 'Porfolio Model Detailt (Data - Fixed)',
	'description'	=> 'Dữ liệu cố định',
	'base'			=> 'ahlu_portfolio',
	'params'			=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01 '	=> 'style-01'
			),
			'std'				=> 'style-01'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Name Model',TEXTDOMAIN),
			'param_name'	=> 'name_model',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'attach_image',
			'heading'		=> __('Picture Primary - Ảnh Đại Diện',TEXTDOMAIN),
			'param_name'	=> 'picture_primary'
		),


		// PORTFOLIO DETAIL 

		/** TYPE DATA */
		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Type Data - Định Dạng Dữ Liệu Model',TEXTDOMAIN),
			'param_name'	=> 'type_data',
			'value'			=> array(
				'Women'	=> 'type_women',
				'Men'		=> 'type_men',
				'Kid'		=> 'type_kid'
			)
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Height - Chiều Cao',TEXTDOMAIN),
			'param_name'	=> 'height'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Dress - Size Đồng Phục (women)',TEXTDOMAIN),
			'param_name'	=> 'dress',
			'dependency'	=> array(
				'element'	=> 'type_data', 'value'	=> 'type_women'
			)
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Suit - Size Đồng Phục (men)',TEXTDOMAIN),
			'param_name'	=> 'suit',
			'dependency'	=> array(
				'element'	=> 'type_data','value'	=> 'type_men'
			)
		),

		// for men
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Chest - Ngực (men)',TEXTDOMAIN),
			'param_name'	=> 'chest',
			'dependency'	=> array(
				'element'	=> 'type_data', 'value'	=> 'type_men'
			)
		),

		// for women
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Bust - Ngực (women)',TEXTDOMAIN),
			'param_name'	=> 'bust',
			'dependency'	=> array(
				'element'	=> 'type_data', 'value'	=> 'type_women'
			)
		),

		// EO - USE BOTH 
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Waist - Eo',TEXTDOMAIN),
			'param_name'	=> 'waist',
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Hips - Mông (women)',TEXTDOMAIN),
			'param_name'	=> 'hips',
			'dependency'	=> array(
				'element'	=> 'type_data', 'value'	=> 'type_women'
			)
		),
		
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Shoe - Size Giầy',TEXTDOMAIN),
			'param_name'	=> 'shoe'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Hair - Màu Tóc',TEXTDOMAIN),
			'param_name'	=> 'hair'
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> __('Eyes - Màu Mắt',TEXTDOMAIN),
			'param_name'	=> 'eyes'
		)
	)
));