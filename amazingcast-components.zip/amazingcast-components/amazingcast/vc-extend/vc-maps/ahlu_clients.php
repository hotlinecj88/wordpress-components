<?php 


class WPBakeryShortCode_Ahlu_Clients extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'	=> 'ahlu_clients',
	'name'	=> 'Client Logo',
	'description'	=> __('Hiện thị thương hiệu khách hàng',TEXTDOMAIN),
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01',TEXTDOMAIN) => 'style-01',
			)

		),

		array(
			'type'			=> 'attach_images',
			'heading'		=> __('Pick image from gallery',TEXTDOMAIN),
			'param_name'	=> 'images'
		),

		
	)
));