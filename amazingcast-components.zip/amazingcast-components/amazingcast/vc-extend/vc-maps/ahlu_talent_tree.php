<?php 


class WPBakeryShortCode_Ahlu_Talent_Tree extends WPBakeryShortCode{}

ahlu_vcmap(array(
	'base'			=> 'ahlu_talent_tree',
	'name'			=> 'Telent Tree',
	'description'	=> __('Hiện thị thành tựu bằng nhánh cây',TEXTDOMAIN),
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01',TEXTDOMAIN) 	=> 'style-01',
			),
			'admin_label'	=> true
		),

		array(
			'type'			=> 'param_group',
			'heading'		=> __('Nhập Dữ Liệu Nhánh Cây',TEXTDOMAIN),
			'param_name'	=> 'items',
			'params'			=> array(

				array(
					'type'			=> 'textfield',
					'heading'		=> __('Field',TEXTDOMAIN),
					'param_name'	=> 'field',
					'admin_label'	=> true
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> __('Content',TEXTDOMAIN),
					'param_name'	=> 'content'
				)

			)
		)


	)
));