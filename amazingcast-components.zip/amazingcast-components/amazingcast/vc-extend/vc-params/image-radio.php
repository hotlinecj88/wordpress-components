<?php
/*
 * Example
	array(
		'type'       => 'image-radio',
		'heading'    => esc_html__( 'Style', 'miimo' ),
		'param_name' => 'style',
		'value'     => array(
				'style1' => array(
					'img' => 'https://abc.com/xyz.png',
					'title' => 'Style 1',
				),
				'style2' => 'https://abc.com/xyz.png',
				'style3' => array(
					'img' => 'https://abc.com/xyz.png',
					'title' => 'Style 3',
				),
			),
		)
*/
if ( ! class_exists( 'Insight_Param_Image_Radio' ) ) {

	class Insight_Param_Image_Radio {

		private $settings = array();

		private $value = '';

		/**
		 * @param $settings
		 * @param $value
		 */
		public function __construct( $settings, $value ) {
			$this->settings = $settings;
			$this->value    = $value;
		}

		public function render() {
			$param_name = isset( $this->settings['param_name'] ) ? $this->settings['param_name'] : '';
			$values     = isset( $this->settings['value'] ) ? $this->settings['value'] : '';

			$output = '<div class="image-radio">';
			foreach ( $values as $value => $label ) {
				if ( is_array( $label ) ) {
					$label = $label['img'];
				}
				$radio_id = uniqid( 'image-radio-' );
				$checked  = ( $value == $this->value ) ? 'checked="checked"' : '';
				$selected = ( $value == $this->value ) ? 'class="selected"' : '';
				//$param_class = ( $value == $this->value ) ? 'class="wpb_vc_param_value"' : '';

				$output .= '<input type="radio" name="rdimg-' . $param_name . '" id="' . $radio_id . '" ' . $checked . ' value="' . $value . '" data-target="#' . $param_name . '" />';
				$output .= '<label ' . $selected . ' for="' . $radio_id . '">';
				$output .= '<div><img src="' . esc_url( $label ) . '"/></div>';
				$output .= '</label>';
			}
			$output .= '<input type="hidden" name="' . $param_name . '" value="' . $this->value . '" class="wpb_vc_param_value" />';;
			$output .= '</div>';

			return $output;
		}
	}
}

if ( class_exists( 'Insight_Param_Image_Radio' ) ) {

	function ist_image_radio_settings_field( $settings, $value ) {

		$radio = new Insight_Param_Image_Radio( $settings, $value );

		return $radio->render();
	}

	WpbakeryShortcodeParams::addField( 'image-radio', 'ist_image_radio_settings_field', SEOPRO_URI . '/assets/admin/js/img_radio.js' );
}
