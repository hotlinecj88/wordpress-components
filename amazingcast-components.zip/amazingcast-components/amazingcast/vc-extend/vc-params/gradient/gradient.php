<?php
/*
 * Example
    array(
        'type'       => 'gradient',
		'param_name' => 'bg_gradient',
		'group'      => esc_html__( 'Gradient', 'miimo' ),
		'color1'     => 'rgba(238, 238, 238, 0.2)', // MUST BE IN rgb or rgba
		'color2'     => 'rgb(255, 255, 255)',
		'dependency' => array(
			'element'   => 'enable_gradient',
			'not_empty' => true,
		),
    ),
*/
if ( ! class_exists( 'Insight_Param_Gradient' ) ) {
	class Insight_Param_Gradient {

		public function __construct() {

			if ( class_exists( 'WpbakeryShortcodeParams' ) ) {
				WpbakeryShortcodeParams::addField( 'gradient', array(
					$this,
					'render'
				), SEOPRO_URI . '/vc-extend/vc-params/gradient/gradient.js' );
			}

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
		}

		function admin_scripts() {
			wp_enqueue_style( 'gradient', SEOPRO_URI . '/vc-extend/vc-params/gradient/gradient.css' );
			wp_enqueue_script( 'minicolors', SEOPRO_URI . '/vc-extend/vc-params/gradient/jquery.minicolors.min.js' );
			wp_enqueue_script( 'classygradient', SEOPRO_URI . '/vc-extend/vc-params/gradient/jquery.classygradient.min.js' );
		}


		/**
		 *
		 * @param $settings
		 * @param $value
		 *
		 * @return string
		 */
		public function render( $settings, $value ) {

			$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';
			$type       = $settings['type'];


			$color1 = isset( $settings['color1'] ) ? $settings['color1'] : '';
			$color2 = isset( $settings['color2'] ) ? $settings['color2'] : '';
			$class  = isset( $settings['class'] ) ? $settings['class'] : '';

			$id = uniqid();

			$output = '<div id="gradient-' . $id . '">';
			$output .= '<div class="tm_gradient_control" data-uniqid="' . $id . '" data-color1="' . $color1 . '" data-color2="' . $color2 . '">';

			$output .= '<div class="wpb_element_label" style="margin-top: 10px;">' . esc_html__( 'Orientation', 'miimo' ) . '</div>';
			$output .= '<select id="grad_type-' . $id . '" class="grad_type" data-uniqid="' . $id . '">
				<option value="vertical">' . esc_html__( 'Vertical', 'miimo' ) . '</option>
				<option value="horizontal">' . esc_html__( 'Horizontal', 'miimo' ) . '</option>
				<option value="custom">' . esc_html__( 'Custom', 'miimo' ) . '</option>
			</select>';

			$output .= '<div id="grad_type_custom_wrapper-' . $id . '" class="tm_number grad_type_custom_wrapper" style="display:none;">';
			$output .= '<input type="button" value="-" class="minus" />';
			$output .= '<input type="number" id="grad_type_custom-' . $id . '" placeholder="45" data-uniqid="' . $id . '" class="grad_custom" step="10"/>';
			$output .= '<input type="button" value="+" class="plus" />' . '<span>deg</span>';
			$output .= '</div>';

			$output .= '<div class="wpb_element_label" style="margin-top: 10px;">' . esc_html__( 'Choose Colors', 'miimo' ) . '</div>';
			$output .= '<div class="grad_hold" id="grad_hold-' . $id . '"></div>';
			$output .= '<div class="wpb_element_label" style="margin-top: 10px;">' . esc_html__( 'Preview', 'miimo' ) . '</div>';
			$output .= '<div class="grad_target" id="grad_target-' . $id . '"></div>';

			$output .= '<input type="hidden" id="grad_val-' . $id . '" class="wpb_vc_param_value ' . $param_name . ' ' . $type . ' ' . $class . ' vc_ug_gradient" name="' . $param_name . '"  value="' . $value . '"/></div>';
			$output .= '</div>';
			?>
            <script type="text/javascript">

				jQuery( function( $ ) {

					var $parent = jQuery( '#gradient-<?php echo esc_attr( $id ) ?>' );

					$parent.find( '.grad_type' ).change( function() {
						var id = $( this ).data( 'uniqid' );
						var $hold = $( '#grad_hold-' + id );
						var $val = $( '#grad_val-' + id );
						var $type_custom_wrapper = $( '#grad_type_custom_wrapper-' + id );
						var orientation = $( this ).children( 'option:selected' ).val();

						if ( 'custom' == orientation ) {
							$type_custom_wrapper.show();
						} else {
							$type_custom_wrapper.hide();

							if ( orientation == 'vertical' ) {
								var ori = 'top';
							} else {
								var ori = 'left';
							}

							$hold.data( 'ClassyGradient' ).setOrientation( ori );
							$val.val( $hold.data( 'ClassyGradient' ).getCSS() );
						}
					} );

					// custom degree
					$parent.find( '.grad_custom' ).on( 'change keyup', function() {
						var id = $( this ).data( 'uniqid' );
						var $hold = $( '#grad_hold-' + id );
						var $val = $( "#grad_val-" + id );
						var orientation = $( this ).val() + 'deg';

						$hold.data( 'ClassyGradient' ).setOrientation( orientation );
						$val.val( $hold.data( 'ClassyGradient' ).getCSS() );
					} );

					$parent.find( '.tm_gradient_control' ).each( function() {
						var id = $( this ).data( 'uniqid' );
						var $hold = $( '#grad_hold-' + id );
						var $val = $( '#grad_val-' + id );
						var $type = $( '#grad_type-' + id );
						var $type_custom = $( '#grad_type_custom-' + id );
						var $type_custom_wrapper = $( '#grad_type_custom_wrapper-' + id );

						var target = '#grad_target-' + id;

						var orientation = $type.children( 'option:selected' ).val();
						var prev_color = $val.val();
						var is_custom = false;

						if ( prev_color ) {
							if ( prev_color.indexOf( '-webkit-linear-gradient(top,' ) != - 1 ) {

								var p_l = prev_color.indexOf( '-webkit-linear-gradient(top,' );

								prev_color = prev_color.substring( p_l + 28 );
								p_l = prev_color.indexOf( ');' );
								prev_color = prev_color.substring( 0, p_l );
								orientation = 'vertical';

							} else if ( prev_color.indexOf( '-webkit-linear-gradient(left,' ) != - 1 ) {

								var p_l = prev_color.indexOf( '-webkit-linear-gradient(left,' );

								prev_color = prev_color.substring( p_l + 29 );
								p_l = prev_color.indexOf( ');' );
								prev_color = prev_color.substring( 0, p_l );
								orientation = 'horizontal';

							} else {

								var subStr = prev_color.match( "-webkit-linear-gradient((.*));background: -o" );
								var prev_color = subStr[1].replace( /-webkit-linear-gradient\(g/, '' ).substr( 1, subStr[1].length - 2 )
								var temp_col = prev_color;
								var t_l = temp_col.indexOf( 'deg' );
								var deg = temp_col.substring( 0, t_l );

								prev_color = prev_color.substring( t_l + 4, prev_color.length );

								$type_custom.val( deg );
								$type_custom_wrapper.show();
								orientation = 'custom';
								is_custom = true;
							}
						} else {
							var color1 = $( this ).data( 'color1' );
							var color2 = $( this ).data( 'color2' );

							if ( color1 && color2 ) {
								prev_color = color1 + ' 0%,' + color2 + ' 100%';
							} else {
								prev_color = 'rgb(238, 238, 238) 0%,rgb(255, 255, 255) 100%';
							}
						}

						$type.children( 'option' ).each( function( i, opt ) {
							if ( opt.value == orientation ) {
								$( this ).attr( 'selected', true );
							}

						} );

						if ( is_custom == true ) {
							orientation = deg + 'deg';
						}
						else {
							if ( orientation == 'vertical' ) {
								orientation = 'top';
							} else {
								orientation = 'left';
							}
						}

						$hold.ClassyGradient( {
							width: 350,
							height: 30,
							orientation: orientation,
							target: target,
							gradient: prev_color,
							onChange: function( stringGradient, cssGradient ) {
								cssGradient = cssGradient.replace( 'url(data:image/svg+xml;base64,', '' );

								var e_pos = cssGradient.indexOf( ';' );
								cssGradient = cssGradient.substring( e_pos + 1 );

								if ( $val.parents( '.wpb_el_type_gradient' ).css( 'display' ) == 'none' ) {
									cssGradient = '';
								}
								$val.val( cssGradient );
							}
						} )
					} );

				} );

            </script>
			<?php
			return $output;
		}

	}
}

if ( class_exists( 'Insight_Param_Gradient' ) ) {
	new Insight_Param_Gradient();
}
