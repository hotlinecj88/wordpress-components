<?php 

/**
*	@access ACCESS ONLY FOR SINGLE PORTFOLIO 
*/

if(is_single()){

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? $style : 'style-01';

$albums = (!empty($albums) && isset($albums)) ? explode(',',$albums) : null;
$elclass .= $style;


$id_albums = uniqid('album-');

?>



<div class='ahlu-albums <?php echo esc_attr($elclass); ?>'>
	<div class='row' id='<?php echo $id_albums; ?>' itemscope itemtype="http://schema.org/ImageGallery">
		<?php 
			foreach($albums as $k => $img){
			$image_attributes = wp_get_attachment_image_src( $img ,'full');
			$img_src 	= $image_attributes[0];
			$img_width 	= $image_attributes[1];
			$img_height = $image_attributes[2];
			$data_size  = $img_width .'x' . $img_height;
		?>
		<div class='col-12 col-xl-4 col-lg-4 col-md-6'>
			<figure itemprop='associatedMedia' itemscope itemtype='http://schema.org/ImageObject'>
				<a href='<?php echo $img_src; ?>' itemprop='contentUrl' data-size='<?php echo $data_size; ?>'>
					<img src='<?php echo $img_src; ?>' itemprop='thumbnail' alt='AmazingCast Model'>
				</a>
				<figcaption itemprop='caption description'>AmazingCast Model</figcaption>
			</figure>
		</div>
		<?php 
			}
		?>
 	</div>
</div>

<script type='text/javascript'>
	

// execute above function
__PhotoSwipe('#<?php echo $id_albums; ?>');

</script>


<?php } ?>