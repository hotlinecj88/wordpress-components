<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';

$elclass .= $style;

// $items = isset($items) ? vc_param_group_parse_atts( $items ) : '';


$address = isset($address) ? $address 	: '';
$email 	= isset($email)	? $email 	: '';
$tel		= isset($tel)		? $tel 		: '';
?>

<div class='ahlu-address <?php echo esc_attr($elclass); ?>'>
	<p><?php echo $address; ?></p>
	<div class='email'>
		<span>Email </span>
		<a href='mail:<?php echo $email; ?>'><?php echo $email; ?></a>
	</div>
	<div class='tel'>
		<span>Tel</span>
		<a href='tel:<?php echo $tel; ?>'><?php echo $tel;	 ?></a>
	</div>
</div>