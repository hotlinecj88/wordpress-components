<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';
$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$socials = array();

?>

<div class='ahlu-social <?php echo esc_attr($elclass); ?>'>
	<?php 
		// facebook
		if(isset($social_facebook) && !empty($social_facebook) ){
			?>
			<a class='hint--top' aria-label='Facebook' href='<?php echo esc_url($social_facebook); ?>'><i class='fa fa-facebook'></i></a>
			<?php
		}
		// google
		if(isset($social_google) && !empty($social_google) ){
			?>
			<a class='hint--top' aria-label='Google' href='<?php echo esc_url($social_google); ?>' ><i class='fa fa-google'></i></a>
			<?php
		}
		// instagram
		if(isset($social_instagram) && !empty($social_instagram) ){
			?>
			<a class='hint--top' aria-label='Instagram' href='<?php echo esc_url($instagram); ?>'><i class='fa fa-instagram'></i></a>
			<?php
		}
		// twitter
		if(isset($social_twitter) && !empty($social_twitter) ){
			?>
			<a class='hint--top' aria-label='Twitter' href='<?php echo esc_url($social_twitter); ?>'><i class='fa fa-twitter'></i></a>
			<?php
		}
		// linkedin
		if(isset($social_linkedin) && !empty($social_linkedin) ){
			?>
			<a class='hint--top' aria-label='Linkedin' href='<?php echo esc_url($social_linkedin); ?>'><i class='fa fa-linkined'></i></a>
			<?php
		}
		// vimeo
		if(isset($social_vimeo) && !empty($social_vimeo) ){
			?>
			<a class='hint--top' aria-label='Vimeo' href='<?php echo esc_url($social_vimeo); ?>'><i class='fa fa-vimeo'></i></a>
			<?php
		}
	?>	
</div>
