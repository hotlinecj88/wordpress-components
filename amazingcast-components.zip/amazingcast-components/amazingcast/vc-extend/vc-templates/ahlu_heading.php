<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style = isset($style) ? ' '.$style : ' no-style ';
$title = isset($title) ? $title : '';

$font_size = isset($font_size) ? ' '.$font_size : '';
$line_height = isset($line_height) ? $line_height : '';

$font_weight = isset($font_weight) ? ' '.$font_weight : '';
$text_tran = isset($text_transform) ? ' '.$text_transform : '';
$letter = isset($letter_spacing) ? $letter_spacing : '';
$text_align = isset($text_align) ? ' '.$text_align : '';
$color = isset($color) ? ' '.$color : ' color-black ';

// SUPPORT OPACITY
$opacity = isset($opacity) ? ' '.$opacity : ' no-opacity ';

$script_css = $custom_css = '';

$element_tag = isset($element_tag) ? $element_tag : 'h1';

if($element_tag != null && !empty($element_tag)){
	$context = '<' . $element_tag . '>' . $title . '</' . $element_tag . '>';
}else{
	$context = $title;
}

$heading_id = uniqid('vc_custom_css_heading_');

// export letter spacing
if(!empty($letter) && is_numeric($letter) && $letter > 0){	
	$script_css .= 'letter-spacing:'.$letter.'px!important;';
}else{
	$custom_css = '';
}
// export line height
if(!empty($line_height) && is_numeric($line_height) && $line_height > 0){
	$script_css .= 'line-height:'.$line_height.'px!important;';
}

/**
*	@access NOTE -> FIX ADD CSS 
*/
if( (isset($line_height) && !empty($line_height) ) || (isset($letter) && !empty($letter) )){
	$custom_css = '<style type="text/css">.'.$heading_id.'{'.$script_css.'}</style>';
}else{
	$custom_css = '';
}


echo $custom_css;


$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $font_size . $font_weight . $text_tran . $text_align . $color . $opacity . $animation . ' '.$heading_id;
?>


<div class='heading <?php echo esc_attr($elclass); ?>'>
	<?php echo $context;?>
</div>


