<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$version = isset($version) ? $version : '';

$id_carousel = uniqid('carousel-');

$add_style 			= isset($add_style) ? $add_style : false;
$style 				= isset($style) ? $style : 'style-01';

$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

if($add_style == true){
	$elclass .=  $style;
}

$elclass .= $animation;

// carousel
if($version == 'carousel'){
	/**
	*	@var $carousel_item [image - title - content]
	*	@var $carousel_control array()
	*	@var $add_style bool [true - false]
	*	@var $style
	*/

	$carousel_control = isset($carousel_control) ? Helper::get_carousel_control($carousel_control) : '';

	$carousel_items = isset($carousel_items) ? (array)vc_param_group_parse_atts($carousel_items) :'';


		if(!empty($carousel_items)){
	?>
		<div class='ahlu-slider carousel-slider <?php echo esc_attr($elclass); ?>'>
			<div id='<?php echo esc_attr($id_carousel); ?>' class=''>
				<?php foreach($carousel_items as $k => $item){ 
						$title 	= $item['title'];
						$content = $item['content'];
						$img 		= $item['image'];
				?>
				<div class='carousel-item'>
					<div class='item-image'>
						<?php echo wp_get_attachment_image($img,'full'); ?>
					</div>
					<div class='item-title'>
						<?php echo esc_html($title); ?></div>
					<div class='item-content'>
						<?php echo esc_html($content); ?></div>
				</div>
				<?php } ?>
			</div>
		</div>
	<?php
	get_carousel($id_carousel,$carousel_control);
		}
}

// slider revolution

if($version == 'slider_revolution'){
	/**
	*	@var id slider	
	*	@var do_shortcode
	*/
	$rev_slider = isset($rev_slider) ? $rev_slider : '';

	$shortcode = '[rev_slider alias="'.esc_html($rev_slider).'"]';
	?>
		<div class='ahlu-slider rev-slider <?php echo esc_attr($elclass); ?>'>
			<?php echo do_shortcode($shortcode); ?>
		</div>
	<?php
}


?>
