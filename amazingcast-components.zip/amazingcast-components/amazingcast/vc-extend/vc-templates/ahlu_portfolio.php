<?php 
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );
$elclass = $this->getExtraClass( $el_class );

$style = isset($style) ? ' '.$style : ' style-01 ';

$elclass .= $style;

$picture_primary = isset($picture_primary) ? $picture_primary : '';

$name_model = isset($name_model) ? $name_model : '';

$data = array();

$type_data = isset($type_data) ? ' '.$type_data : 'no-data-type';

$height	= (!empty($height) && isset($height)) 	
? $data['height'] = $height 	: '';
$suit   	= (!empty($suit) && isset($suit)) 	
? $data['suit'] 	= $suit 		: '';
$chest	= (!empty($chest) && isset($chest)) 	
? $data['chest'] 	= $chest 	: '';
$bust	  	= (!empty($bust) && isset($bust)) 	
? $data['bust'] = $bust		: '';
$waist	= (!empty($waist) && isset($waist)) 	
? $data['waist'] = $waist 	: '';
$hips		= (!empty($hips) && isset($hips)) 	
? $data['hips'] =  $hips		: '';
$shoe 	= (!empty($shoe) && isset($shoe)) 	
? $data['shoe'] =  $shoe 		: '';
$hair 	= (!empty($hair) && isset($hair)) 	
? $data['hair'] =  $hair 		: '';
$eyes		= (!empty($eyes) && isset($eyes)) 	
? $data['eyes'] =  $eyes 		: '';

$elclass .= $type_data;


/**
*	@access BUILD 2 STYLE
*/


?>

<div class='ahlu-portfolio <?php echo esc_attr($elclass); ?>'>
	
	<?php 
		/**
		*	@access FOR SINGLE PAGE
		*/
		if(is_single()){

			?>
			<div class='ahlu-portfolio-single'>
				<div class='container'>
					<div class='row'>

					<div class='col-left col-md-12 col-lg-6'>
							
						<div class='model-box-wrapper'>

							<div class='model-name'>
								<p><?php echo esc_html($name_model); ?></p>
							</div>
							<div class='model-portfolio-details'>
								<ul>
									<?php foreach($data as $k => $val){ ?>
										<li>
											<span class='field'><?php echo $k; ?></span>
											<span class='value'><?php echo $val; ?></span>
										</li>
									<?php } ?>
								</ul>
							</div>
						<!-- 	<div class='model-box-function'>
								<a href="#"> << Back</a>
								<a href="#">WishList</a>
							</div> -->
						</div>

						

					</div>

					<div class='col-right col-md-12 col-lg-6'>
						<div class='picture-primary'>
							<?php echo wp_get_attachment_image($picture_primary,'full
							'); ?>
						</div>
					</div>

					</div>
				</div>
			</div>


			<?php
		}


		/**
		*	@access FOR ARCHIVE PAGE
		*/
		if(is_archive()){
			$image_link = wp_get_attachment_image_url($picture_primary,'full');
			?>

				<div class='ahlu-portfolio-archive' style='background-image:url("<?php echo $image_link; ?>");'>
					<div class='model-portfolio-details'>
					<ul>
						<?php foreach($data as $k => $val){ ?>
							<li>
								<span class='field'><?php echo $k; ?></span>
								<span class='value'><?php echo $val; ?></span>
							</li>
						<?php } ?>
					</ul>
					</div>

					<div class='model-name'>
						<p><?php echo esc_html($name_model); ?></p>
					</div>

				</div>
			<?php

		}
	?>

</div>


