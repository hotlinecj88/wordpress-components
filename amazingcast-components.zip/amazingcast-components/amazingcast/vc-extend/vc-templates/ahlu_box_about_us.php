<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';

$avatar 	= isset($avatar) ? $avatar : '';
$name 	= isset($name)	? $name : '';
$content = isset($content) ? $content : '';

$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;
?>

<div class='ahlu-box-about-us <?php echo esc_attr($elclass); ?>'>
		
	<div class='avatar'>
		<?php echo wp_get_attachment_image($avatar,'full'); ?>
	</div>
	<div class='name'>
		<?php echo $name; ?>
	</div>
	<div class='content'>
		<p><?php echo $content; ?></p>
	</div>

</div>