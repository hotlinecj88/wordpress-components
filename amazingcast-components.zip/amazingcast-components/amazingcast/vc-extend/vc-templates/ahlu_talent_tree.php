<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';

$items = isset($items) ? vc_param_group_parse_atts($items) : '';

$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;
?>

<div class='ahlu-talent-tree <?php echo esc_attr($elclass); ?>'>
	<ul>
		<?php
			if(!empty($items)) foreach($items as $k => $val){
		?>
			<li>
				<span class='field'><?php echo $val['field']; ?></span>
				<span class='content'><p><?php echo $val['content']; ?></p></span>
			</li>
		<?php 
			}
		?>
	</ul>
</div>