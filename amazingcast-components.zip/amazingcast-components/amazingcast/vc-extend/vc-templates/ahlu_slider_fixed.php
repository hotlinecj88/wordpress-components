<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$style = isset($style) ? $style : ' style-01 ';

$el_class .= $style;

$images = isset($images) ? explode(',',$images) : '';
$id_carousel = uniqid('id_carousel');
?>

<div class='ahlu-slider-fixed <?php echo esc_attr($el_class); ?>'>
	<div class='overlay'></div>
	<div id='<?php echo $id_carousel; ?>' class='carousel slide carousel-fade' data-ride='carousel'>
		<div class='carousel-inner'>
			<?php if(!empty($images))foreach($images as $k => $image){ ?>
					<div class='carousel-item <?php echo $k == 1	 ? "active" : ""; ?>'>
						<img class='d-block w-100' src='<?php echo wp_get_attachment_image_url($image,"full"); ?>'>
					</div>
			<?php } ?>
		</div>
	</div>
</div>

<script>
	(function($){
		$(document).ready(function(){
			$('#<?php echo $id_carousel; ?>').carousel();
		});
	});
</script>
<?php ?>