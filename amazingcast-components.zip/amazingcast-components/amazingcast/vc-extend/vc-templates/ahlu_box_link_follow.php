<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';

$elclass .= $style;

$items = isset($items) ? vc_param_group_parse_atts( $items ) : '';

?>

<div class='ahlu-box-link-follow <?php echo esc_attr($elclass); ?>'>
	
	<?php foreach($items as $k => $item){ 
		$field = $item['field'];
		$value = $item['value'];
		$link  = $item['link_value'];

		?>
		<div class='item'>
			<span class='field'><?php echo $field; ?></span>
			<a href='<?php echo !empty($link) ? $link : "#"; ?>' class='value'>
				<?php echo $value; ?>
			</a>
		</div>
	<?php } ?>
</div>