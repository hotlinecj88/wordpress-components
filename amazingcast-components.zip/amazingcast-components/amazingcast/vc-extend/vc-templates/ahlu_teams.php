<?php 
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? $style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$image 	= isset($image) ? $image : '';

$name 	= isset($name)  ? $name : '';
?>

<div class='ahlu-team <?php echo esc_attr($elclass); ?>'>

	<div class='image'>
		<?php echo wp_get_attachment_image($image, 'full'); ?>
	</div>

	<div class='name'>
		<?php echo esc_html($name); ?>
	</div>

</div>