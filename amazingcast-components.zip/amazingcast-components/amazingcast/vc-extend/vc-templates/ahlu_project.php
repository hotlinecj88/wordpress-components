<?php 
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$title = isset($title) ? $title : '';
$content = isset($content) ? $content : '';
$picture = isset($picture_demo) ? $picture_demo : '';

?>

<div class='ahlu-project <?php echo esc_attr($elclass); ?>'>
	<div class='picture'>
		<?php echo wp_get_attachment_image($picture,'full'); ?>
	</div>
	<div class='title'>
		<?php echo $title; ?>
	</div>
	<div class='content'>
		<?php echo $content; ?>
	</div>
</div>