<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';

$type_data = isset($type_data) ? $type_data : 'single';

$id_counter = uniqid('id-counter-');

$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

$elclass .= $style . ' '.$type_data . $animation;
?>

<div class='ahlu-counter <?php echo esc_attr($elclass); ?>'>
   
   <div id='<?php echo $id_counter ?>'>

   <?php 
   // DISPLAY DATA MULTIPLE
   if($type_data == 'multiple'){ 
      $items = isset($items) ? vc_param_group_parse_atts( $items ) : '';
      ?>
   
      <div class='counter-body'>
      <?php if($items) foreach($items as $k => $val){?>
         <div class='counter-wrapper'>
            <div class='counter-value'><?php echo $val['number']; ?></div>
            <div class='counter-label'><?php echo $val['label']; ?></div>
         </div>
      <?php } ?>
      </div>

   <?php } 
   // DISPLAY DATA SINGLE
   if($type_data == 'single'){
   $label = isset($label) ? $label : '';
   $number = isset($number) ? $number : '';
   ?>
   
      <div class='counter-body'>
         <div class='counter-wrapper'>
            <div class='counter-value'><?php echo $number; ?></div>
            <div class='counter-label'><?php echo $label; ?></div>
         </div>
      </div>
   
   <?php } ?>

   </div>

</div>

<?php 

// <script type='text/javascript'>
//    (function($){
//       $(document).ready(function() {
//          $('#id_counter.counter-value').counterUp({
//             delay: 12,time: 3500
//          });
//       });
//    })(jQuery);
// </script>

?>