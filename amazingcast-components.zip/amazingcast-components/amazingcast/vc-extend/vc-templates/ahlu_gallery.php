<?php 

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );
$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? Helper::add_animation($css_aniamtion) : '';

$elclass .= $style . $animation;

$title = isset($title) ? $title : '';

$images = isset($images) ? explode(',',$images) : '';

?>

<div class='ahlu-gallery <?php echo esc_attr($elclass); ?>'>
	<?php if(!empty($title)){ ?>
		<div class='title'><?php echo esc_html($title); ?></div>
	<?php } ?>
	<div class='gallery-group grid-isotope' data-isotope='{ "itemSelector": ".grid-image", "layoutMode": "masonry" }'>
	<?php 
		if(!empty($images)) foreach($images as $k => $val){
	?>
	<div class='col-12 col-md-6 col-xl-3 col-lg-3 grid-image'>
		<?php echo wp_get_attachment_image($val , 'full'); ?>
	</div>

	<?php } ?>
	</div>

</div>