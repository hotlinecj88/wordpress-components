<?php

$page_layout = CustomSetting::setting('page_layout');
$page_wide   = CustomSetting::setting('page_wide');

get_header();


$class_container = $page_wide == 1 ? 'container_fluid' : 'container';


$class_inner_page_wrapper = $page_layout == 'no-sidebar' ? 'col-12' : 'col-9';
?>


<div class='page-content <?php echo esc_attr($class_container); ?>'>

	<?php
	// SIDEBAR - CONTENT
		if($page_layout == 'sidebar-content'){get_sidebar();}
	?>

	<?php
		if(have_posts()){
			while(have_posts()){
				the_post();
				?>
				<div id='page-<?php the_ID(); ?>' class='page-wrapper row'>
					<div class='page-content-inner <?php echo $class_inner_page_wrapper; ?>'>
						<?php the_content(); ?>
					</div>
				</div>
				<?php
			}
			// RESET POST
			wp_reset_postdata();
		}
	?>

	<?php
	// SIDEBAR - CONTENT
		if($page_layout == 'content-sidebar'){get_sidebar();}
	?>

</div>


<?php
	get_footer();
?>
