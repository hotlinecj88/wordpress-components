<?php

defined( 'ABSPATH' ) || exit;


/**
*	@access HELPER CLASS
*	@author Ahlu Team
*	@version 1
*/

class Helper {
	


	/**
	*	@access GET ALL LAYOUT FOOTER 
	*/

	public static function get_footer_layout(){
        global $wpdb;
        $query = "SELECT ID,post_title,post_name FROM wp_posts WHERE post_type='footer' AND post_status='publish';";
        $layout = $wpdb->get_results($query);

	    if(count($layout) > 0){
	        $storage = array();
	        // BUILD LEVEL 1
	        $storage['none']    = __('None',TEXTDOMAIN);
	        foreach($layout as $key => $val){
	            $storage[$val->ID] = __($val->post_title,TEXTDOMAIN);
	        }
	        return $storage;
	    }else{
	        return false;
	    }

    }

	public static function get_all_menus() {
		$args          = array(
			'hide_empty' => true,
			'fields'     => 'id=>name',
			'slug'       => '',
		);
		// $menus['']     = __('Default',TEXTDOMAIN);
		$menus         = get_terms( 'nav_menu', $args );

		return $menus;
	}



	public static function get_registered_sidebars( $default_option = false ) {
		global $wp_registered_sidebars;
		$sidebars = array();

		if ( $default_option === true ) {
			$sidebars['default'] = __( 'Primary Sidebar', TEXTDOMAIN );
		}
		// echo '<pre>' . print_r($wp_registered_sidebars) . '</pre>';
		foreach ( $wp_registered_sidebars as $sidebar ) {
			$sidebars[ $sidebar['name'] ] = $sidebar['id'];
		}

		return $sidebars;
	}

	/**
	*	@access GET REV SLIDER SHORTCODE
	*/
	public static function get_rev_sliders() {
		global $wpdb;
		$revsliders = array(
			'' => esc_html__( 'Choose a slider', TEXTDOMAIN ),
		);
		if ( function_exists( 'rev_slider_shortcode' ) ) {
			$results = $wpdb->get_results( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}revslider_sliders WHERE type != %s",
				'template' ) );
			if ( ! empty( $results ) ) {
				foreach ( $results as $result ) {
					$revsliders[ $result->title ] = $result->alias;
				}
			}
		}

		return $revsliders;
	}


	/**
	*	@access GET MASTER SLIDER in Demo
	*/

	public static function get_master_sliders(){
		global $wpdb;
		$query = "SELECT id,title FROM wp_masterslider_sliders ;";

		$master_slider = array(
			'' => esc_html__( 'Choose a slider', '' ),
		);


	}

	/**
	*	@access VC LINK BUILD
	*/

	public static function get_vc_link($link, $class_link = null){
		if($link){
			if($class_link == null){
				$class_link = 'btn btn-primary';
			}
			echo '<a class="'.$class_link.'" href="'.$link["url"].'" rel="'.$link["rel"].'" target="'.$link["target"].'">'.$link["title"].'</a>';
		}else{
			return false;
		}
	}


	public static function img_thumb( $id, $params ) {
		//$image = self::img_fullsize( $id );
		$size = 'full';
		if ( isset( $params['height'] ) && isset( $params['width'] ) ) {
			$size = array( $params['width'], $params['height'] );
		}
		$image = wp_get_attachment_image_src( $id, $size );

		return $image[0];
	}

	public static function get_param( $param_name, $std = '', $group = null ) {

		switch ( $param_name ) {

			case 'carousel-control':
				/**
				*	@access $std -> element name
				*/

				$param = array(
					'type'            => 'carousel-control',
					'heading'         => __( 'Carousel Control', TEXTDOMAIN ),
					'param_name'      => 'carousel_control',
					'save_always'     => true,
					'slide_to_show'   => array(
						'readonly' => false,
						'value'    => '1',
					),
					'slide_to_scroll' => array(
						'readonly' => false,
						'value'    => '1',
					),
					'auto_play'       => array(
						'readonly' => false,
						'value'    => 'true',
					),
					'infinite'        => array(
						'readonly' => false,
						'value'    => 'true',
					),
					'show_dots'       => array(
						'readonly' => false,
						'value'    => 'true',
					),
					'show_arrows'     => array(
						'readonly' => false,
						'value'    => 'false',
					),
					'variable_width'  => array(
						'readonly' => false,
						'value'    => 'false',
					),
					'center_mode'     => array(
						'readonly' => false,
						'value'    => 'false',
					),
				);

				if(!empty($std)){
					$param['dependency']      = array('element' => $std , 'value' => 'carousel');
				}

			break;

			case 'css':
				$param = array(
					'type'       => 'css_editor',
					'heading'    => __( 'CSS', TEXTDOMAIN ),
					'param_name' => 'css',
					'group'      => __( 'Design Options', TEXTDOMAIN ),
				);
			break;

			case 'note':
				$param = array(
					'type'        => 'textarea',
					'heading'     => __( 'Note', TEXTDOMAIN),
					'param_name'  => 'note',
					'group'       => __( 'Note', TEXTDOMAIN),
					'description' => __( 'Describe more about this element. This text just appearance in the page editor for you more easy to manage the content.',TEXTDOMAIN),
					'admin_label' => true,
				);
				break;
			case 'el_class':
				$param = array(
					'type'        => 'textfield',
					'heading'     => __( 'Extra class name', TEXTDOMAIN ),
					'param_name'  => 'el_class',
					'admin_label' => true,
				);
				break;
			case 'hover_style':
				$param = array(
					'group'       => $group,
					'type'        => 'dropdown',
					'heading'     => __( 'Hover effect', TEXTDOMAIN ),
					'admin_label' => true,
					'param_name'  => 'hover_style',
					'value'       => array(
						__( 'none', TEXTDOMAIN )         => '',
						__( 'Zoom in', TEXTDOMAIN )       => 'zoom-in',
						__( 'Blur', TEXTDOMAIN )          => 'blur',
						__( 'Gray scale', TEXTDOMAIN )    => 'grayscale',
						__( 'White overlay', TEXTDOMAIN ) => 'white-overlay',
						__( 'Black overlay', TEXTDOMAIN ) => 'black-overlay',
					),
					'std'         => $std,
					'description' => __( 'Select animation style for banner when mouse over. Note: Some styles only work in modern browsers',TEXTDOMAIN),
				);
				break;

			case 'css':
				$param = array(
					'type'       => 'css_editor',
					'heading'    => __( 'CSS', TEXTDOMAIN ),
					'param_name' => 'css',
					'group'      => __( 'Design Options', TEXTDOMAIN )
				);
				break;
			case 'title':
				$param = array(
					'type'        => 'textfield',
					'heading'     => __( 'Title', TEXTDOMAIN ),
					'param_name'  => 'title',
					'admin_label' => true,
				);
				break;
			case 'menu':
				// GET DEPENDENCY

				$menus = get_terms( 'nav_menu', array( 'hide_empty' => false ) );
				$items = array();
				foreach ( $menus as $menu ) {
					$items[ $menu->name ] = $menu->slug;
				}
				$param = array(
					'type'        => 'dropdown',
					'heading'     => __( 'Choose Menu',TEXTDOMAIN),
					'value'       => $items,
					'param_name'  => 'menu',
					'admin_label' => true,
					'save_always' => true,
				);
				break;


			case 'element_tag':
				$param = array(
					'type'        => 'dropdown',
					'class'       => '',
					'heading'     => __( 'Element tag', TEXTDOMAIN ),
					'description' => __( 'Select element tag', TEXTDOMAIN ),
					'param_name'  => 'element_tag',
					'value'       => array(
						'Default' => '',
						'h1'      => 'h1',
						'h2'      => 'h2',
						'h3'      => 'h3',
						'h4'      => 'h4',
						'h5'      => 'h5',
						'h6'      => 'h6',
						'p'       => 'p',
						'div'     => 'div',
					),
					'save_always' => true,
				);
				break;
			case 'post_categories':
				return self::get_post_categories();
				break;
			case 'post_categories_select':
				return self::get_post_categories( 'dropdown' );
				break;
			case 'cf7_forms':
				return self::get_cf7_forms();
				break;
			case 'order':
				$param = array(
					'type'        => 'dropdown',
					'param_name'  => 'orderby',
					'heading'     => __( 'Order by', TEXTDOMAIN ),
					'value'       => array(
						__('None',TEXTDOMAIN)						   => 'none',
						__( 'Date', TEXTDOMAIN )                  => 'date',
						__( 'Post ID', TEXTDOMAIN )               => 'ID',
						__( 'Author', TEXTDOMAIN )                => 'author',
						__( 'Title', TEXTDOMAIN )                 => 'title',
						__( 'Last modified date', TEXTDOMAIN )    => 'modified',
						__( 'Number of comments', TEXTDOMAIN )    => 'comment_count',
						__( 'Menu order/Page Order', TEXTDOMAIN ) => 'menu_order',
						__( 'Random order',TEXTDOMAIN )           => 'rand',
					),
				);
				break;
			case 'order_product':
				$param = array(
					'type'       => 'dropdown',
					'param_name' => 'orderby',
					'heading'    => __( 'Order by', TEXTDOMAIN),
					'value'      => array(
						__( 'None', TEXTDOMAIN )               => 'none',
						__( 'Date', TEXTDOMAIN )               => 'date',
						__( 'Price', TEXTDOMAIN )              => 'price',
						__( 'Sales', TEXTDOMAIN )              => 'sales',
						__( 'Rating', TEXTDOMAIN )             => 'rating',
						__( 'Post ID', TEXTDOMAIN )            => 'ID',
						__( 'Title', TEXTDOMAIN )              => 'title',
						__( 'Last modified date', TEXTDOMAIN ) => 'modified',
						__( 'Random order', TEXTDOMAIN )      	=> 'rand',
					),
				);
				break;
			case 'order_way':
				$param = array(
					'type'        => 'dropdown',
					'param_name'  => 'order',
					'heading'     => __( 'Sort order', TEXTDOMAIN ),
					'value'       => array(
						'',
						__( 'Descending',TEXTDOMAIN ) => 'DESC',
						__( 'Ascending', TEXTDOMAIN )  => 'ASC',
					),
					'description' => sprintf(
						wp_kses(
							__( 'Designates the ascending or descending order. More at <a href="%s" target="_blank">WordPress codex page</a>.',
						TEXTDOMAIN ),
							array('a'=>array('href'=>array(),'title'=>array())) ),
						esc_url( 'http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters' ) ),
				);
				break;
			case 'product_cat_autocomplete':
				$param = array(
					'type'        => 'chosen',
					'heading'     => __( 'Categories', TEXTDOMAIN ),
					'param_name'  => 'product_cat_slugs',
					'options'     => array(
						'multiple' => true, // multiple or not
						'type'     => 'taxonomy', // taxonomy or post_type
						'get'      => 'product_cat', // term or post type name, split by comma
						'field'    => 'slug', // slug or id
					),
					'description' => __( 'Select what categories you want to use. Leave it empty to use all categories.',TEXTDOMAIN ),
				);
				break;

				/**
				*	@access UPDATE CORE
				*/

				/**
				*	@access COLOR
				*/
				case 'color':
					$param = array(
						'type'			=> 'dropdown',
						'heading'		=> 'Color',
						'param_name'	=> 'color',
						'value'			=> color_build(),
						'std'				=> 'color-black',
					);
				break;
				/**
				*	@access FONT WEIGHT
				*/

				case 'font_weight':
					$param = array(
						'type'			=> 'dropdown',
						'heading'		=> 'Font Weight',
						'param_name'	=> 'font_weight',
						'value'		=> array(
							'Default'  => 'font-weight-default',
							'Font 100' => 'font-weight-100',
							'Font 200' => 'font-weight-200',
							'Font 300' => 'font-weight-300',
							'Font 400' => 'font-weight-400',
							'Font 500' => 'font-weight-500',
							'Font 600' => 'font-weight-600',
							'Font 700' => 'font-weight-700',
							'Font 800' => 'font-weight-800',
							'Font 900' => 'font-weight-900'
						),
						'std'			  => 'font-weight-default'
					);
				break;

				case 'letter_spacing':
				$param = array(
					'type'			=> 'textfield',
					'heading'		=> 'Letter Spacing',
					'param_name'	=> 'letter_spacing',
					'description'	=> __('Enter number with pixel unit',TEXTDOMAIN)
				);
				break;
				/**
				*	@access UPDATE FONT SIZE atts->custom
				*
				*/
				case 'font_size':
				$param = array(
					'type'			=> 'dropdown',
					'heading'		=> 'Font Size',
					'param_name'	=> 'font_size',
					'value'						=> array(
						'Use Style'				=> '',
						'Custom'					=> 'custom',
						'Medium - 14px' 		=> 'medium',
						'xx Small - 15px' 	=> 'xx-small',
					 	'x Small - 16px' 		=> 'x-small',
						'Small - 18px'			=> 'small',
						'Smaller - 24px'		=> 'smaller',
						'Large - 34px' 		=> 'large',
						'x Large - 40px'   	=> 'x-large',
						'xx Large - 56px'  	=> 'xx-large',
						'xl Large - 72px'  	=> 'xl-large',
						'Larger - 80px'    	=> 'larger',
						'Bigger - 90px'    	=> 'bigger'
					),
					'std'				=> 'large'
				);
				break;

				case 'line_height':
				$param = array(
					'type'			=> 'textfield',
					'heading'		=> 'Line Height',
					'param_name'	=> 'line_height'
				);
				break;

				case 'text_transform':
				$param = array(
					'type'			=> 'dropdown',
					'heading'		=> 'Text Transform',
					'param_name'	=> 'text_transform',
					'value'			=> array(
						'None'					=> '',
						'Text Uppercase' 		=> 'text-uppercase',
						'Text Lowercase'		=> 'text-lowercase',
						'Text Capitalize'		=> 'text-capitalize'
					)
				);
				break;

				case 'text_align':
				$param = array(
					'type'		=> 'dropdown',
					'heading'	=> 'Text Alignment',
					'param_name'	=> 'text_align',
					'value'			=> array(
						'None'			=> '',
						'Text Left'		=> 'text-left',
						'Text Right' 	=> 'text-right',
						'Text Center'	=> 'text-center',
					),
				);

				break;
				/**
				*	@access OPTION ATTR - CSS
				*/
				case 'opacity':
				$param = array(
					'type'			=> 'dropdown',
					'heading'		=> __('Opacity',TEXTDOMAIN),
					'param_name'	=> 'opacity',
					'value'			=> array(
						'No Opacity'=> 'no-opacity',
						'10 %'		=> 'opacity-1',
						'20 %'		=> 'opacity-2',
						'30 %'		=> 'opacity-3',
						'40 %'		=> 'opacity-4',
						'50 %'		=> 'opacity-5',
						'60 %'		=> 'opacity-6',
						'70 %'		=> 'opacity-7',
						'80 %'		=> 'opacity-8',
						'90 %'		=> 'opacity-9',
					),
					'std'				=> 'no-opacity'

				);
				break;

				default : null ; break;
			}

		return $param;
	}


	public static function get_post_categories( $type = 'checkbox' ) {
		$terms = get_terms( 'category',
			array(
				'hide_empty' => false,
			) );

		$categories = array();

		foreach ( $terms as $key => $term ) {

			if($term->term_id != 1 || $term->term_id != 0){
				$categories[ $term->name ] = $term->term_id;
			}
		}

		return array(
			'type'        => $type,
			'heading'     => __( 'Categories', TEXTDOMAIN ),
			'value'       => $categories,
			'param_name'  => 'categories',
			'admin_label' => true,
		);
	}

	public static function get_cf7_forms() {
		$cf7_forms     = array();
		$get_cf7_forms = get_posts( array(
			'post_type'      => 'wpcf7_contact_form',
			'post_status'    => 'publish',
			'posts_per_page' => '10',
		) );
		if ( is_array( $get_cf7_forms ) && count( $get_cf7_forms ) > 0 ) {
			foreach ( $get_cf7_forms as $get_cf7_form ) {
				$cf7_forms[ $get_cf7_form->post_title ] = $get_cf7_form->ID;
			}
		}
		return array(
			'type'        => 'dropdown',
			'heading'     => __( 'Contact Form 7 Data', TEXTDOMAIN ),
			'value'       => $cf7_forms,
			'param_name'  => 'form_id',
			'admin_label' => true,
		);
	}


	public static function get_carousel_control( $args = '' ) {
		$carousel_control                    = array();
		$args_arr                            = explode( ',', $args );
		$carousel_control['slide_to_show']   = isset( $args_arr[0] ) ? $args_arr[0] : 1;
		$carousel_control['slide_to_scroll'] = isset( $args_arr[1] ) ? $args_arr[1] : 1;
		$carousel_control['auto_play']       = isset( $args_arr[2] ) ? $args_arr[2] : 'true';
		$carousel_control['infinite']        = isset( $args_arr[3] ) ? $args_arr[3] : 'true';
		$carousel_control['show_dots']       = isset( $args_arr[4] ) ? $args_arr[4] : 'true';
		$carousel_control['show_arrows']     = isset( $args_arr[5] ) ? $args_arr[5] : 'true';
		$carousel_control['variable_width']  = isset( $args_arr[6] ) ? $args_arr[6] : 'false';
		$carousel_control['center_mode']     = isset( $args_arr[7] ) ? $args_arr[7] : 'false';

		return $carousel_control;
	}



	public static function nice_class( $class ) {
		return trim( preg_replace( '/\s+/', ' ', $class ) );
	}

	public static function number_with_zero( $num ) {
		if ( $num < 10 ) {
			return '0' . $num;
		} else {
			return $num;
		}
	}

	/**
	*	@access GET GRID CLASS BOOTSTRAP -> UPDATE IF LOOP IN ARRAY
	*/
	public static function get_grid_item_class( $number_of_cols ) {
		$total_cols = 12;
		$classes    = array();

		if ( ! is_array( $number_of_cols ) && is_numeric( $number_of_cols ) && $number_of_cols > 0 ) {

			if ( 0 == $total_cols % $number_of_cols ) {
				$width     = $total_cols / $number_of_cols;
				$classes[] = 'col-md-' . $width;
			} else {
				if ( 5 == $number_of_cols ) {
					$classes[] = 'col-md-is-5';
				}
			}
		} else {

			foreach ( $number_of_cols as $media_query => $number_of_col ) {
				$col = intval( $number_of_col );
				if ( $col == 0 ) {
					$col = 1;
				}
				if ( 0 == $total_cols % $col ) {
					$width     = $total_cols / $col;
					$classes[] = 'col-' . $media_query . '-' . $width;
				} else {
					if ( 5 == $col ) {
						$classes[] = 'col-' . $media_query . '-is-5';
					}
				}
			}
		}

		return join( ' ', $classes );
	}


	/**
 	* @access ADD ANIMATION
 	* @var wpb_animate_when_almost_visible 
 	* @param wpb_fadeInUp fadeInUp -> from css_animation [vc_map atts]
 	*/
	public static function add_animation($animation = ''){
		if( $animation == null || empty($animation) || $animation == 'none' ){
			return '';
		}else{
			$add_prefix = ' wpb_'.$animation.' '.$animation.' ';
			return ' wpb_animate_when_almost_visible '.$add_prefix;
		}
	}


	/**
	*	@access EXTEND BUTTON
	*/

	public static function get_param_button($query = null){
		// model default
		$a = array(
			array(
				'type'			=> 'dropdown',
				'heading'		=> __('Style Mode',TEXTDOMAIN),
				'param_name'	=> 'style_mode',
				'value'			=> array(
					'No Style'	=> '',
					'Style Mode 01'	=> 'style-mode-01',
					'Style Mode 02'	=> 'style-mode-02'
				)
			),

			array(
				'type'			=> 'checkbox',
				'heading'		=> __('Style Button',TEXTDOMAIN),
				'param_name'	=> 'style',
				'value'			=> array(
					'No Border'	=> 'no-border',
					'No Radius'	=> 'no-radius'
				),
				'std'				=> 'no-radius',
				'admin_label'	=> true
			),

			array(
				'type'			=> 'dropdown',
				'heading'		=> __('Button Size',TEXTDOMAIN),
				'param_name'	=> 'btn_size',
				'value'			=> array(
					'Large'		=> 'btn-large',
					'Medium'		=> 'btn-medium',
					'Small'		=> 'btn-small'
				),
				'admin_label'	=> true,
				'std'				=> 'btn-medium'
			),

			// OPTION

			array(
				'type'			=> 'dropdown',
				'heading'		=> __('Button Option',TEXTDOMAIN),
				'param_name'	=> 'btn_option',
				'value'			=> array(
					__('Text Normal')		=> '',
					__('Text Uppercase')	=> 'text-uppercase',
					__('Text Lowercase')	=> 'text-lowercase',
				),
				'std'				=> 'text-uppercase'
			),

			array(
				'type'			=> 'dropdown',
				'heading'		=> 'Color - Background',
				'param_name'	=> 'color',
				'value'			=> color_build(),
				'admin_label'	=> true
			),

			array(
				'type'			=> 'dropdown',
				'heading'		=> __('Style Hover',TEXTDOMAIN),
				'param_name'	=> 'style_hover',
				'value'			=> array(
					'Normal'		=> 'style-hover-normal',
					'Style 01'	=> 'style-hover-01',
					'Style 02'	=> 'style-hover-02'
				),
				'std'				=> 'style-hover-normal'
			),

			array(
				'type'			=> 'vc_link',
				'heading'		=> 'Link',
				'param_name'	=> 'link',
			)

		);

		if($query == false || $query == 'single'){
			return $a;
		}elseif($query == true || $query == 'multiple'){
			$b = array(
				array(
					'type'			=> 'dropdown',
					'heading'		=> __('Display',TEXTDOMAIN),
					'param_name'	=> 'display',
					'value'			=> array(
						__('Row',TEXTDOMAIN)		=> 'display-row',
						__('Column',TEXTDOMAIN)	=> 'display-column',
					)
				),

				array(
					'type'			=> 'dropdown',
					'heading'		=> __('Gap Item',TEXTDOMAIN),
					'description'	=> __('Enter value with unit. Default is 5px',TEXTDOMAIN),
					'param_name'	=> 'gap_item',
					'value'			=> array(
						'5px'				=> 'gap-5',
						'10px'			=> 'gap-10',
						'15px'			=> 'gap-15',
						'20px'			=> 'gap-20',
					),
					'std'					=> 'gap-5'
				),

				array(
					'type'			=> 'param_group',
					'heading'		=> __('Create Link',TEXTDOMAIN),
					'param_name'	=> 'multi_link',
					'params'			=> $a
				)
			);
			return $b;

		}

	}


	/**
	*	@access GET ALL FONT ASSETS WITH DORPDOWN VC MAP
	*/
	public static function font_lib($font_name = ''){
		$font = array(
			'type'			=> 'dropdown',
			'heading'		=> __('Font Library',TEXTDOMAIN),
			'param_name'	=> 'font_libs',
		);
		
		switch($font_name){
			case 'fontawesome':
				$font['value'] = [ 'Font Awesome' => $font_name ];
			break;
			case 'openiconic':
				$font['value'] = [ 'Open Iconic' => $font_name ];
			break;
			case 'typicons':
				$font['value'] = [ 'Typicons' => $font_name ];
			break;
			case 'entypo':
				$font['value'] = [ 'Entypo' => $font_name ];
			break;
			case 'linecons':
				$font['value'] = [ 'Linecons' => $font_name ];
			break;
			case 'monosocial':
				$font['value'] = [ 'Mono Social' => $font_name ];
			break;
			case 'material':
				$font['value'] = [ 'Material' => $font_name ];
			break;
			
			default :
			$font['value']	= array(
				'Font Awesome'	=> 'fontawesome',
				'Open Iconic'	=> 'openiconic',
				'Typicons'		=> 'typicons',
				'Entypo'			=> 'entypo',
				'Linecons'		=> 'linecons',
				'Mono Social'	=> 'monosocial',
				'Material'		=> 'material',
			);
			break;
		}

		return $font;

	}

	/**
	*	@access FONT LIBRARY use js-composer default font
	* 	@var terminal -> set dependency 
	*	@return 
	// Helper::get_font('fontawesome');
	// Helper::get_font('openiconic');
	// Helper::get_font('typicons');
	// Helper::get_font('entypo');
	// Helper::get_font('linecons');
	// Helper::get_font('monosocial');
	// Helper::get_font('material');
	*	[
		font awesome
		openiconic
		typicons
		typicons
		entypo
		linecons
		mono social
		material
		]
	*/
	public static function get_font($font_name , $terminal = null){
		// use group

		// terminal access
		if($terminal != null && !empty($terminal) && is_array($terminal)){
			$font['dependency'] = $terminal;
		}else{
			$font['dependency'] = array(
				'element' => 'font_libs' , 'value' => $font_name
			);
		}


		$font = array(
			'type'			=> 'iconpicker',
			'description'	=> __( 'Select icon from library.', TEXTDOMAIN ),
			'settings'		=> array(
				'emptyIcon'		=> false,
				'iconsPerPage' => 1000,
				'type'			=> $font_name
			)
		);

		switch($font_name){
			// font awesome
			case 'fontawesome':

				$font['heading'] 		= __( 'Icon Font Awesome', TEXTDOMAIN );
				$font['param_name']  = 'icon_fontawesome';
				$font['value']       = 'fa fa-adjust';
				
				return $font;
			break;

			// ionic
			case 'openiconic':

				$font['heading']     = __( 'Icon Openiconic', TEXTDOMAIN );
				$font['param_name']  = 'icon_openiconic';
				$font['value']       = 'vc-oi vc-oi-dial';
				return $font;
			break;

			// typicons
			case 'typicons':

				$font['heading']     = __( 'Icon Typicons', TEXTDOMAIN );
				$font['param_name']  = 'icon_typicons';
				$font['value']       = 'typcn typcn-adjust-brightness';
				return $font;
			break;

			// entypo
			case 'entypo':

				$font['heading']     = __( 'Icon Entypo', TEXTDOMAIN );
				$font['param_name']  = 'icon_entypo';
				$font['value']       = 'entypo entypo-icon entypo-icon-note';
				return $font;
			break;

			// linecons
			case 'linecons':

				$font['heading']     = __( 'Icon Linecons', TEXTDOMAIN );
				$font['param_name']  = 'icon_linecons';
				$font['value']       = 'vc_li vc_li-heart';
				return $font;
			break;


			// mono social
			case 'monosocial':
				$font['heading']     = __( 'Icon Monosocial', TEXTDOMAIN );
				$font['param_name']  = 'icon_monosocial';
				$font['value']       = 'monosocial vc-mono vc-mono-fivehundredpx'; 
				return $font;
			break;


			// material
			case 'material':
				$font['heading']     = __( 'Icon Material', TEXTDOMAIN );
				$font['param_name']  = 'icon_material';
				$font['value']       = 'vc-material vc-material-cake';
				return $font;
			break;
			 
		}
	}


	/**
	*	@access FORM NEW SLETTER
	*/
	public static function ahlu_form_newsletter(){

		echo do_shortcode('[email-subscribers-form id="1"]');

	}

	/**
	*	@access GET LINK
	*/
	public static function ahlu_pagination(){
		
		$args = array(
			'mid_size'	=> 2,
			'prev_text' => '<i class="fas fa-long-arrow-alt-left"></i> Previous',
			'next_text' => 'Next <i class="fas fa-long-arrow-alt-right"></i>',
		);

		echo '<div class="ahlu-pagination">'.get_the_posts_pagination( $args ).'</div>';

	}

	/**
	*	@access DISPLAY LANGUAGE FLAG
	*/

	public static function ahlu_language_ui(){
		?>
			<div class='ahlu-language-ui'>
				<a href='<?php echo home_url('/vn'); ?>'>
					<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAMCAMAAABYzB2OAAAATlBMVEX/AAD+AAD/MADqAAD/jQDsAADWAAD/LgD/RgD/6wD/GAD/ygD//wD/AQD/uQD/4gD/8AD/JAD/sAD/DAD/CgDYAADCAADEAACuAACYAADblr/kAAAAVUlEQVQIHQXBQQrCQBAEwOrOLF4j+P8XCh4CAS+uVQAAAAAgBWgBHYD6gZUBj4ixvzDgSLA3KLhb2hsUuDKTCwjwTOz9wcoAxxsvOBMsAJzNSAOAJH8qKQ1P0ElGygAAAABJRU5ErkJggg=='>
					<span>VN</span>
				</a>
				<a href='<?php echo home_url(); ?>'>
					<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAMCAIAAADgcHrrAAAACXBIWXMAAAsSAAALEgHS3X78AAAAK3RFWHRDcmVhdGlvbiBUaW1lAHphIDMxIGRlYyAyMDA1IDE3OjEzOjE3ICswMTAwcgTDIgAAAUhJREFUKBWNwb9Kw0AcAODflQtptDZpg1CwOkgpODn3Bezu5OLeRyn0TXwEBQcdCk6Cs0JEGtL2ernLv0suuVNHaaT9PjQaPSJUrFarKGK9nm0YjbLUd5+zgRHANqVCrTdK4SSJhkPbcRzOUadjxXHOeX7y/AQXbdhWVQ4hzc0G+/6y263i2CsKJSWOIhFFYn57c9lKoc5aSiIl7vct20ZSYoSqdtsyTWyaxvFk4g4dqMM8DzOGEQJCEkKSLCuU0gBQlhV7uE9foRajlAuBtdau22o0jtJUuu5hkuQIgXU+ODgzoU4zCJpxjKfT6yyLguALANAv+HEq3wBS+B++ms8gz1PO4a8U6glKhRBI+z7EMSwWsJ8Pz1szhvR4XJVlWJawnxfON1IiLQQwVlC6phR2IZSSMFwSgt5dl2tNlQq1hl1CralSVKlvif7HO0cUn0EAAAAASUVORK5CYII='>
					<span>US</span>
				</a>
			</div>
		<?php
	}

}
