<?php 
	

/**
*	@access CLASS STATIC AUTO CALL
*/
	
	
class CustomSetting {
	
	
	public static function get_page_layout(){
		return array(
			'no-sidebar'		=> ['src' => THEME_URI . '/assets/images/1c.png'] ,
			'sidebar-content'	=> ['src' => THEME_URI . '/assets/images/2cl.png'],
			'content-sidebar'	=> ['src' => THEME_URI . '/assets/images/2cr.png']
		);
	}


	/**
	*	@access CALL SETTING CUSTOMIZER
	*/
	public static function setting($name = ''){
		if(class_exists('Kirki')){
			return Kirki::get_option('theme',$name);
		}else{
			return false;
		}
	}
	
	
}

