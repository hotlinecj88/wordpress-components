<?php 

defined( 'ABSPATH' ) || exit;

/**
*	@access CORE VENDOR BY AHLUTEAM DEVELOPER
*	@author CJ
*	@version 1
*/

class ColdFire{
	
	public $id_cart;

	public static function header_template_part(){
		$header_name = CustomSetting::setting('header_layout');
		$header_sticky = CustomSetting::setting('header_sticky');
		$header_classes = 'header-'.$header_name.' '.$header_sticky;
		?>
		<div class='header <?php echo $header_classes; ?>'>
		<?php get_template_part('components/header/header',$header_name); ?>
		</div>
		<?php
	}

	public static function header_layout(){
		echo (CustomSetting::setting('header_wide_mode') == true) ? 'container-fluid' : 'container';
	}

	public static function header_logo($echo = false){
		$logo_active 	= CustomSetting::setting('logo_active');
		$logo_title 	= CustomSetting::setting('logo_title');

		if($logo_active == true || $logo_active == 1){
			$logo_url = CustomSetting::setting('logo_url');
			$logo_alt = CustomSetting::setting('logo_alt');	
			if($echo == false || $echo == null){
				echo '<img class="header_logo" src="'.$logo_url.'" alt="'.$logo_alt.'">';
			}else{
				return '<img class="header_logo" src="'.$logo_url.'" alt="'.$logo_alt.'">';
			}
		}else{
			echo $logo_title;
		}

	}

	/**
	*	@access CALL SEARCH HEADER
	*	@param BOOL RETURN IS TRUE - NO RETURN ECHO
	*/
	public static function header_search(){
		if(CustomSetting::setting('header_search') == 1){
			echo '<a href="'.get_bloginfo("url"). '/search">
			<i class="far fa-search"></i>
			</a>';
		}
	}

	/**
	*	@access MENU PRIMARY ACTIVE in Header []
	*/
	public static function header_menu($name = ''){
		if(CustomSetting::setting('header_navigation') == 1){
			if($name == null){
				$menu = wp_nav_menu( array(
					'theme_location'  => 'primary',
					'container'       => 'ul',
					'walker'          => new __Walker_Nav_Menu(),
					// 'walker'				=> new WP_Bootstrap_Navwalker(),
					'echo'				=> false,
					// 'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback'
				));
			}

			echo '<div id="menu-primary-header" class="menu-primary-header">' . $menu .'<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#active-menu-mobile" aria-controls="active-menu-mobile" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  			</button>';
		}
	}

	
	/**
	*	@access MENU MOBILE
	*/

	public static function menu_mobile(){
		$mobile = wp_nav_menu( array(
			'theme_location'  => 'primary',
			'container'       => 'ul',
			'walker'          => new WP_Bootstrap_Navwalker(),
			'echo'				=> false,
			'fallback_cb'     => ['WP_Bootstrap_Navwalker','fallback']

		));

		echo '
		<div id="active-menu-mobile" class="header-menu-mobile active-menu-mobile">
		<div class="menu-mobile-top">
			'.self::header_logo(true).'

			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#active-menu-mobile" aria-controls="active-menu-mobile" aria-expanded="false" aria-label="Toggle navigation">
    			<span class="navbar-toggler-icon"></span>
  			</button>

		</div>
		<div class="menu-mobile-wrapper">
		'.$mobile. '</div></div>';
	}


	/**
	*	@access BUILD GOOGLE FONT LIST
	*/
	public static function list_google_fonts(){
		return array(
			'Roboto'		=> 'Roboto',
			'Lato'		=> 'Lato',
			'Work Sans'	=> 'Work+Sans'
		);

	}


	/**
	*	@access GOOGLE FONT CUSTOMIZER
	*/
	public static function google_font(){
		$font_name 		= '';

		$get_font_custom = CustomSetting::setting('google_font_custom');
		if(empty($get_font_custom)){
			$font_name = CustomSetting::setting('google_font');
			if(empty($font_name)){
				$font_name = 'Roboto';
			}
		}else{
			$font_name = str_replace('&nbsp;','+',$get_font_custom);
		}

		$font_italic 	= false;
		$font_bold 		= false;
		$font_regular 	= false;
		
		
		$build 			= "https://fonts.googleapis.com/css?family=".$font_name.'&display=swap';

		wp_enqueue_style('google-font',$build,false);
	}

	/**
	*	@access ACTIVE HEADER BANNER
	*/

	public static function header_banner(){
		$active 					= CustomSetting::setting('banner_active');
		$background_color 	= CustomSetting::setting('banner_background_color');
		$background_image 	= CustomSetting::setting('banner_background');
		$background_size 		= CustomSetting::setting('banner_background_size');
		$banner_wide 			= CustomSetting::setting('banner_wide');
		$banner_style 			= CustomSetting::setting('banner_style');

		// $class_container 		= ($banner_wide == 1 || $banner_wide == true) ? 'container-fluid' : 'container';

		$class_container 		= 'container';

		$banner_atts			= '';
		
		if(!empty($background_image)){
			$banner_atts		.= "background-image:url(\"".$background_image."\");";
			if(!empty($background_size)){
				$banner_atts 		.= "background-size:$background_size !important;";	
			}
			$banner_atts 		.= "background-repeat:no-repeat !important;";
		}else{
			$banner_atts 		.= "background-color:$background_color;";
		}

		$class_container .= ' '.$banner_style;
		

		// if( $active == true && !is_page() ){
			
		?>

		<div id='banner-wrapper' class='<?php echo $class_container; ?>' style='<?php echo $banner_atts; ?>'>
			<div class='header-banner'>
				<?php self::banner_title(); ?>
			</div>
		</div>

		<?php

		// }else{
		// 	return false;
		// }
		
		
	}

	/**
	*	@access BANNER TITLE
	*/
	public static function banner_title() {
			echo '<h1 class="title">';
			if ( is_front_page() && is_home() ) {
				esc_html_e( 'Home', TEXTDOMAIN );
			} elseif ( is_front_page() ) {
				esc_html_e( 'Home', TEXTDOMAIN);
			} elseif ( is_home() ) {
				esc_html_e( 'Home', TEXTDOMAIN);
			} elseif ( class_exists( 'WooCommerce' ) && is_shop() ) {
				esc_html_e( 'Shop', TEXTDOMAIN );
			} elseif ( class_exists( 'WooCommerce' ) && is_product_category() ) {
				echo single_cat_title();
			} elseif ( is_search() ) {
				echo 'Tìm kiếm kết quả cho : ' . get_search_query();
			} elseif ( is_singular() ) {
				if ( get_post_type() === 'post' ) {
					esc_html_e( 'Home', TEXTDOMAIN );
				} elseif ( get_post_type() === 'product' ) {
					esc_html_e( 'Shop', TEXTDOMAIN);
				} else {
					the_title();
				}
			} elseif ( is_archive() ) {
// 				the_archive_title();
				single_cat_title();
			} else {
				the_title();
			}
			echo '</h1>';

			// BREADCRUMBS FOR SHOP
			if(class_exists('WooCommerce') && is_shop()){
				// woocommerce_breadcrumb();
			}elseif ( class_exists( 'WooCommerce' ) && is_product_category() ) {
				// woocommerce_breadcrumb();
			}elseif(get_post_type() === 'product'){
				// woocommerce_breadcrumb();
			}
			// Breadcrumbs
			self::breadcrumbs();
			// woocommerce_breadcrumb();
			echo '</div>';

	}

	/**
	*	@access Breadcrumbs
	*/
	public static function breadcrumbs() {
		
		if ( function_exists( 'insight_core_breadcrumb' ) ) {
			echo '<div class="breadcrumbs">';
			echo insight_core_breadcrumb( array( 'home_label' => __( 'Home', TEXTDOMAIN ) ) );
			echo '</div>';
		}
	}



	/**
	*	@access BUTTON MINI CART
	*/
	public static function woo_mini_cart(){
		if(CustomSetting::setting('show_mini_cart') == true){
			?>
			<button id='mini-cart-toggle' class='mini-cart-toggle'>
				<i class="fa fa-shopping-cart"></i>
			</button>
			<?php
		}
	}

	/**
	*	@access DISPLAY CONTENT CART
	*/
	public static function woo_mini_cart_display(){
		if(CustomSetting::setting('show_mini_cart') == true){
			woocommerce_mini_cart();
		}
	}
	

	/**
	*	@access PAGINATIONS
	*/
	public static function show_paginations($args = '' , $echo = true){
		$args = array(
			'base'               => '%_%',
			'format'             => '?paged=%#%',
			'total'              => 1,
			'current'            => 0,
			'show_all'           => false,
			'end_size'           => 1,
			'mid_size'           => 2,
			'prev_next'          => true,
			'prev_text'          => __('Previous'),
			'next_text'          => __('Next'),
			'type'               => 'plain',
			'add_args'           => false,
			'add_fragment'       => '',
			'before_page_number' => '',
			'after_page_number'  => ''
		);

		if($echo == true){
			echo paginate_links($args);
		}else{
			return paginate_links($args);
		}
	}


	public static function auto_feed_category($id_term = null, $pagename = null){

		if($pagename != null && !empty($pagename)){
			if(is_page($pagename)){
				if($id_term != null && !empty($id_term)){
					$terms = get_the_terms($id_term , $pagename);
				}else{
					$terms = get_category();	
				}
				
			}
		}

		return $terms;


	}

	/**
	*	@access NAV POST
	*/
	public static function nav_post(){
		$next_post = get_next_post();
		$prev_post = get_previous_post();
		?>

		<div class='nav-post'>
			<?php if(is_a($prev_post, 'WP_Post' )){ ?>
				<a class='prev-post' href='<?php the_permalink($prev_post->ID); ?>'>
					<div class='entry-nav-wrapper'>
					<div class='components'>
						<div class='icon'>
							<i class='fa fa-chevron-left'></i>
						</div>
						<div class='label'>Previous Post</div>
					</div>

					<div class='contents'>
						<div class='title'>
							<?php echo get_the_title($prev_post->ID); ?>
						</div>
						<?php echo wp_get_attachment_image(get_post_thumbnail_id($prev_post->ID),'thumbnail'); ?>
					</div>
					</div>
				</a>
			<?php 

				}

				if(is_a($next_post,'WP_Post')){ 

					?>
						<a class='next-post' href="<?php the_permalink($next_post->ID); ?>">
							<div class='entry-nav-wrapper'>
							<div class='components'>
								<div class='label'>Next Post</div>
								<div class='icon'><i class='fa fa-chevron-right'></i></div>

							</div>

							<div class='contents'>
								<div class='title'>
									<?php echo get_the_title($next_post->ID); ?>
								</div>
								<?php 
									echo wp_get_attachment_image(get_post_thumbnail_id($next_post->ID),'thumbnail'); 
								?>
							</div>
							</div>
						</a>
					<?php
				}
			?>

		</div>

		<?php 
	}


}






