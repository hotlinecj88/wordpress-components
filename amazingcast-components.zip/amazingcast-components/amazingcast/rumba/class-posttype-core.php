<?php 

/**
*	@access CREATE POST TYPE 
*	@author CJ
*	@version 1
*/


if(!class_exists('Ahlu_PostType_Core')){
	class Ahlu_PostType_Core{


		public static $_instance;

		public static function _instance(){
			if(!static::$_instance ){
				static::$_instance = new static();
			}
			return static::$_instance;
		}

		private $name_posttype;
		private $tax;
		private $slug;
		private $icon;

		public function register_posttype(){
			$name = $this->name_posttype;

			if($icon == '' || empty($icon)){
				$icon = 'dashicons-id-alt';;
			}

			$labels = array(
			'name'                  => _x( $name , 'Post type general name' ),
			'singular_name'         => _x( $name, 'Post type singular name' ),
			'menu_name'             => _x( $name, 'Admin Menu text'),
			'name_admin_bar'        => _x( $name, 'Add New on Toolbar'),
			'add_new'               => __( "Add New $name" , TEXTDOMAIN ),
			'add_new_item'          => __( "Add New $name", TEXTDOMAIN ),
			'new_item'              => __( "New $name", TEXTDOMAIN ),
			'edit_item'             => __( "Edit $name", TEXTDOMAIN ),
			'view_item'             => __( "View $name", TEXTDOMAIN ),
			'all_items'             => __( "All $name", TEXTDOMAIN ),
			'search_items'          => __( "Search $name", TEXTDOMAIN ),
			'parent_item_colon'     => __( "Parent : $name", TEXTDOMAIN ),
			'not_found'             => __( "No $name found.", TEXTDOMAIN ),
			'not_found_in_trash'    => __( "No $name found in Trash.", TEXTDOMAIN ),
			'featured_image'        => _x( "$name Cover Image", 'Overrides the “Featured Image” phrase for this post type. Added in 4.3' ),
			'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3' ),
			'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3' ),
			'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3' ),
			'archives'              => _x( "$name archives", 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4' ),
			'insert_into_item'      => _x( "Insert into $name", 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4' ),
			'uploaded_to_this_item' => _x( "Uploaded to this $name", 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4' ),
			'filter_items_list'     => _x( "Filter $name list", 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4' ),
			'items_list_navigation' => _x( "$name list navigation", 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4'),
			'items_list'            => _x( "$name list", 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4'),
			);

			$args = array(
			   'labels'             => $labels,
			   'public'             => true,
			   'publicly_queryable' => true,
			   'show_ui'            => true,
			   'show_in_menu'       => true,
			   'menu_icon'          => $icon,
			   'query_var'          => true,
			   'rewrite'            => array( 'slug' => $this->slug ),
			   'capability_type'    => 'page',
			   'has_archive'        => true,
			   'can_export'          => true,
			   'exclude_from_search' => false,
			   'hierarchical'       => false,
			   'menu_position'      => null,
			   'query_var'          => true,
			   'taxonomies'         => array($this->tax),
			   'supports'           => array( 'title','editor','author','thumbnail','excerpt','comments'),
			);
			register_post_type($this->slug,$args);
		}

		public function register_taxonomy(){
			$name = $this->name_posttype;
			$labels = array(
				'name'              => __( "$name Category",TEXTDOMAIN ),
				'singular_name'     => __( "$name Category",TEXTDOMAIN ),
				'search_items'      => __( "Search $name", TEXTDOMAIN ),
				'all_items'         => __( "All $name", TEXTDOMAIN ),
				'parent_item'       => __( "Parent $name", TEXTDOMAIN ),
				'parent_item_colon' => __( "Parent $name :", TEXTDOMAIN ),
				'edit_item'         => __( "Edit $name", TEXTDOMAIN ),
				'update_item'       => __( "Update $name", TEXTDOMAIN ),
				'add_new_item'      => __( "Add New $name", TEXTDOMAIN ),
				'new_item_name'     => __( "New $name Name", TEXTDOMAIN ),
				'menu_name'         => __( "$name Category", TEXTDOMAIN ),
			);

			$args = array(
				'labels'            => $labels,
				'hierarchical'      => true,
				'show_ui'           => true,
				'show_admin_column' => true,
				'query_var'         => true,
				'public'            => true,
				'rewrite'           => array( 'slug' => $this->tax ),
			);
			register_taxonomy($this->tax,$this->slug,$args);
		}	

		public function auto_fill_slug($slug){
			return 'posttype-' . strtolower($slug);
		}
		public function auto_fill_taxonomy($tax){
			return 'taxonomy-' . strtolower($tax);
		}

		/**
		*	@var $name 
		*	@var $slug
		*	@var $icon
		*/

		public function init($args = array()){
			add_action('init',array($this,'register_posttype'),10);
        	add_action('init',array($this,'register_taxonomy'),10);
		}

		public function __construct($args){
			if(is_array($args)){
				$this->name_posttype = isset($args['name']) ? $args['name'] : 0;

				$this->slug = isset($args['slug']) ? $args['slug'] : $this->auto_fill_slug($this->name_posttype);

				$this->tax = 'category-' . strtolower($this->name_posttype);

				$this->icon = isset($args['icon']) ? $args['icon'] : 'dashicons-id-alt';


				$this->init();


			}else{
				return 0;
			}
		}


	}
}

// new Ahlu_PostType_Core(array('name'=>'Project', 'slug' => 'project' ));
new Ahlu_PostType_Core(array('name'=>'Model'  , 'slug' => 'model' ));