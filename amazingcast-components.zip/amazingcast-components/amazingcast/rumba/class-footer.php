<?php
if ( ! defined( 'ABSPATH' ) ) exit;

if(!class_exists('Register_Posttype_Footer')){

class Register_Posttype_Footer{
	public function __construct(){
		add_action('init',array($this,'register_footer'),1);
	}

	public function register_footer(){
		$labels = array(
		'name'                => _x( 'Footer', 'Post type general name', TEXTDOMAIN ),
        'singular_name'         => _x( 'Footer', 'Post type singular name', TEXTDOMAIN ),
        'menu_name'             => _x( 'Footer', 'Admin Menu text', TEXTDOMAIN ),
        'name_admin_bar'        => _x( 'Footer', 'Add New on Toolbar', TEXTDOMAIN ),
        'add_new'               => __( 'Add New Footer', TEXTDOMAIN ),
        'add_new_item'          => __( 'Add New Footer', TEXTDOMAIN ),
        'new_item'              => __( 'New Footer', TEXTDOMAIN ),
        'edit_item'             => __( 'Edit Footer', TEXTDOMAIN ),
        'view_item'             => __( 'View Footer', TEXTDOMAIN ),
        'all_items'             => __( 'All Footer', TEXTDOMAIN ),
        'search_items'          => __( 'Search Footer', TEXTDOMAIN ),
        'parent_item_colon'     => __( 'Parent Footer:', TEXTDOMAIN ),
        'not_found'             => __( 'No Footer found.', TEXTDOMAIN ),
        'not_found_in_trash'    => __( 'No Footer found in Trash.', TEXTDOMAIN ),
        'featured_image'        => _x( 'Footer Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', TEXTDOMAIN ),
        'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', TEXTDOMAIN ),
        'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', TEXTDOMAIN ),
        'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', TEXTDOMAIN ),
        'archives'              => _x( 'Footer archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', TEXTDOMAIN ),
        'insert_into_item'      => _x( 'Insert into Footer', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', TEXTDOMAIN ),
        'uploaded_to_this_item' => _x( 'Uploaded to this Footer', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', TEXTDOMAIN ),
        'filter_items_list'     => _x( 'Filter Footer list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', TEXTDOMAIN ),
        'items_list_navigation' => _x( 'Footer list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', TEXTDOMAIN ),
        'items_list'            => _x( 'Footer list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', TEXTDOMAIN ),
    	);

    	$args = array(
			'labels'             => $labels,
            'show_in_admin_bar'   => true,
            'show_in_nav_menus'   => true,
			'public'             => true,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'menu_icon'			 => 'dashicons-id-alt',
			'query_var'          => true,
			'rewrite'            => false,
			'capability_type'    => 'page',
			'has_archive'        => false,
			'hierarchical'       => false,
			'menu_position'      => null,
            'can_export'          => true,
			'supports'           => array( 'title', 'editor'),
		);

   	    register_post_type('footer',$args);
	}
}

// DEFAULT BUILD FOOTER FOR CONFIGIRATION
new Register_Posttype_Footer();

}

if(!function_exists('get_footer_layout')){

    function get_all_footer_layout($name = ''){
        if($name == null || empty($name)){
            return false;
        }else{  
            // ONLY GET ALL LAYOUT
            if($name == 'layout'){

                global $wpdb;
                $query = "SELECT ID,post_title,post_name FROM wp_posts WHERE post_type='footer' AND post_status='publish';";
                $result = $wpdb->get_results($query);
                if(count($result) > 0){
                    return $result;
                }

            }
            // CUSTOM SOMETHING ELSE HERE

            else{
                return false;
            }
        }
    }

}

if(!function_exists('display_layout_setting')){
    function display_layout_setting(){
        $layout = get_all_footer_layout('layout');
        if(!empty($layout)){
            $storage = array();
            // BUILD LEVEL 1
            $storage['none']    = __('None',TEXTDOMAIN);
            foreach($layout as $key => $val){
                $storage[$val->ID] = __($val->post_title,TEXTDOMAIN);
            }
            return $storage;
        }else{
            return false;
        }
    }
}

/**
*   @access GET FOOTER BY QUERY
*/

if(!function_exists('ahlu_get_footer_final')){
    function ahlu_get_footer_final(){
        $footer_setting     = CustomSetting::setting('footer_layout');
        $access['all']      = CustomSetting::setting('footer_access_all');

        $access['page']     = CustomSetting::setting('footer_access_page');
        $access['single']   = CustomSetting::setting('footer_access_post');
        $access['shop']     = CustomSetting::setting('footer_access_shop');

        // $footer = get_all_footer_layout($footer_setting)[0];
        $footer_wide = CustomSetting::setting('footer_wide');

        $footer = new WP_Query(array(
            'page_id' => $footer_setting,
            'post_type' => 'footer',
        ));
        
        $footer_sticky = CustomSetting::setting('footer_sticky') ? ' sticky' : ' no-sticky';

        if($footer->have_posts()):
            while($footer->have_posts()):
            $footer->the_post();

            $slug = get_post_field( 'post_name', get_post(get_the_ID())) . $footer_sticky;
            $footer_custom_css = get_post_meta( get_the_ID(),'_wpb_shortcodes_custom_css',true);
            if(!empty($footer_custom_css)){
                echo '<style type="text/css" id="wpb_custom_css-'.get_the_ID().'">'.$footer_custom_css.'</style>';
            }

        ?>
        <footer id='Footer-<?php the_ID(); ?>' class='<?php echo $slug; ?>'>
            <div class='container'>
                <?php the_content(); ?>
            </div>
        </footer>
        <?php 
            endwhile;
            wp_reset_postdata();
        endif;
    }
}


/**
 * @access CALL FOOTER in footer.php -> see footer.php
 */
if(!function_exists('auto_footer')){
    function auto_footer(){
        
        
        // ahlu_get_footer_final();

        /**
        *   @access NOT SYNC
        */
        echo_rumba();
        /**
        *   @access INCLUDE WRAPPER PHOTO SWIPE
        */ 

        require_once THEME_DIR . '/rumba/inc.root-wrapper-photoswipe.php';

        // active nav post
        // ColdFire::nav_post();
    }
}




