<?php

$priority = 1;
$section = 'header';


Kirki::add_field('theme',[
	'type'		=> 'select',
	'label'		=> __('Header Layout','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'settings'	=> 'header_layout',
	'choices'	=> [
		'01'	=> '1 - 1 - 1',
		'02'	=> '1 - 2',
		'03'	=> '2 - 1',
	],
	'default'	=> '01'
]);

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'label'		=> __('header sticky','customizer'),
	'section'	=> $section,
	'priority'	=> $priority,
	'settings'	=> 'header_sticky',
	'default'	=> false,
]);



Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'label'		=> __('Header Wide Mode','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'settings'	=> 'header_wide_mode',
	'default'	=> true
]);

// SEARCH HEADER

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'settings'	=> 'header_search',
	'label'		=> __('Active Search Tool','customizer'),
	'description'	=> __('Enable search tool in header navigation','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> false
]);

// MENU - NAVIGATION ACTIVE

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'settings'	=> 'header_navigation',
	'label'		=> __('Active Navigation','customizer'),
	'description'	=> __('Enable menu in header','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> true
]);

Kirki::add_field('theme',[
	'type'			=> 'toggle',
	'settings'		=> 'logo_active',
	'label'			=> __('Logo Active','customizer'),
	'description'	=> __('Enable logo in header','customizer'),
	'section'		=> $section,
	'priority'		=> $priority++,
	'default'		=> true
]);

Kirki::add_field( 'theme', array(
	'type'        => 'text',
	'settings'    => 'logo_title',
	'label'       => __( 'Logo title', 'customizer' ),
	'description' => __( 'Enter the text used as the title attribute.', 'customizer' ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => get_bloginfo( 'name' ),
));


Kirki::add_field( 'theme', array(
	'type'        => 'text',
	'settings'    => 'logo_alt',
	'label'       => __( 'Logo alt', 'customizer' ),
	'description' => __( 'Enter the text used as the alt attribute.', 'customizer' ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => get_bloginfo( 'description' ),
) );

Kirki::add_field( 'theme', array(
	'type'        => 'image',
	'settings'    => 'logo_url',
	'label'       => __( 'Logo src', 'customizer' ),
	'description' => __( 'Select an image file for your logo.', 'customizer' ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => esc_url( THEME_URI . '/assets/images/logo/logo.png' ),
));





