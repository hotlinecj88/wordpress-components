<?php

/**
*	@access CUSTOMIZE SETTING
*
*/


// require_once THEME_DIR .'/rumba/kirki/kirki.php';

$priority = 1;

// SETUP CUSTOMIZER
Kirki::add_config( 'theme', array(
	'option_type' => 'theme_mod',
	'capability'  => 'edit_theme_options',
));

Kirki::add_section('layout',array(
	'title'		=> __('Layout',TEXTDOMAIN),
	'priority'	=> $priority++
));

Kirki::add_section('header',array(
	'title'		=> __('Header',TEXTDOMAIN),
	'priority'	=> $priority++
));

Kirki::add_section('social',array(
	'title'		=> __('Social',TEXTDOMAIN),
	'priority'	=> $priority++
));

Kirki::add_section('banner',array(
	'title'		=> __('Banner',TEXTDOMAIN),
	'priority'	=> $priority++
));

Kirki::add_section('shop',array(
	'title'		=> __('Shop',TEXTDOMAIN),
	'priority'	=> $priority++,
));

Kirki::add_section('sidebar',array(
	'title'	=> __('Sidebar',TEXTDOMAIN),
	'priority'	=> $priority++
	
));

Kirki::add_section('footer',array(
	'title'		=> __('Footer',TEXTDOMAIN),
	'priority'	=> $priority++
));

Kirki::add_section('setting',array(
	'title'		=> __('Setting',TEXTDOMAIN),
	'priority' 	=> $priority++
));


require_once 'section-layout.php';
require_once 'section-header.php';
require_once 'section-social.php';
require_once 'section-banner.php';
require_once 'section-shop.php';
require_once 'section-sidebar.php';
require_once 'section-footer.php';
require_once 'section-setting.php';

