<?php 

$section = 'banner';
$priority = 1;

Kirki::add_field('theme',[
	'type'		=> 'select',
	'settings'	=> 'banner_style',
	'label'		=> __('Banner Style','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'choices'	=> [
		''					=> __('None','customizer'),
		'banner_light' => __('Banner Light','customizer'),
		'banner_dark'	=> __('Banner Dark','customizer')
	]
]);


Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'settings' 	=> 'banner_active',
	'label'		=> __('Active Banner','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> true
]);	


/**
*	@access ACCESS POST TYPE
*/

// Access All
Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'banner_access_all',
	'label'		=> __('Access All','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> true
]);


	// Page Active
	Kirki::add_field('theme',[
		'type'		=> 'checkbox',
		'settings'	=> 'banner_page_active',
		'label'		=> __('Page Active','customizer'),
		'section'	=> $section,
		'priority'	=> $priority++,
		'default'	=> false
	]);

	// Single Active
	Kirki::add_field('theme',[
		'type'		=> 'checkbox',
		'settings'	=> 'banner_single_active',
		'label'		=> __('Post Active','customizer'),
		'section'	=> $section,
		'priority'	=> $priority++,
		'default'	=> false
	]);

	// Archive Active
	Kirki::add_field('theme',[
		'type'		=> 'checkbox',
		'settings'	=> 'banner_archive_active',
		'label'		=> __('Archive Active','customizer'),
		'section'	=> $section,
		'priority'	=> $priority++,
		'default'	=> false
	]);

	// shop active
	Kirki::add_field('theme',[
		'type'		=> 'checkbox',
		'settings'	=> 'banner_shop_active',
		'label'		=> __('Shop Active','customizer'),
		'section'	=> $section,
		'priority'	=> $priority++,
		'default'	=> false
	]);

	// post type => archive
	



	/**
	*	@access SPECIAL PAGE [post type]
	*/

	

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'settings'	=> 'banner_wide',
	'label'		=> __('Enabled Banner Wide','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> true
	
]);


Kirki::add_field('theme',[
	'type'		=> 'image',
	'settings'	=> 'banner_background',
	'label'		=> __('Banner Background Image','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> '',
]);

Kirki::add_field('theme',[
	'type' 		=> 'color',
	'settings'	=> 'banner_background_color',
	'label'		=> __('Banner Background Color','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> '#E0E0E0',
]);
// BACKGROUND ATTS
	
	// -> NO REPEAT
Kirki::add_field('theme',[
	'type'		=> 'select',
	'settings'	=> 'banner_background_repeat',
	'label'		=> __('Background Repeat','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'choices'	=> [
		''			=> __('None','customizer'),
		'no-repeat'	=> __('No Repeat','customizer'),
		'repeat-x'	=> __('Repeat X','customizer'),
		'repeat-y'	=> __('Repeat Y','customizer'),
	]
]);

	// SIZE 
Kirki::add_field('theme',[
	'type'		=> 'select',
	'settings'	=> 'banner_background_size',
	'label'		=> __('Background Size','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'choices'	=> [
		''					=> __('None','customizer'),
		'auto'			=> __('Auto','customizer'),
		'cover'			=> __('Cover','customizer'),
		'contain'		=> __('Contain','customizer'),
	],
]);


//	POSITION BACKGROUND
Kirki::add_field('theme',[
	'type'		=> 'select',
	'settings'	=> 'banner_background_position',
	'label'		=> __('Background Position','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'choices'	=> [
		''			=> __('None','customizer'),
		'left top'			=> __('Left Top','customizer'),
		'left center'		=> __('Left Center','customizer'),
		'left bottom'		=> __('Left Bottom','customizer'),
		'right top'			=> __('Right Top','customizer'),
		'right center'		=> __('Right Center','customizer'),
		'right bottom'		=> __('Right Bottom','customizer'),
		'center top'		=> __('Center Top','customizer'),
		'center center'	=> __('Center Center','customizer'),
		'center bottom'	=> __('Center Bottom','customizer')
	]
]);



// ATTACHMENT


Kirki::add_field('theme',[
	'type'		=> 'select',
	'settings'	=> 'banner_background_attachment',
	'label'		=> __('Background Original','customizer'),
	'section'	=> $section,
	'priority'	=> $priority++,
	'choices'	=> [
		''					=> __('None','customizer'),
		'border-box'	=> __('Border Box','customizer'),
		'content-box'	=> __('Content Box','customizer'),
	]
]);

































