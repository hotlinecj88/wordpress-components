<?php
$section = 'layout';
$prioriy = 1;


/**
*	@access ------------------------- PAGE -------------------------
*/

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Page Wide','customizer'),
	'type'		=> 'toggle',
	'settings'	=> 'page_wide',
	'default'	=> true,
	// CONTAINER-FLUID
]);
	
// LAYOUT BODY	
Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Page Layout','customizer'),
	'type'      => 'radio-image',
	'settings'	=> 'page_layout',
	'choices'	=> CustomSetting::get_page_layout(),
	'default'	=> 'no-sidebar',
]);

/**
*	@access ------------------------- SHOP -------------------------
*/

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Shop Wide','customizer'),
	'settings'	=> 'shop_wide',
	'type'		=> 'toggle',
	'default'	=> true
]);

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Shop Layout','customizer'),
	'type'      => 'radio-image',
	'settings'	=> 'shop_layout',
	'choices'	=> CustomSetting::get_page_layout(),
	'default'	=> 'no-sidebar',
]);


/**
*	@access ------------------------- SINGLE -------------------------
*/

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Post Wide','customizer'),
	'settings'	=> 'single_wide',
	'type'		=> 'toggle',
	'default'	=> true,
]);

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Post Layout','customizer'),
	'type'      => 'radio-image',
	'settings'	=> 'single_layout',
	'choices'	=> CustomSetting::get_page_layout(),
	'default'	=> 'no-sidebar',
]);

Kirki::add_field('theme',array(
	'type'		=> 'custom',
	'settings'	=> 'header_custom_group_title' . $priority++,
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> '<div class="group_title">'. __('Post Setting','customizer') . '</div>',
));

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Show total posts','customizer'),
	'type'		=> 'number',
	'settings'	=> 'total_posts',
	'choices'	=> [
		'min'		=> 2,
		'max'		=> 1000,
		'step'	=> 2,
	],
	'default'	=> 12
]);

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Post per column','customizer'),
	'type'		=> 'number',
	'settings'	=> 'posts_per_column',
	'choices'	=> [
		'min'		=> 1,
		'max'		=> 4,
		'step'	=> 1,
	],
	'default'	=>2
]);