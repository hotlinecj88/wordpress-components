<?php 


$section    = 'sidebar';
$priority   = 1;

Kirki::add_field('theme',array(
	'section'	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'toggle',
	'label'		=> 'Enable Sidebar',
	'settings'	=> 'enable_sidebar',
	'default'	=> FALSE
));

Kirki::add_field('theme',[
	'section'	=> $section,
	'priotiy'	=> $priority++,
	'type'		=> 'select',
	'label'		=> __( 'Sidebar' , TEXTDOMAIN ),
	'settings'	=> 'sidebar_data',
	'choice'		=> Helper::get_registered_sidebars(),
]);