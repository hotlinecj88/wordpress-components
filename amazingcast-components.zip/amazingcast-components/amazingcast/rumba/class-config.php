<?php 

/**
*	@access CONFIG THEME
*/

$theme = wp_get_theme();


if ( ! empty( $theme['Template'] ) ) { $theme = wp_get_theme( $theme['Template'] ); }

define('THEME_NAME', $theme['Name']);
define('THEME_DIR',get_template_directory());
define('THEME_URI',get_template_directory_uri());
define('TEXTDOMAIN',$theme['TextDomain']);
define('SHORTCODE_CATEGORY',sprintf(__('by %s',TEXTDOMAIN),THEME_NAME));


// ADD HELPER INSIGHT
require_once THEME_DIR.'/rumba/class-insight-core-breadcrumbs.php';
require_once THEME_DIR.'/assets/libs/class-walker-menu.php';
require_once THEME_DIR.'/assets/libs/class-wp-bootstrap-navwalker.php';

require_once THEME_DIR.'/rumba/class-global-funcs.php';
require_once THEME_DIR.'/rumba/class-footer.php';
require_once THEME_DIR.'/rumba/class-customizer.php';
require_once THEME_DIR.'/rumba/class-core.php';
require_once THEME_DIR.'/rumba/class-setup-theme.php';
require_once THEME_DIR.'/rumba/class-posttype-core.php';
require_once THEME_DIR.'/rumba/class-helper.php';
require_once THEME_DIR.'/rumba/customizer/require-customizer.php';
require_once THEME_DIR.'/rumba/class-remake-wpbakery.php';
require_once THEME_DIR.'/rumba/class-woocommerce.php';
require_once THEME_DIR.'/rumba/class-instagram-api.php';



