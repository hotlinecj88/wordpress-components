</div>

<footer>
	<div class='container'><div class='col-12'>
		<h3>©Copyright by <mark>Amazing CastingAgency</mark> All rights reserved | @Design by <a href="#">AhluDeveloper</a></h3>
	</div></div>
</footer>

<a class='hover-on-top' href='#header'><i class="fas fa-arrow-up"></i></a>

<?php 

/**
*   @access AUTO RUN FOOTER
*/
Helper::ahlu_language_ui();
auto_footer();
wp_footer(); 

?>

<!-- SEARCH FORM -->
<div id='form-search-popup' class="form-search-popup">
<button type='button' class='form-popup-button'><i class='fa fa-search'></i></button>
<div class='container'><div class='row'><div class='col-12'>
<?php echo get_search_form(array('echo'	=> false,'aria_label' => 'SEARCH ...')); ?>
</div></div></div>
</div>

<?php 
	$phone_number = CustomSetting::setting('social_phonenumber');

	if($phone_number == null || $phone_number == ''){
		$phone_number = '#';
	}
?>
<!-- FOOTER ACTION -->
<div id='footer-action' class='footer-action d-none'>
	<a href="tel:<?php echo esc_attr($phone_number); ?>"><i class="fas fa-phone"></i></a>
</div>
</body>
</html>