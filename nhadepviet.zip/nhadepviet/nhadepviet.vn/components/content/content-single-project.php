<div id='content-<?php the_ID(); ?>' <?php post_class('content-wrapper'); ?>>
	<div class='entry-wrapper'>
	
		<div class='wpb_column vc_column_container vc_col-sm-9'>
			<div class='entry-title'>
				<a href='<?php echo get_permalink(); ?>'>
					<h1><?php the_title(); ?></h1>
				</a>
			</div>
		</div>

		<div class='entry-category'>
			<?php 
				$terms = get_the_category();
				if(!empty($terms)){
					foreach($terms as $k => $val){
					?>
					<a id='cat-<?php echo $val->term_id; ?> class='cat-item cat-item-<?php echo $val->term_id; ?>' href='#'>
						<?php echo $val->name; ?>
					</a>
					<?php
					}
				}
			?>
		</div>

		<?php get_template_part('components/content-meta'); ?>


		<div class='entry-content'>
			<?php the_content(); ?>
		</div>

	</div>
</div>