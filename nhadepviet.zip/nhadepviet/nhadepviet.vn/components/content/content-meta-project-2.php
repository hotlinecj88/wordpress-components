<div class='entry-meta'>
	
  	<span class='date'>
		<?php echo get_the_date( 'F j, Y' , $post->ID );  ?>
	</span>

</div>
