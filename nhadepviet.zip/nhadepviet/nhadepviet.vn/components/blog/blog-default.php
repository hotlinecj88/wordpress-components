<?php 

/*
	TEMPLATE NAME: Blog Default
*/