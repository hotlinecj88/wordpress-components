<div class='left'>

	<a href='<?php echo get_bloginfo('url'); ?>' class='navbar-brand header-logo'>
		<?php ColdFire::header_logo(); ?>
	</a>
	
</div>

<div class='middle'>
		<?php ColdFire::header_menu(); ?>
</div>

<div class='right'>	
	<div class='header-components'>
	<?php ColdFire::header_search(); ?>
	<?php ColdFire::woo_mini_cart(); ?>
	</div>
</div>