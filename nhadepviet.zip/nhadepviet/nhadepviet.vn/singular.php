<?php 
get_header();


$column_post = 'col-12 col-md-12 col-xl-10 mx-auto';


?>


<div id='page-singular' class='page-singular'>
	<div class='container'>
		<div class='row'>
			
			
			<?php get_sidebar(); ?>


			<div class='col-12 col-xl-8'>
					
				<div class='entry-container'>
					<?php 
						if( have_posts() ){
							while( have_posts() ){
								the_post();
								get_template_part('components/content/content');
							}
						}
						wp_reset_postdata();
					?>
				</div>

			</div>

		</div>

		<div class='row'>
			<div class='col-12'>
				<?php Helper::nav_post(); ?>
			</div>
		</div>
		
	</div>
</div>

<?php
get_footer();
