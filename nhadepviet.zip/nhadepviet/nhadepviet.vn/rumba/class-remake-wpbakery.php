<?php

/**
*  @access REMAKE WPBAKERY (js composer)
*  @version 1
*/


// filter  vc_iconpicker-type-{prefix_icon_name}

function __vc_before_init() {vc_set_as_theme();}

function __set_use_theme_fonts_default() {
	//Get current values stored in the color param in "Call to Action" element
	$param_use_theme_fonts = WPBMap::getParam( 'vc_custom_heading', 'use_theme_fonts' );
	//Append new value to the 'value' array
	$param_use_theme_fonts['std'] = 'yes';
	//Finally "mutate" param with new values
	vc_update_shortcode_param( 'vc_custom_heading', $param_use_theme_fonts );
}

function __load_libs_for_vc_param() {
   wp_enqueue_style( 'is-visual-composer', THEME_URI . '/assets/admin/css/visual-composer.css' );
}

function __load_vc_params(){
   $params = THEME_DIR .'/vc-extend/vc-params';
   require_once $params . '/number.php';
   require_once $params . '/carousel-control.php';
}
function __automata_load_vc_map_default($bool = true){
   $folder_defaults    = THEME_DIR . '/rumba/shortcode/vc_maps/';

   if($bool == TRUE ) foreach(glob($folder_defaults.'*.php') as $file_defaults){
      require_once $file_defaults;
   }
}
// __automata_load_vc_map_default();


/**
*  @access AUTO LOAD MAP
*/

function __automata_load_vc_map( $bool = true ){
	$destination        = THEME_DIR . '/vc-extend/vc-maps/';
	if( $bool == TRUE ) foreach( glob( $destination . '*.php' ) as $files ){
		require_once $files;
	}
   
}

if( ! function_exists( '__do_load_init_wpbakery' ) ){
   function __do_load_init_wpbakery(){
      vc_set_shortcodes_templates_dir( THEME_DIR . '/vc-extend/vc-templates' );
      // load param
      __load_vc_params();
      add_action( 'admin_head', '__load_libs_for_vc_param ');
      add_action( 'vc_before_init', '__vc_before_init' );
      add_action( 'vc_after_init', '__set_use_theme_fonts_default', 'load' );
      __automata_load_vc_map_default();
      __automata_load_vc_map( true );
   }
}

//load before
add_action( 'init' , '__do_load_init_wpbakery',99 );
