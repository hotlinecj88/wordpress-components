<?php 


$section    = 'social';
$priority   = 1;


// FACEBOOK
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_fb',
	'label'    => 'Link Facebook',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));

// TWITTER
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_tw',
	'label'    => 'Link Twitter',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));

// INSTAGRAM
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_ins',
	'label'    => 'Link Instagram',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));
// VIMEO
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_vimeo',
	'label'    => 'Link Vimeo',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));
// YOUTUBE 
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_utube',
	'label'    => 'Link Youtube',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));
// FEED
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_feed',
	'label'    => 'Link Feed',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));
// PHONE NUMBER
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_phonenumber',
	'label'    => 'Phone Number',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));