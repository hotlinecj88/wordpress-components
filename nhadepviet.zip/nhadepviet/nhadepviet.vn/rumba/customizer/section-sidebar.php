<?php 


$section    = 'sidebar';
$priority   = 1;

Kirki::add_field('theme',array(
	'section'	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'toggle',
	'label'		=> 'Enable Sidebar',
	'settings'	=> 'enable_sidebar',
	'default'	=> FALSE
));

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'select',
	'label'		=> __( 'Sidebar' , TEXTDOMAIN ),
	'settings'	=> 'sidebar_choice',
	'choices'	=> array(
		'sidebar-primary'  	=> 'Sidebar Primary',
		'sidebar-secondary'  => 'Sidebar Secondary',
	)
]);


Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'select',
	'label'		=> __( 'No Access' , TEXTDOMAIN ),
	'settings'	=> 'sidebar_except',
	'multiple'  => 10,
	'choices'	=> Helper::get_pages()
]);
