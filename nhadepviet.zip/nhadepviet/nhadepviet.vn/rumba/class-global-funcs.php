	<?php

/**
*	@access GLOBAL FUNCTION
*/

/**
*	@access SETTING STYLE DEFAULT;
*/	

function only_color(){
	return array(
		'Color White'		=> 'color-white',
		'Color Black'		=> 'color-black',
		'Color Red'			=> 'color-red',
		'Color Yellow'		=> 'color-yellow',
		'Color Orange'		=> 'color-orange',
		'Color Gray'		=> 'color-gray',
	);
}

function only_background(){
	return array(
		'Background Red'		=> 'bg-red',
		'Background White'	=> 'bg-white',
		'Background Black'	=> 'bg-black'
	);
}


function color_build(){
	$color = array(
		// COLOR
		'Color White'		=> 'color-white',
		'Color Black'		=> 'color-black',
		'Color Red'			=> 'color-red',
		'Color Yellow'		=> 'color-yellow',
		'Color Orange'		=> 'color-orange',
		'Color Gray'		=> 'color-gray',
		// BACKGROUND
		'Background Red'		=> 'bg-red',
		'Background White'	=> 'bg-white',
		'Background Black'	=> 'bg-black'
	);
	return $color;
}


/**
*	@access STYLE FROM CUSTOMIZER
*/
function echo_rumba(){
	$background_color  = CustomSetting::setting('background_color');

	// BACKGROUND 
	if(empty($background_color)){
		$background_color = "#F9F9F9";
	}
	// FONT

	$html = '';
	$html .= '<style type="text/css">';
	$html .= 'body{ 
		background:'.$background_color.' !important;
	}';
	$html .= '</style>';

	echo $html;
	
}
// TRANSLATE TEXT 
function _tran($text, $echo = false){
	if($echo == true){
		echo sprintf(__($text,'%s'),THEME_TEXTDOMAIN);
	}else{
		return sprintf(__($text,'%s'),THEME_TEXTDOMAIN);
	}
}


/**
*	@access FUNCTION GLOBAL CALL VCMAP -> custom vc_map shortcode
*	@version 1
*	@author CJ
*/

function build_vcmap($map = array(),$option = array()){
	$default = array();
	$default['category']	= SHORTCODE_CATEGORY;

	$icon_link_default = THEME_URI.'/assets/images/shortcode-icons/default.png';
	$icon_link_custom	 = THEME_URI.'/assets/images/shortcode-icons/icon-shortcode-custom.png';
	$icon_link_custom_dir	 = THEME_DIR.'/assets/images/shortcode-icons/icon-shortcode-custom.png';

	if(file_exists($icon_link_custom_dir)){
		$default['icon']	= $icon_link_custom;
	}else{
		$default['icon'] = isset($option['icon']) ? $option['icon'] : $icon_link_default;
	}


	// REMAKE ADD TRANSLATION NAME SHORTCODE -> use textdomain with theme setup

	if(isset($map['name'])){
		$map['name'] = __($map['name'],TEXTDOMAIN);
	}

	// OPTION
	$map['params'][] = vc_map_add_css_animation();
	$map['params'][] = Helper::get_param('el_class');
	$map['params'][] = Helper::get_param('css');

	if(!empty($map) && is_array($map)){
		return vc_map(array_merge($default,$map));
	}else{
		exit;
	}

	
}


/**
*	@access GET CURRENT TEMPLATE NAME
*/
if(!function_exists('current_template_name')){
function current_template_name($options = null){

	$current = '';
	if ( is_front_page() && is_home() ) {
		$current = 'page';
	} elseif ( is_front_page() ) {
		$current =  'page';
	} elseif ( is_home() ) {
		$current =  'page';
	} elseif ( class_exists( 'WooCommerce' ) && is_shop() ) {
		$current =  'shop';
	} elseif ( class_exists( 'WooCommerce' ) && is_product_category() ) {
		$current =  'shop';
	} elseif ( is_search() ) {
		$current =  'page';
	} elseif(is_page()){
		$current = 'page';
	} elseif ( is_singular() ) {

		if ( get_post_type() === 'post' ) {
			$current =  'single';
		} elseif ( get_post_type() === 'product' ) {
			$current =  'shop';
		}else{
			$current =  'default';
		}


	} elseif ( is_archive() ) {
		$current =  'archive';
	} else {
		// NOTHING ELSE
		$current =  'none';
	}

	// NO ONE
	if(empty($current)){
		$current = 'none';
	}

	if($options == null){
		return $current;
	}else{
		return;
	}
}
}


/**
*	@access GET CAROUSEL SETTING -> display javascript
*/
function get_carousel($id_carousel , $setting = '' , $option = ''){
	if($setting == null || empty($setting)){
		return '';
	}else{
		if(is_array($setting)){
			
			$dots 				= isset($setting['show_dots']) ? 'true' : 'false';
			$arrows 				= isset($setting['show_arrows']) ? 'true' : 'false';
			$autoplay 			= isset($setting['auto_play']) ? 'true' : 'false';
			$slidesToShow 		= isset($setting['slide_to_show']) ? $setting['slide_to_show'] : 1;
			$slidesToScroll 	= isset($setting['slide_to_scroll']) ? $setting['slide_to_scroll'] : 1;
			$infinite 			= isset($setting['infinite']) ? 'true' : 'false';

			// CONTINUE RESPONSE
			?>
			<script id='<?php echo $id_carousel; ?>-js' type='text/javascript'>
				(function($){
					$(document).ready(function(){
						$('#<?php echo $id_carousel; ?>').slick({
							
							dots : <?php echo $dots; ?>,
							arrows : <?php echo $arrows; ?>,
							autoplay : <?php echo $autoplay; ?>,
							slidesToShow : <?php echo $slidesToShow; ?>,
							slidesToScroll : <?php echo $slidesToScroll; ?>,
							infinite: <?php echo $infinite; ?>,
							responsive: [

							{
							breakpoint: 991,
							settings: {
								slidesToShow: 3,
								slidesToScroll: 2,
								infinite: true,
								dots: true,
								arrows: false,
								}
							},

							{
							breakpoint: 768,
							settings: {
								slidesToShow: 2,
								slidesToScroll: 1,
								infinite: true,
								dots: true,
								arrows: false,
								}
							},

							{
							breakpoint: 480,
							settings: {
								slidesToShow: 1,
								slidesToScroll: 1,
								arrows: false,
								infinite: true,
								dots: true
								}
							}
							]
						});
					});
				})(jQuery);
			</script>
			<?php
		}else{
			return '';
		}
	}
}


/**
*	@access DUP ARRAY IT SELF WITH TOTAL VALUE 
*/

function dup_array($a , $t , $f = null){
	if(is_array($a) && !empty($a) && is_numeric($t) && $t > 0){
		$c = count($a);
		if($c >= $t){
			return array_slice($a , 0 , $t);
		}elseif($c < $t){
			$n = array();
			for($i = 0;$i < ($t - $c);$i++){
				$r = rand(0 , $c - 1);
				$n[] = $a[$r];
			}
			return array_merge($a,$n);
		}else{
			// default
			return $a;
		}
	}
}
