<?php
defined( 'ABSPATH' ) || exit;
global $product , $product_image;



// Ensure visibility.
if ( empty( $product ) || ! $product->is_visible() ) { return; }

$product_id = $product->get_id();

$shop_display_excerpt = CustomSetting::setting('shop_display_excerpt') ? true : false;
$product_per_column 	 = (int)CustomSetting::setting('product_per_column');

$product_class_grid = 'col-12 col-md-6 ';

if($product_per_column > 0 && $product_per_column <= 4){
	if($product_per_column == 2){
		// 2 COLUMN
		$product_class_grid .= ' col-xl-6';
	}
	// 3 COLUMN
	if($product_per_column == 3){
		$product_class_grid .= ' col-xl-4';
	}
	// 4 COLUMN
	if($product_per_column == 4){
		$product_class_grid .= ' col-xl-3';
	}
}else{
	// 4 COLUMN 
	$product_class_grid .= ' col-xl-3';
}


$product_class 	 = array('ahlu-product','product','product-loop');

$product_actions 	= CustomSetting::setting('product_actions') ? TRUE : FALSE;



?>

<div class='<?php echo esc_attr($product_class_grid); ?>'>

<div <?php wc_product_class( $product_class ); ?> >
	
		<div class='product-thumb'>
			<?php
			if ( $product_image == true ) {
				$product_meta = get_post_meta( $product_id );
				echo wp_get_attachment_image( $product_meta['_thumbnail_id'][0], 'full' );
			} else {
				// woocommerce_template_loop_product_link_open();
				woocommerce_show_product_loop_sale_flash();
				woocommerce_template_loop_product_thumbnail();
				// woocommerce_template_loop_product_link_close();
			} ?>
			

		<?php if($product_actions == true){ ?>

		<div class='product-actions-inside'>
			<div class='product-btn-add-cart woo-action-btn hint--left' aria-label='<?php echo esc_html($product->add_to_cart_text()); ?>'>
				 <?php woocommerce_template_loop_add_to_cart(); ?>
			</div>

			<div class='product-btn-view woo-action-btn hint--left' aria-label='<?php echo __( 'Quick view',TEXTDOMAIN );?>'>
				  <?php echo do_shortcode( '[woosq id="'.$product_id.'"type="link"]' );?>
			</div>

			<div class='product-btn-wishlist woo-action-btn hint--left' aria-label="<?php echo __('Wishlist',TEXTDOMAIN); ?>">
			  <?php echo do_shortcode("[woosw id='$product_id' type='link']"); ?>
			</div>
				
			<div class='product-btn-compare woo-action-btn hint--left' aria-label='<?php echo __( 'Compare',TEXTDOMAIN ); ?>'>
				<?php echo do_shortcode("[wooscp id='$product_id' type='link']"); ?>
			</div>

			</div>
		<?php } ?>

		</div>
		<div class='product-details'>
			<div class='product-title'>
				<?php 
				woocommerce_template_loop_product_link_open();
				woocommerce_template_loop_product_title();
				woocommerce_template_loop_product_link_close();
				?>

			</div>

			<div class='product-price'>
				<?php woocommerce_template_loop_price(); ?>
			</div>
			<?php if($shop_display_excerpt){ ?>
			<div class='product-excerpt'>
			  <?php woocommerce_template_single_excerpt(); ?>
			</div>
			<?php } ?>
			

		</div>
		<?php if($product_actions == false){ ?>
		<div class='product-actions'>
			<div class='product-btn-add-cart woo-action-btn hint--left' aria-label='<?php echo esc_html($product->add_to_cart_text()); ?>'>
				  <?php woocommerce_template_loop_add_to_cart(); ?>
			 </div>

			  <div class='product-btn-view woo-action-btn hint--left' aria-label='<?php echo __( 'Quick view',TEXTDOMAIN );?>'>
				  <?php echo do_shortcode( '[woosq id="'.$product_id.'"type="link"]' );?>
			  </div>

			  <div class='product-btn-wishlist woo-action-btn hint--left' aria-label="<?php echo __('Wishlist',TEXTDOMAIN); ?>">
			  <?php  
			  	  echo do_shortcode("[woosw id='$product_id' type='link']"); 
			  ?>
			  </div>
				
				<div class='product-compare woo-action-btn hint--left' aria-label='<?php echo __( 'Compare',TEXTDOMAIN ); ?>'>
				<?php echo do_shortcode("[wooscp id='$product_id' type='link']");
						  ?>
				</div>
		</div>

	<?php } ?>


</div>

</div>