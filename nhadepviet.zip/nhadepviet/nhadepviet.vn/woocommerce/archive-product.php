<?php
/**
 * The Template for displaying product archives, including the main shop page which is a post type archive
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/archive-product.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.4.0
 */

defined( 'ABSPATH' ) || exit;


$page_layout 	= CustomSetting::setting('shop_layout');
$page_wide   	= CustomSetting::setting('shop_wide');
$class_layout	= '';

$page_class_container = '';

if($page_wide == 1){
	$page_class_container = 'container-fluid';
}else{
	$page_class_container = 'container';
}

// 
if($page_layout != 'no-sidebar'){
	$class_layout = 'col-12 col-md-9 col-lg-9';
}else{
	$class_layout = 'col-12';
}

get_header( 'shop' );

?>

<div class='woo-container <?php echo $page_class_container; ?>'>
<div class="woo-main-content">
<?php

if($page_layout == 'sidebar-content'){do_action( 'woocommerce_sidebar' );}

if ( woocommerce_product_loop() ) {
?>
	<div class='woo-components row'>

		<div class='col-12 col-md-6 col-lg-6'>
			<div class='woo-result-count'>
				<?php woocommerce_result_count(); ?>
			</div>
		</div>

		<div class='col-12 col-md-6 col-lg-6'>
			<div class='woo-order'>
				<?php woocommerce_catalog_ordering(); ?>
			</div>
		</div>

	</div>
	
<?php
	woocommerce_product_loop_start();

	if ( wc_get_loop_prop( 'total' ) ) {
		while ( have_posts() ) {
			the_post();
			do_action( 'woocommerce_shop_loop' );
			wc_get_template_part( 'content', 'product' );
		}
	}
	woocommerce_product_loop_end();

	woocommerce_pagination();

} else {
	do_action( 'woocommerce_no_products_found' );
}

echo '</div>';


if($page_layout == 'content-sidebar' ){do_action( 'woocommerce_sidebar' );}

?>

</div>

<?php

get_footer( 'shop' );

?>
