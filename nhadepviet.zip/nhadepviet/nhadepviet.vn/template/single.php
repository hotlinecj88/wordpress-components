<?php 
get_header();



$layout = CustomSetting::setting('post_layout');
?>

<div class='<?php echo esc_attr(ColdFire::get_class_layout());  ?>'>
<div class='single-container-post'>

	<?php $layout == 'sidebar-content' ? get_sidebar() : false;  ?>

	<?php 

	if(have_posts()):

	while ( have_posts() ) : the_post();

		$author = ucfirst(get_the_author_meta( 'user_nicename' ));
	?>
		
		<div class='entry-title'><?php the_title(); ?></div>

		<div class='entry-meta'>
			
			<span class='avatar'>
			<?php echo get_avatar(get_the_author_meta('ID'),30);?>
			
		  		<a class='avatar-name' href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ), get_the_author_meta( 'user_nicename' ) ); ?>"
				 title="<?php the_author(); ?>"><?php echo $author; ?></a>	
			</span>
			<span class='date'>
				<?php echo get_the_date('m-d-Y'); ?>
			</span>
		</div>

		<div class='entry-thumbnail'><?php  the_post_thumbnail('post'); ?></div>
		
		<div class='entry-content'><?php the_content(); ?></div>

	<?php
	endwhile;

	endif;
	?>
	
	<?php $layout == 'content-sidebar' ? get_sidebar : false; ?>

</div>
</div>

<?php
get_footer();
