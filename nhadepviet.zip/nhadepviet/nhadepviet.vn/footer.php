</div>



<a class='hover-on-top' href='#header'><i class="fas fa-arrow-up"></i></a>

<?php 

/**
*   @access AUTO RUN FOOTER
*/
auto_footer();
wp_footer(); 

?>

<!-- SEARCH FORM -->
<div id='form-search-popup' class="form-search-popup">
<button type='button' class='form-popup-button'><i class='fa fa-search'></i></button>
<div class='container'><div class='row'><div class='col-12'>
<?php echo get_search_form(array('echo'	=> false,'aria_label' => 'SEARCH ...')); ?>
</div></div></div>
</div>

</body>
</html>