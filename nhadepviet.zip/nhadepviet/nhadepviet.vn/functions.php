<?php 

require_once get_template_directory().'/rumba/class-config.php';



