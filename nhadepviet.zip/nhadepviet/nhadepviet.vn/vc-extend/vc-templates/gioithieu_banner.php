<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;


$background = isset( $background ) 	? wp_get_attachment_image_url($background,'full') : 0;
$logo 		= isset( $logo ) 			? $logo : 0;
$heading 	= isset( $heading ) 		? $heading : 'Heading';

$link_fb 	= isset( $link_fb ) 		? esc_url($link_fb) : '#';
$link_pin 	= isset( $link_pin ) 	? esc_url($link_pin) : '#';
?>

<div class='shortcode-gioithieu-banner <?php echo $elclass; ?>'>

	<div class='background' style='background-image:url("<?php echo esc_html($background); ?>")'>

		<div class='logo'>
			<?php echo wp_get_attachment_image( $logo, 'medium'); ?>
		</div>

		<div class='heading'><h2><?php echo $heading; ?></h2></div>
		
		<div class='group'>
			<a href="<?php echo $link_fb; ?>" class='hint--top social-move fb-move' aria-label='Facebook'>
				<i class="fab fa-facebook-square"></i>
			</a>
			<a href="<?php echo $link_pin; ?>" class='hint--top social-move pin-move' aria-label='Pinterest'>
				<i class="fab fa-pinterest-square"></i>
			</a>
		</div>
	</div>

</div>