<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;


$title = isset( $title ) ? $title : '';

$link = isset( $link ) ? vc_build_link( $link ) : 0;

if( $link != 0 || $link != NULL ){
	$link_title 	= isset( $link['title'] ) 	? $link['title'] 	: 'Title ShortCode Link';
	$link_url		= isset( $link['url'] ) 	? $link['url'] 	: '#';
	$link_ref		= isset( $link['ref'] ) 	? $link['ref'] 	: 'follow';
	$link_target 	= isset( $link['target'] ) ? $link['target'] : '_blank';
}
?>


<div class='shortcode-heading-link <?php echo esc_attr( $elclass ); ?>'>

	<div class='entry-wrapper'>
	<div class='entry-title'>
		<h1> <?php echo $title; ?></h1>
	</div>
	<div class='entry-link'>
		<a href='<?php echo esc_url( $link_url ); ?>' ref='<?php echo esc_attr( $link_ref ); ?>' target='<?php echo esc_attr( $link_target ); ?>'><?php echo esc_html( $link_title ); ?> <span>&raquo;</span> </a>
	</div>
	</div>
</div>