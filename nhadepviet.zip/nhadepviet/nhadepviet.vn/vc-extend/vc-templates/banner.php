<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$title 	= isset( $title ) ? $title : '';

$des 		= isset( $description ) ? esc_html( $description ) : '';

$background = isset( $background ) ? wp_get_attachment_image( $background , 'full' ) : 0;

?>

<div class='shortcode-banner <?php echo esc_attr( $elclass ); ?>'>

	<div class='container'>

			<div class='banner-wrapper'>
				<h1 class='title'><?php echo esc_html( $title ); ?></h1>
				<h3 class='description'><?php echo esc_html( $des ); ?></h3>
			</div>


	</div>

	<div class='background'><?php echo $background; ?></div>
</div>