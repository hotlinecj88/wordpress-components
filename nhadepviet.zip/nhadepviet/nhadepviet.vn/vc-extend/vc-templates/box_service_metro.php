<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$post = new WP_Query( array( 
	'post_type'			=> 'project', // all
	'post_status' 		=> 'publish',
	'posts_per_page'	=> 12,
	'paged'				=> get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1,
	'order' 				=> 'DESC',
	
));

$masonry =  '{ "itemSelector": ".isotope-selector", "layoutMode": "masonry" }';

?>

<div class='shortcode-box-service-metro <?php echo $elclass; ?>'>
	
	<div class='container'><div class='row' data-isotope='<?php echo $masonry; ?>' >
	<?php 
		if( $post->have_posts() ){
			$loop = 0;

			while( $post->have_posts() ){
				
				$post->the_post();

				$grid_class = '';
				if( ($loop + 1)%3 == 0){
					$grid_class = 'grid-100';
				}else{
					$grid_class = 'grid-50';
				}
	?>
		
		<div class='isotope-selector grid-item <?php echo $grid_class; ?>'>
			<a href='<?php the_permalink(); ?>' class='entry-posts'>
			<div class='image'>
				<?php echo the_post_thumbnail(); ?>
			</div>
			<div class='title'>
				<h2><?php the_title(); ?></h2>
			</div>
			<a>
		</div>

	<?php
				$loop++;

			}
		}
	?>
	</div></div>
</div>