<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$slide_id = isset( $slide_rev ) ? $slide_rev : 0;

?>

<div class='shortcode-slider-rev <?php  echo esc_attr( $elclass ); ?>'>

	<?php echo do_shortcode('[rev_slider alias="'. $slide_id .'"]'); ?>
</div>