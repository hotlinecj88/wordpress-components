<?php

// Display Only for Single Page

if( is_single() ){

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$des 		= isset( $short_des ) ? $short_des : '';

$addess 	= isset( $addess ) ? $address : '';

$client 	= isset( $client_name ) ? $client_name : '';

$surface = isset( $surface_area ) ? $surface_area : '';

$value 	= isset( $value ) ? $value : '';

$time 	= isset( $time_done ) ? $time_done : '';


// ACCESS ONLY SINGLUAR


?>

<div class='shortcode-project-extra <?php echo esc_attr( $elclass ); ?>'>
	<div class='title'><h3 class='sidebar-title'>Thông Tin Dự Án</h3></div>
	
	<div class='shortcode-wrapper'>
	
	<?php if( !empty( $short_des ) ){ ?>
	<div class='description'>
		<span class='key'>Giới Thiệu Dự Án</span>
		<span class='value'><?php echo esc_html( $short_des ); ?></span>
	</div>
	<?php } ?>
	<div class='category'>
		
	</div>

	<div class='group'>
	<?php if( !empty( $client ) ){ ?>
	<div class='client'>
		<span class='key'>Khách Hàng</span>
		<span class='value'><?php echo esc_html( $client ); ?></span>
	</div>
	<?php } ?>

	
	<?php if( !empty( $address ) ){ ?>
		<div class='address'>
			<span class='key'>Địa Chỉ</span>
			<span class='value'><?php echo esc_html( $address ); ?></span>
		</div>
	<?php } ?>

	</div>

	<div class='group'>
		
	<?php if( !empty( $surface ) ){ ?>
		<div class='surface'>
			<span class='key'>Diện Tích</span>
			<span class=value><?php echo esc_html( $surface ); ?></span>
		</div>
	<?php } ?>

	<?php if( !empty( $value ) ){ ?>
		<div class='values'>
			<span class='key'>Giá Trị</span>
			<span class='value'><?php echo esc_html( $value ); ?></span>
		</div>
	<?php } ?>

	</div>

	<?php if( !empty( $time ) ){ ?>
		<div class='time'>
			<span class='key'>Thời Gian Hoàn Thành</span>
			<span class='value'><?php echo esc_html( $time ); ?></span>
		</div>
	<?php } ?>
	</div>

	<?php 
	// share button
		get_template_part('components/content/content-share');
	?>

</div>

<div id='sidebar' class='sidebar'>
<?php dynamic_sidebar('sidebar-primary'); ?>
</div>

<?php } ?>