<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-02';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$logo = isset( $logo ) ? wp_get_attachment_image( $logo , 'large' ) : 0;
$background = isset( $background ) ? wp_get_attachment_image( $background , 'full' ) : 0;

$address = isset( $address ) ? $address : '';

$tel_1 = isset( $phone_number_one ) ? $phone_numer_one : 0;

$tel_2 = isset( $phone_number_two ) ? $phone_numer_two : 0;

?>

<div class='shortcode-banner <?php echo esc_html( $elclass ); ?>'>
	
	<div class='container'>
		
		<div class='wrapper'>
			<a class='logo' href='<?php bloginfo('home'); ?>'>
				<?php echo $logo; ?>
			</a>
			<div class='contents'>
				<div class='address'>
					<i class='fas fa-map-marker-alt'></i>
					<?php echo esc_html( $address ); ?>
				</div>
				<div class='phone'>
					<i class='fas fa-phone'></i>
					<ul>
						<li><a href="tel:<?php echo $tel_1; ?>"><?php echo $tel_1; ?></a></li>
						<li><a href="tel:<?php echo $tel_2; ?>"><?php echo $tel_2; ?></a></li>
					</ul>
				</div>
			</div>

		</div>


	</div>
	
	<div class='background'>
		<?php echo $background; ?>
	</div>
</div>