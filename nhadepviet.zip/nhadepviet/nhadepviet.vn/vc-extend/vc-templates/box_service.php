<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$title = isset( $title ) ? $title : '';

$type = isset( $type ) ? $type : '';

$image = isset( $image ) ? $image : 0;
$font  = isset( $font ) ? $font : '';


?>

<div class='shortcode-box-service <?php echo esc_html($elclass); ?>'>

	<?php if( $type == 'image' ){ ?>
		<div class='image'>
			<?php echo wp_get_attachment_image( $image , 'large' ); ?>
		</div>
	<?php } ?>

	<?php if( $type == 'font' ){ ?>
		<div class='font'>
			<i class='<?php echo $font; ?>'></i>
		</div>
	<?php } ?>



	<div class='title'>
		<h3><?php echo $title; ?></h3>
	</div>
</div>