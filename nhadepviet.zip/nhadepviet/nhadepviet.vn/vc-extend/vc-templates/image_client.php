<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? $style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= ' '.$style . $animation;

$carousel = isset( $carousel_control) ? Helper::get_carousel_control( $carousel_control ) : 0;

$id_carousel = uniqid('carousel-slider-');

?>
<div class='shortcode-image-client <?php echo esc_attr( $elclass ); ?>'>
	<?php 
	// simple
	if( $style == 'style-01' ){
		$image_simple = isset( $image_simple ) ? explode( ',' , $image_simple ) : 0;

		?>
		
		<div class='carousel-slider'>
			<div id='<?php echo $id_carousel; ?>'>
				<?php foreach( $image_simple as $k => $image ){ 
					$img = wp_get_attachment_image( $image , 'medium'  );
					?>
					<div class='carousel-item'>
						<?php echo $img; ?>
					</div>
				<?php } ?>
			</div>
		</div>

			
		<?php
	}

	if( $style == 'style-02' ){
		$image_details = isset( $image_details ) ? vc_param_group_parse_atts( $image_details ) : 0;
	}

	?>
</div>
<?php get_carousel( $id_carousel , $carousel );  ?>
