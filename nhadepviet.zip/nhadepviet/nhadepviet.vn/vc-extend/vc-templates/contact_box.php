<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$address 	= isset( $address ) 		? $address 		: '';
$phone 		= isset( $phone ) 		? $phone 		: '';
$telephone 	= isset( $telephone ) 	? $telephone 	: '';
$email 		= isset( $email ) 		? $email 		: '';
$time 		= isset( $work_hour ) 	? $work_hour 	: '';


?>

<div class=shortcode-contact-box <?php echo esc_attr( $elclass ); ?>'>
	
	<ul>
		<li>
			<span class='icon'><i class="fas fa-map-marker-alt"></i></span>
			<span class='text'><?php echo $address; ?></span>
		</li>
		<li>
			<span class='icon'><i class="fas fa-phone-alt"></i></span>
			<span class='text'><?php echo $phone; ?></span>
		</li>
		<li>
			<span class='icon'><i class="fas fa-fax"></i></span>
			<span class='text'><?php echo $telephone; ?></span>
		</li>
		<li>
			<span class='icon'><i class="fas fa-envelope"></i></span>
			<span class='text'><?php echo $email; ?></span>
		</li>
		<li>
			<span class='icon'><i class="fas fa-calendar-alt"></i></span>
			<span class='text'><?php echo $time; ?></span>
		</li>
	</ul>

</div>