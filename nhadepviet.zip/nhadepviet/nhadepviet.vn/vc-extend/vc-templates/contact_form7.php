<?php 


$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$form_id = isset($form_id) ? $form_id : '';

?>

<div class='shortcode-form7 <?php echo esc_attr( $elclass ); ?>'>
	<?php echo do_shortcode('[contact-form-7 id="'.$form_id.'" title="Contact form 1"]'); ?>
</div>