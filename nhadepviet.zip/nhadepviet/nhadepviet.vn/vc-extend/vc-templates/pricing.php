<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';
// echo '<pre>';
// print_r( $css_animation );
// echo '</pre>';

$label = isset( $label ) ? $label : '' ;

if( isset( $enable_label ) && ( $enable_label == TRUE || $enable_label == 1 ) ){
    $enable_label = 'enable-label';
}

$title = isset( $title ) ? $title : '';
$image = isset( $picture ) ? $picture : 0;
$contents = isset( $contents ) ? $contents : '';

$link = isset( $link ) ? vc_build_link ( $link ) : FALSE;

$link_title = isset( $link['title'] ) && !empty( $link['title'] )   ? $link['title']    : 'Báo Giá';
$link_url   = isset( $link['url'] )   && !empty( $link['url'] )  ? $link['url']      : '#';
$link_ref   = isset( $link['ref'] ) ? $link['ref']      : 'nofollow';

$elclass .= $style . $animation .' '. $enable_label;
?>

<div class='shortcode-pricing <?php echo esc_attr( $elclass ); ?>'>

    <div class='wrapper'>
        <?php if( $enable_label == 'enable-label' ){ ?>
            <div class='label'><?php echo $label; ?></div>
        <?php } ?>

        <div class='left'>
            <div class='img'><?php echo wp_get_attachment_image( $image , 'post' ); ?></div>
        </div>

        <div class='right'>
            <div class='inner'>
                <div class='title'><h1><?php echo $title; ?></h1></div>            
                <div class='content'><p><?php echo $contents; ?></p></div>
            </div>

            <div class='link'>
                <a href='<?php echo esc_url( $link_url ); ?>' ref='<?php echo $link_ref; ?>' target='_blank'>XEM CHI TIẾT</a>
            </div>
        </div>
    </div>

    
    


</div>