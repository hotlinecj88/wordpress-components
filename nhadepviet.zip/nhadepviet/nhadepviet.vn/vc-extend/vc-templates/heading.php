<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$title = isset( $title ) ? esc_html( $title ) : '';

$html = '';

if( isset( $element_tag ) && !empty( $element_tag ) ){
	$html .= '<' . $element_tag . '>' . $title . '</' . $element_tag . '>';
}else{
	$html = $title;
}

?>
<div class='shortcode-heading <?php echo esc_html( $elclass ); ?>'>
	<?php echo $html; ?>
</div>
