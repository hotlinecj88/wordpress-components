<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$format = isset( $format ) ? $format : NULL;

$elclass .= $style . ' ' . $format . $animation;

$carousel = isset( $carousel_control) ? Helper::get_carousel_control( $carousel_control ) : '';

if( $format == NULL ){
	return 0;
}

$id_carousel = uniqid('carousel-slider-');

$images = isset( $images ) ? explode( ',' , $images ) : 0;

$image_item = count( $images );

if( empty( $images ) && $images == 0 ){
	return 0;
}

/**

	@access ADD IMAGE TO BUTTON
*/

	$prefix 		= [];
	$str_prefix = '%s .slick-dots button#slick-slide-control%s';


?>
<div class='shortcode-box-gallery <?php echo esc_attr( $clclass ); ?>'>

	<?php 
		if( $format == 'box-slider' ){
			?>
			<div class='carousel-slider <?php echo esc_attr( $format ); ?>'>
			<div id='<?php echo esc_attr( $id_carousel ); ?>'>
			
			<?php 
			foreach( $images as $k => $vl ){

				$img = wp_get_attachment_image( $vl , 'full');
				$src = wp_get_attachment_url( $vl );

				if( $k < 10){
					$prefix[$k]['prefix'] = sprintf( '#'.$str_prefix , $id_carousel , '0'.$k );
					$prefix[$k]['src']	 = $src;
				}else{
					$prefix[$k]['prefix'] = sprintf( '#'.$str_prefix , $id_carousel  , $k );
					$prefix[$k]['src']	 = $src;
				}

				?>
				<div class='carousel-item'>
					<?php echo $img; ?>
				</div>

				<?php 
			}

			?>
		

			</div>
			</div>
			
			<?php
		}

		if( $format == 'box-' ){

		}
	?>

	</div>
</div>

	<?php 

	get_carousel( $id_carousel , $carousel ); 
	Helper::get_button_image_carousel( $prefix , TRUE );
	?>

