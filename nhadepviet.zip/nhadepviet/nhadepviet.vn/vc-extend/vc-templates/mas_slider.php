<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$master_slider_id = isset( $master_slider_id ) ? $master_slider_id : 0;

?>

<div class='shortcode-master-slider <?php echo esc_attr( $elclass ); ?>'>
	<?php echo masterslider( $master_slider_id ); ?>
</div>

