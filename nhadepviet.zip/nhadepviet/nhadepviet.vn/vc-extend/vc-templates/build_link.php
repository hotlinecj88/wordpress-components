<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$position = isset( $position ) ? ' '.$position : 'mx-auto';


$link = isset( $link ) ? vc_build_link( $link ) : 0;

if( $link != 0 || $link != NULL ){
	$target 	= isset( $link['target'] ) ? $link['target'] : '_blank';
	$url		= isset( $link['url'] ) ? $link['url'] : '#';
	$title	= isset( $link['title'] ) ? $link['title'] : 'Link Shortcode';
	$rel 		= isset( $link['rel'] ) ? $link['rel'] : 'follow';
}

$elclass .= $style . $position .  $animation;

?>

<div class='shortcode-link <?php echo esc_attr( $elclass ); ?>'>
	<a href='<?php echo esc_url( $url ); ?>' rel='<?php echo $rel; ?>' target='<?php echo $target; ?>'> <?php echo esc_html( $title ); ?></a>
</div>