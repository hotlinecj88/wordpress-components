<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? $style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= ' '.$style . $animation;

$categories = isset( $categories ) ? Helper::filter_array_categories( $categories , 'group' ) : 0 ;

$show_pagination = ( isset( $show_pagination ) &&  $show_pagination == TRUE ) ? 1 : 0;

$post = new WP_Query( array( 
	'post_type'			=> 'project', // all
	'post_status' 		=> 'publish',
	'posts_per_page'	=> 3,
	'paged'				=> get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1,
	'order' 				=> 'DESC',
	'tax_query'			=> [
		[
			'taxonomy'	=> 'category-project',
			'filed'		=> 'term_id',
			'terms'		=> $categories['id']
		]
	]
	
));


// sidebar active
$post_class = 'col-12 col-md-12 col-lg-6';

// no sidebar
if ( CustomSetting::get_customizer_active( get_the_ID() , 'sidebar' ) == 0 ){
	$post_class = 'col-12 col-md-6 col-lg-4';
}

$post_class .= ' isotope-selector';

$masonry =  '{ "itemSelector": ".isotope-selector", "layoutMode": "fitRows" }';
// data-isotope='{ "itemSelector": ".grid-item", "layoutMode": "fitRows" }'

?>

<div class='shortcode-project <?php echo esc_attr( $elclass );?>'>
	
	<div class='container'><div class='row' data-isotope='<?php echo $masonry; ?>' >
	<?php

		if( $post->have_posts() ){

			while( $post->have_posts() ){

				$post->the_post();

	 ?>

	 	<div class='<?php echo esc_attr( $post_class ); ?> grid-item'>

			<div class='entry-box'>
				<div class='entry-dot'>
					<span></span>

					<!-- <span></span>
					<span></span> -->
				</div>

				<div class='entry-thumbnail <?php echo has_post_thumbnail( $post->ID ) ? 'post-thumbnail' : 'no-thumbnail';  ?>'>
					<?php the_post_thumbnail( 'large' ); ?>

					<?php if( $style == 'style-01' ){ get_template_part('components/content/content-share-project'); } ?>
					
					<?php if( $style == 'style-02' ){ get_template_part('components/content/content-meta-project-2'); } ?>
				</div>
				
				<div class='entry-content'>
					
					<?php if( $style == 'style-02' ){ Helper::get_category( $post->ID , 'category-project' , [ 'class' => 'entry-category' ] ); } ?>

					
					<a href='<?php echo get_the_permalink( $post->ID ); ?>'>
						<div class='entry-title'><h1><?php echo the_title(); ?></h1></div>
					</a>
						
					<?php if( $style == 'style-01' ){ get_template_part('components/content/content-meta-project'); } ?>
					<?php 

							if( $style == 'style-02'){
								echo '<div class="entry-excerpt">';
								echo '<p>' . get_the_excerpt() . '</p>';
								echo '</div>';
							}

					?>
					<?php 
						if( $style == 'style-02' ){
							?>
							<div class='entry-readmore'>
								<a href='<?php echo get_the_permalink( $post->ID ); ?>'>Đọc Tiếp</a>
							</div>
							<?php
						}
					?>

				</div>

			</div>

		</div>


	<?php 
		}
		wp_reset_postdata();
	}
	?>

		</div></div>

		<?php if( $show_pagination == TRUE || $show_pagination == 1 ){ ?>
		<div class='container'><div class='row'><div class='col-12'>
			<?php Helper::paginate_links( $post ); ?>
		</div></div></div>
		<?php } ?>


</div>
