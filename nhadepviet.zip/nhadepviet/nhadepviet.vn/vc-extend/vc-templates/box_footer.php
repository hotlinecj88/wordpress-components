<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? $style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= ' '. $style . $animation;

$title = isset( $title ) ? $title : '';
?>

<div class='shortcode-box <?php echo esc_attr( $elclass ); ?>'>
	
	<div class='title'><?php echo esc_html( $title ); ?></div>

	<?php
		if( $style == 'style-01' ){	

			$address 		= isset( $address ) 		? $address 		: '';
			$telephone 		= isset( $telephone ) 	? $telephone 	: '';
			$email 			= isset( $email ) 		? $email 		: '';
			$phone 			= isset( $phone ) 		? $phone 		: '';
			$work_time 		= isset( $work_time ) 	? $work_time 	: '';
	?>
		<div class='address'>
			<i class="fas fa-map-marker-alt"></i>
			<span class='text'><?php echo esc_html( $address); ?></span>
		</div>
		<div class='telephone'>
			<i class="fas fa-phone"></i>
			<span class='text'><?php echo esc_html( $telephone); ?></span>
		</div>
		<div class='email'>
			<i class="fas fa-envelope"></i>
			<span class='text'><?php echo esc_html( $email); ?></span>
		</div>
		<div class='phone'>
			<i class="fas fa-phone"></i>
			<span class='text'><?php echo esc_html( $phone); ?></span>
		</div>
		<div class='work-time'>
			<i class="fas fa-clock"></i>
			<span class='text'><?php echo esc_html( $work_time); ?></span>
		</div>

	<?php }elseif( $style == 'style-02' ){ 

		$list = isset( $list ) ? vc_param_group_parse_atts( $list ) : 0;

		if( ! empty( $list ) ){
			foreach( $list as $k => $vl ){

				$link = isset($vl['list_link']) ? vc_build_link( $vl['list_link'] ) : 0;

				$link_title 	= isset( $link['title'] ) 	? $link['title'] : '';
				$link_url 		= isset( $link['url'] ) 	? $link['url'] : '#';
				$link_target 	= isset( $link['target'] ) ? $link['target'] : '_blank';
				$link_rel	 	= isset( $link['rel'] ) 	? $link['rel'] : 'nofollow';
				?>

					<a href='<?php echo esc_url( $link_url ); ?>' target='<?php echo esc_attr( $link_target ); ?>' rel='<?php echo esc_attr( $link_rel ); ?>'>
						<h3> <i class='fa fa-angle-right'></i> <?php echo esc_html( $link_title ); ?></h3>
					</a>

				<?php

			}
		}
		

		?>

	<?php } ?>

</div>