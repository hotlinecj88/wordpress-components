<?php 

class WPBakeryShortCode_Project_Extra extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'project_extra',
	'name'	=> 'Project Extra',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style' , TEXTDOMAIN ),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			),
			'admin_label'	=> TRUE
		),

		array(
			'type'			=> 'textarea',
			'heading'		=> 'Mô Tả Ngắn',
			'param_name'	=> 'short_des'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Tên Khách Hàng',
			'param_name'	=> 'client_name'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Địa Chỉ',
			'param_name'	=> 'address'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Năm Hoàn Thành',
			'param_name'	=> 'time_done',
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Diện Tích',
			'param_name'	=> 'surface_area'
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Giá Trị',
			'param_name'	=> 'value'
		),

	)
));