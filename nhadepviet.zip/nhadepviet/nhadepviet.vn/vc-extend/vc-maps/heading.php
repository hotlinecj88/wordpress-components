<?php 

class WPBakeryShortCode_Heading extends WPBakeryShortCode{}

build_vcmap(array(

	'base'	=> 'heading',
	'name'	=> 'Heading',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=>	__( 'Style' , TEXTDOMAIN ),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01'	=> 'style-01',
				'Style 02 ( Heading Project Title )'	=> 'style-02',
				'Style 03 ( Heading Page - Gioi Thieu )'	=> 'style-03',
				'Style 04 ( Heading Image Client )'	=> 'style-04',
				'Style 05 ( Heading Contact Page )'	=> 'style-05',
				'Style 06'	=> 'style-06',
			),
			'admin_label'	=> TRUE
		),

		Helper::get_param('element_tag'),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> TRUE
		),


	)

));