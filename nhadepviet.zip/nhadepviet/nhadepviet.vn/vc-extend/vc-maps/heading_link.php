<?php 

class WPBakeryShortCode_Heading_Link extends WPBakeryShortCode{}

build_vcmap([
	'base'	=> 'heading_link',
	'name'	=> 'Heading Link',
	'params'	=> [


		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			)
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Link',
			'param_name'	=> 'link'
		)

	]

]);