<?php

class WPBakeryShortCode_Banner_Details extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'banner_details',
	'name'	=> 'Banner Details',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 02'	=> 'style-02',
			)
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Address',
			'param_name'	=> 'address',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Phone Number 1',
			'param_name'	=> 'phone_numer_one',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Phone Number 2',
			'param_name'	=> 'phone_numer_two',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'attach_image',
			'heading'		=> 'Logo',
			'param_name'	=> 'logo'
		),

		array(
			'type'			=> 'attach_image',
			'heading'		=> 'Background',
			'param_name'	=> 'background'
		),





	)
));