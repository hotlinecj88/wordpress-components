<?php 

class WPBakeryShortCode_Pricing extends WPBakeryShortCode{}

build_vcmap([
    'base'  => 'pricing',
    'name'  => 'Bảng Báo Giá ( Pricing )',
    'params'    => [

        [
            'type'          => 'dropdown',
            'heading'       => 'Style',
            'param_name'    => 'style',
            'value'         => [
                'Style 01'  => 'style-01',
                'Style 02'  => 'style-02'
            ]
        ],

        [
            'type'          => 'checkbox',
            'heading'       => 'Kích hoạt label?',
            'param_name'    => 'enable_label',
            'default'       => FALSE
        ],

        [
            'type'          => 'textfield',
            'heading'       => 'Nhãn ( Label )',
            'param_name'    => 'label',
        ],

        [
            'type'          => 'attach_image',
            'heading'       => 'Hình Ảnh',
            'param_name'    => 'picture'
        ],

        [
            'type'          => 'textfield',
            'heading'       => 'Tiêu Đề (Title)',
            'param_name'    => 'title',
            'admin_label'   => TRUE
        ],

        [
            'type'          => 'textarea',
            'heading'       => 'Nội Dung',
            'param_name'    => 'contents'
        ],

        [
            'type'          => 'vc_link',
            'heading'       => 'Liên Kết Trang',
            'param_name'    => 'link'
        ]
    ]

]);