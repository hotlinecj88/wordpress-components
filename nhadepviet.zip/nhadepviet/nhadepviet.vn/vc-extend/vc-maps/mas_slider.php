<?php 

class WPBakeryShortCode_Mas_Slider extends WPBakeryShortCode{}

build_vcmap([

	'base'	=> 'mas_slider',
	'name'	=> 'Master Slider',
	'params'	=> [

		[
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			]
		],

		Helper::get_master_sliders(),

	]
]);