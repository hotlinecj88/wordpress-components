<?php 

class WPBakeryShortCode_Sidebar extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'sidebar',
	'name'	=> 'Get Sidebar',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Sidebar',
			'param_name'	=> 'sidebar_id',
			'value'			=> Helper::get_registered_sidebars(),
		)

	)
));