	<?php 

class WPBakeryShortCode_Build_Link extends WPBakeryShortCode{}

build_vcmap([
	'base'	=> 'build_link',
	'name'	=> 'Build Link',
	'params'	=> [

		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			]
		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Position',
			'param_name'	=> 'position',
			'value'			=> [
				'Left'		=> 'ml-auto',
				'Right'		=> 'mr-auto',
				'Center'		=> 'mx-auto'
			]
		),

		array(
			'type'			=> 'vc_link',
			'heading'		=> 'Link',
			'param_name'	=> 'link'
		)

		
	]
]);