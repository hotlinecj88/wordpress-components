<?php 

class WPBakeryShortCode_Gioithieu_Banner extends WPBakeryShortCode{}

build_vcmap([
	'base'	=> 'gioithieu_banner',
	'name'	=> 'Giới Thiệu - Banner',
	'params'	=> [

		[
			'type'		=> 'dropdown',
			'heading'	=> 'Style',
			'param_name'=> 'style',
			'value'		=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			]
		],

		[
			'type'		=> 'attach_image',
			'heading'	=> 'Background',
			'param_name'	=> 'background',
		],

		[
			'type'		=> 'attach_image',
			'heading'	=> 'Logo',
			'param_name'	=> 'logo',
		],

		[
			'type'		=> 'textfield',
			'heading'	=> 'Heading',
			'param_name'	=> 'heading'
		],

		[
			'type'		=> 'textfield',
			'heading'	=> 'Link Facebook',
			'param_name' => 'link_fb',
			'default'	=> 'nhadepviet.vn',
		],

		[
			'type'		=> 'textfield',
			'heading'	=> 'Link Pinterest',
			'param_name' => 'link_pin',
			'default'	=> 'nhadepviet.vn',
		],

	]
]);