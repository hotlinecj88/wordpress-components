<?php

class WPBakeryShortCode_Banner extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'banner',
	'name'	=> 'Banner',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01'	=> 'style-01',
			)
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Title',
			'param_name'	=> 'title',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> 'Description',
			'param_name'	=> 'description',
			'admin_label'	=> true
		),

		array(
			'type'			=> 'attach_image',
			'heading'		=> 'Background',
			'param_name'	=> 'background'
		),




	)
));