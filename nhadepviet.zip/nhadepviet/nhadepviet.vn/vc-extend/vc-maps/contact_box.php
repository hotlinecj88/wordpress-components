<?php

class WPBakeryShortCode_Contact_Box extends WPBakeryShortCode{}

build_vcmap([
	'base'	=> 'contact_box',
	'name'	=> 'Contact Box',
	'params'	=> [

		[
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
			]
		],

		// address
		[
			'type'			=> 'textfield',
			'heading'		=> 'Address - Địa Chỉ',
			'param_name'	=> 'address'
		],

		// phone
		[
			'type'			=> 'textfield',
			'heading'		=> 'Phone Number - Số Điện Thoại',
			'param_name'	=> 'phone'
		],
		// fax
		[
			'type'			=>	'textfield',
			'heading'		=> 'Telephone - Hotline',
			'param_name'	=> 'telephone'
		],
		// email
		[
			'type'			=> 'textfield',
			'heading'		=> 'Email',
			'param_name'	=> 'email'
		],
		// work hours
		[
			'type'			=> 'textfield',
			'heading'		=> 'Work Hour - Thời Gian Làm Việc',
			'param_name'	=> 'work_hour'
		]
	]

]);
