<?php 

class WPBakeryShortCode_Box_Footer extends WPBakeryShortCode{}

build_vcmap(array(
	'base'		=> 'box_footer',
	'name'		=> 'Box',
	'params'		=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style' , TEXTDOMAIN ),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01 ( Contact )'			=> 'style-01',
				'Style 02 ( List Dropdown )'	=> 'style-02',
			),
		),

		
		array( 
			'type'			=> 'textfield',
			'heading'		=> __( 'Title' , TEXTDOMAIN ),
			'param_name'	=> 'title',
			'admin_label'	=> TRUE
		),

		// style 01

			// address
			array(
				'type'			=> 'textfield',
				'heading'		=> 'Address',
				'param_name'	=> 'address',
				'dependency'	=> array(
					'element'	=> 'style'	, 'value' => 'style-01'
				)
			),

			// phone number
			array(
				'type'			=> 'textfield',
				'heading'		=> 'Phone Number',
				'param_name'	=> 'telephone',
				'dependency'	=> array(
					'element'	=> 'style'	, 'value' => 'style-01'
				)
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> 'Email',
				'param_name'	=> 'email',
				'dependency'	=> array(
					'element'	=> 'style'	, 'value' => 'style-01'
				)
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> 'Phone',
				'param_name'	=> 'phone',
				'dependency'	=> array(
					'element'	=> 'style'	, 'value' => 'style-01'
				)
			),

			array(
				'type'			=> 'textfield',
				'heading'		=> 'Work Time',
				'param_name'	=> 'work_time',
				'dependency'	=> array(
					'element'	=> 'style'	, 'value' => 'style-01'
				)
			),


			// style 02
			array(
				'type'			=> 'param_group',
				'heading'		=> 'List',
				'param_name'	=> 'list',
				'dependency'	=> array(
					'element'	=> 'style'	, 'value' => 'style-02'
				),
				'params'			=> array(

					array(
						'type'			=> 'vc_link',
						'heading'		=> 'Link',
						'param_name'	=> 'list_link'

					)
				)
			)

	)
));