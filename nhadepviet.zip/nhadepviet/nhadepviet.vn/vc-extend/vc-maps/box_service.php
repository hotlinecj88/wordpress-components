<?php 

class WPBakeryShortCode_Box_Service extends WPBakeryShortCode{}
build_vcmap([
	'base'	=> 'box_service',
	'name'	=> 'Box Service',
	'params'	=> [
		[
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02'
			]
		],

		[
			'type'			=> 'textfield',
			'heading'		=> 'Tiêu Đề',
			'param_name'	=> 'title',
			'admin_label'	=> true
		],

		[
			'type'			=> 'dropdown',
			'heading'		=> 'Type',
			'param_name'	=> 'type',
			'value'			=> [
				'Image - Hình Ảnh'	=> 'image',
				'Font - Icon'			=> 'font',
			],
		],

		// @if
		[
			'type'			=> 'textfield',
			'heading'		=> 'Font - Icon',
			'param_name'	=> 'font',
			'dependency'	=> ['element' => 'type' , 'value' => 'font' ]
		],

		[
			'type'			=> 'attach_image',
			'heading'		=> 'Image',
			'param_name'	=> 'image',
			'dependency'	=> ['element' => 'type' , 'value' => 'image' ]
		],




	]
]);