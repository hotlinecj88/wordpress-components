<?php 

class WPBakeryShortCode_Box_Gallery extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'box_gallery',
	'name'	=> 'Box Gallery',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02'
			]
		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> 'Format',
			'param_name'	=> 'format',
			'value'			=> [
				'Gallery'	=> 'box-gallery',
				'Slider'		=> 'box-slider'
			]
		),

		Helper::get_param('carousel-control'),

		array(
			'type'			=> 'attach_images',
			'heading'		=> 'Pick image from gallery.',
			'param_name'	=> 'images'
		),

		

		



	)
));