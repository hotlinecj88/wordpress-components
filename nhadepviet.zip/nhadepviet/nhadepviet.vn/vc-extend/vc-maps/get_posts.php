<?php 


class WPBakeryShortCode_Get_Posts extends WPBakeryShortCode{}

build_vcmap([
	'base'	=> 'get_posts',
	'name'	=> 'Get Posts',
	'params'	=> [


		[
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style' , TEXTDOMAIN ),
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			],
			'admin_label'	=> TRUE
		],

		Helper::get_post_categories(),

		[
			'type'			=> 'checkbox',
			'heading'		=> __( 'Show Pagination ?' , TEXTDOMAIN ),
			'param_name'	=> 'show_pagination'
		]


	]

]);