<?php 


class WPBakeryShortCode_Contact_Form7 extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'contact_form7',
	'name'	=> 'Contact Form 7',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __('Style',TEXTDOMAIN),
			'param_name'	=> 'style',
			'value'			=> array(
				'Style 01' => 'style-01',
				'Style 02' => 'style-02',
			)

		),

		Helper::get_cf7_forms(),

	)
));