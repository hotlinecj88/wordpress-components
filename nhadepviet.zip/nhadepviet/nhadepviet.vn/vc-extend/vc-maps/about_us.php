<?php 

class WPBakeryShortCode_About_Us extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'about_us',
	'name'	=> 'About Us',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style', TEXTDOMAIN ),
			'param_name'	=> 'style',
			'value'			=> array(
				__('Style 01' , TEXTDOMAIN ) => 'style-01',
				__('Style 02' , TEXTDOMAIN ) => 'style-02',
			),
			'admin_label'	=> TRUE
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __('Title' , TEXTDOMAIN ),
			'param_name'	=> 'title',
		),

		array(
			'type'			=> 'textarea',
			'heading'		=> __( 'Content' , TEXTDOMAIN ),
			'param_name'	=> 'content'
		),

		array(
			'type'			=> 'attach_images',
			'heading'		=> __( 'Images' , TEXTDOMAIN ),
			'param_name'	=> 'images'
		),


	)

));