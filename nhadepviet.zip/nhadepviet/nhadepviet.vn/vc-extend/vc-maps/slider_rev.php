<?php 


class WPBakeryShortCode_Slider_Rev extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'slider_rev',
	'name'	=> 'Slide Revolution',
	'params'	=> array(

		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style' , TEXTDOMAIN ),
			'param_name' 	=> 'style',
			'value'			=> array(
				__( 'Style 01' , TEXTDOMAIN ) => 'style-01',
				__( 'Style 02' , TEXTDOMAIN ) => 'style-02',
			)
		),

		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Choose Slide' , TEXTDOMAIN ),
			'param_name'	=> 'slide_rev',
			'value'			=> Helper::get_rev_sliders()
		)
		

	)
));