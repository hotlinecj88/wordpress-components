<?php 


class WPBakeryShortCode_Project extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'project',
	'name'	=> 'Project',
	'params'	=> array(


		array(
			'type'			=> 'dropdown',
			'heading'		=> __( 'Style' , TEXTDOMAIN ),
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02',
			],
			'admin_label'	=> TRUE
		),

		array(
			'type'			=> 'textfield',
			'heading'		=> __( 'Title', TEXTDOMAIN ),
			'param_name'	=> 'title',
		),


		Helper::get_post_categories( 'checkbox' , 'category-project'),


		array(
			'type'			=> 'checkbox',
			'heading'		=> __( 'Show Pagination ?' , TEXTDOMAIN ),
			'param_name'	=> 'show_pagination'
		)
		



	)
));