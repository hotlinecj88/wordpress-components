<?php 

class WPBakeryShortCode_Box_Service_Metro extends WPBakeryShortCode{}
build_vcmap([
	'base'	=> 'box_service_metro',
	'name'	=> 'Box Service Metro',
	'params'	=> [
		[
			'type'			=> 'dropdown',
			'heading'		=> 'Style',
			'param_name'	=> 'style',
			'value'			=> [
				'Style 01'	=> 'style-01',
				'Style 02'	=> 'style-02'
			]
		],

		



	]
]);