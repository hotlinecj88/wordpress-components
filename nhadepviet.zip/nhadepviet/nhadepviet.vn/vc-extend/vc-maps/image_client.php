<?php 


class WPBakeryShortCode_Image_Client extends WPBakeryShortCode{}

build_vcmap([
	'base'	=> 'image_client',
	'name'	=> 'Image Client',
	'params'	=> [

		[
			'type'				=> 'dropdown',
			'heading'			=> 'Style',
			'param_name'		=> 'style',
			'value'				=> [
				'Style 01 ( Simple )' 	=> 'style-01',
				'Style 02 ( Details )' 	=> 'style-02'
			]
		],

		[
			'type'				=> 'dropdown',
			'heading'			=> 'Slider | Masonry',
			'param_name'		=> 'type',
			'value'				=> [
				'Slider'			=> 'slider',
				'Masonry'		=> 'masonry'
			]
		],

		Helper::get_param('carousel-control'),

		[
			'type'			=> 'attach_images',
			'dependency'	=>	[ 'element' => 'style' , 'value' => 'style-01' ],
			'heading'		=> 'Image Simple',
			'param_name'	=> 'image_simple'
		],

		// style 02	
		[
			'type'			=> 'param_group',
			'dependency'	=> [ 'element'	=> 'style' , 'value'	=> 'style-02' ],
			'heading'		=> 'Image Details',
			'param_name'	=> 'image_details',
			'params'			=> [

				[
					'type'			=> 'attach_image',
					'heading'		=> 'Image',
					'param_name'	=> 'image_id'
				],

				[
					'type'			=> 'textfield',
					'heading'		=> 'Alt ( SEO )',
					'param_name'	=> 'image_alt',
					'default'		=> 'nhadepviet.vn'
				],

				[
					'type'			=> 'textfield',
					'heading'		=> 'Title ( SEO )',
					'param_name'	=> 'image_title',
					'default'		=> 'nhadepviet.vn'
				]

			]
		]

	]
]);