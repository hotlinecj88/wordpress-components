<?php 

class WPBakeryShortCode_Call_Title extends WPBakeryShortCode{}

build_vcmap(array(
	'base'	=> 'call_title',
	'name'	=> 'Call Title',
	'params'	=> array(


		array(
			'type'			=> 'textfield',
			'heading'		=> 'Note Title',
			'param_name'	=> 'note_title'
		)
		

	)
));