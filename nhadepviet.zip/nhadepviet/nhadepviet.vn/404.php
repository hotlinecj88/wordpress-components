<?php
get_header('404');

get_template_part( 'components/content/content','404');

get_footer('404');
?>

