/*
 * Script for our Insight theme
 * Written By: InsightStudio
 * */

'use strict';

jQuery( document ).on( 'ready', function() {

	if ( jQuery().wpColorPicker ) {
		jQuery( '.product_cat_bg_color' ).wpColorPicker();
	}

	// Only show the "remove image" button when needed
	if ( ! jQuery( '#product_cat_bg_image' ).val() ) {
		jQuery( '.remove_cat_bg_button' ).hide();
	}

	// Uploading files
	var file_frame_tm;
	jQuery( document ).on( 'click', '.upload_cat_bg_button', function( event ) {
		event.preventDefault();
		// If the media frame already exists, reopen it.
		if ( file_frame_tm ) {
			file_frame_tm.open();
			return;
		}
		// Create the media frame.
		file_frame_tm = wp.media.frames.downloadable_file = wp.media( {
			title: 'Choose an image',
			button: {
				text: 'Use image'
			},
			multiple: false
		} );
		// When an image is selected, run a callback.
		file_frame_tm.on( 'select', function() {
			var attachment = file_frame_tm.state().get( 'selection' ).first().toJSON();

			jQuery( '#product_cat_bg_image' ).val( attachment.id );
			jQuery( '#product_cat_bg_image_thumbnail' ).find( 'img' ).attr( 'src', attachment.sizes.thumbnail.url );
			jQuery( '.remove_cat_bg_button' ).show();
		} );
		// Finally, open the modal.
		file_frame_tm.open();
	} );

	jQuery( document ).on( 'click', '.remove_cat_bg_button', function() {
		jQuery( '#product_cat_bg_image_thumbnail' ).find( 'img' ).attr( 'src', js_var.wc_placeholder );
		jQuery( '#product_cat_bg_image' ).val( '' );
		jQuery( '.remove_cat_bg_button' ).hide();
		return false;
	} );

	jQuery( document ).ajaxComplete( function( event, request, options ) {
		if ( request && 4 === request.readyState && 200 === request.status
		     && options.data && 0 <= options.data.indexOf( 'action=add-tag' ) ) {

			var res = wpAjax.parseAjaxResponse( request.responseXML, 'ajax-response' );
			if ( ! res || res.errors ) {
				return;
			}
			// Clear Thumbnail fields on submit
			jQuery( '#product_cat_bg_image_thumbnail' ).find( 'img' ).attr( 'src', js_var.wc_placeholder );
			jQuery( '#product_cat_bg_image' ).val( '' );
			jQuery( '.remove_cat_bg_button' ).hide();
			return;
		}
	} );

} );