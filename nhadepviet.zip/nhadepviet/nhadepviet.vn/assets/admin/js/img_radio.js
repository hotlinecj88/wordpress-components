if ( _.isUndefined( window.vc ) ) {
	var vc = {atts: {}};
}

jQuery( document ).ready( function( $ ) {
	$( '.image-radio label' ).on( 'click', function() {
		$( this ).addClass( 'selected' ).siblings().removeClass( 'selected' );
		var $radio = $( this ).prev( 'input[type=radio]' );
		var $target = $( this ).closest( '.image-radio' ).find( '.wpb_vc_param_value' );
		$target.val( $radio.val() );
		$target.trigger( 'change' );
	} );
} );
