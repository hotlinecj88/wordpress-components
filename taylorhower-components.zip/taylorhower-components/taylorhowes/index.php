<?php
get_header();

$template = current_template_name();




if ( have_posts() ) {
	while ( have_posts() ){ 

		the_post();
		//get_template_part( 'components/content/content',$template);
		the_content();
      
	}
	wp_reset_postdata();
}else{
	get_template_part( 'components/content/content-none');
}


get_footer();
?>
