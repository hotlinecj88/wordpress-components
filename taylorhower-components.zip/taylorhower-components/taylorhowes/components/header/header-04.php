<div class='left'>

	<a href='<?php echo get_bloginfo('url'); ?>' class='navbar-brand header-logo'>
		<?php ColdFire::header_logo(); ?>
	</a>
	
</div>

<div class='right'>	
	<?php ColdFire::header_menu(); ?>

	<div class='header-components'>
		<button class='form-popup-button'>
			<i class='fas fa-search'></i>
		</button>
	</div>

</div>