<div class='left'>
	<!-- Menu Toggle -->
	<!-- <div class='nav-toggle'>
		<button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#active-menu-mobile' aria-controls='active-menu-mobile' aria-expanded='false' aria-label='Toggle navigation'>
			<span class='navbar-toggler-icon'></span>
		</button>
	</div> -->
	<?php ColdFire::header_menu(); ?>
</div>

<div class='middle'>
	<a href='<?php bloginfo('home'); ?>'><?php echo CustomSetting::setting('logo_title'); ?></a>
</div>

<div class='right'>	
	<div class='socials-wrapper'>
	<?php 
		$pinterest_link 	= CustomSetting::setting('social_pinterest');
		$twitter_link 		= CustomSetting::setting('social_tw');
		$instagram_link 	= CustomSetting::setting('social_ins');

		if( CustomSetting::setting('social_pin_active') == true  ){
	?>
			<a href='<?php echo esc_url( $pinterest_link ); ?>' hint--bottom='Pinterest'>  <i class='fa fa-pinterest'></i> </a>
	<?php } if( CustomSetting::setting('social_tw_active') == true ){ ?>
			<a href='<?php echo esc_url( $twitter_link ); ?>' hint--bottom='Twitter'>  <i class='fa fa-twitter'></i> </a>
	<?php } if( CustomSetting::setting('social_ins_active') == true ){ ?>
			<a href='<?php echo esc_url( $instagram_link ); ?>' hint--bottom='Instagram'>  <i class='fa fa-instagram'></i> </a>
	<?php } ?>

	</div>
	

</div>