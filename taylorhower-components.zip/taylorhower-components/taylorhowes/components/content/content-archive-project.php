<div class='grid-item col-12 col-xl-4 col-lg-4 col-md-6'>
	<div class='entry-box'>

		<div class='entry-thumbnail <?php echo has_post_thumbnail() ? 'post-thumbnail' : 'no-thumbnail'; ?>'>
			<?php get_template_part('components/content/content-share'); ?>
			<?php the_post_thumbnail( 'large' ); ?>
		</div>
		
		<div class='entry-wrapper'>

			<div class='entry-title'>
				<h1><a href='<?php the_permalink(); ?>'><?php the_title(); ?></a></h1>
			</div>

			<div class='entry-date'>
				<i class='fas fa-clock'></i>
				<?php the_date('F j, Y'); ?>	
			</div>
			
			<div class='entry-content'>
				<p>
				<?php 
						//echo get_the_excerpt(); 
					echo 'So this blog and others like it have exhausted the facts...';
				?>
				</p>
					
			</div>
			
			<div class='entry-readmore'>
				<a href='<?php the_permalink(); ?>'>ĐỌC TIẾP</a>
			</div>

		</div>

	</div>
</div>