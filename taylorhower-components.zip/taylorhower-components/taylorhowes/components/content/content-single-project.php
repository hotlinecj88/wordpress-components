<div id='content-<?php the_ID(); ?>' <?php post_class('project-single-post'); ?>>
	<div class='entry-wrapper'>
		
		<div class='entry-title'>
			<h1><?php echo get_the_title(); ?></h1>
		</div>
		<?php 
			$tag = get_the_terms( get_the_ID() , 'tag-project' );
			if( !empty( $tag ) ){
		?>
		<div class='entry-tag'>
			<?php 
				foreach( $tag as $k => $vl ){
					echo '<h3>'. $vl->name .'</h3>';
				} 
			?>
		</div>
		<?php } ?>

		<div class='entry-excerpt'>
			<p><?php echo get_the_excerpt(); ?></p>
		</div>

		<div class='entry-contents'>
			<?php 
			// Display shortcode content
			the_content(); ?>
		</div>
		
	</div>
</div>