<div id='content-<?php the_ID(); ?>' <?php post_class('content-wrapper'); ?>>
	<div class='entry-wrapper'>

		<div class='entry-thumbnail'>
			<?php echo the_post_thumbnail('full'); ?>
		</div>

		<div class='entry-title'>
			<h1><?php the_title(); ?></h1>
		</div>

		<?php 
			$tagline = get_the_terms( get_the_ID() , 'post_tag' );
			if( !empty( $tagline ) ){

				?>
				<div class='entry-tag-line'>
					<?php foreach( $tagline as $k => $vl ){ ?>
						<span><?php echo $vl->name; ?></span>
					<?php } ?>	
					&#160;-&#160;<div class='entry-post-time'><?php echo get_the_date('d F Y');?> </div>
				</div>
				<?php

			}
		?>

		<div class='entry-category'>
			<?php 
				$terms = get_the_category();
				if(!empty($terms)){
					foreach($terms as $k => $val){
					?>
					<a id='cat-<?php echo $val->term_id; ?>' class='cat-item cat-item-<?php echo $val->term_id; ?>' href='<?php echo get_category_link( $val->term_id ); ?>'>
						<?php echo $val->name; ?>
					</a>
					<?php
					}
				}
			?>
		</div>

		<?php get_template_part('components/content-meta'); ?>


		<div class='entry-content post-content'>

				<?php the_content(); ?>

		</div>

	</div>
</div>