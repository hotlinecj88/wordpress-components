<?php 
	$img404 = get_template_directory_uri().'/assets/images/404.png';
	if( !empty( CustomSetting::setting('background404') ) ){
		$img404 = CustomSetting::setting('background404');
	}else{
		$img404 = get_template_directory_uri().'/assets/images/404.png';
	}
?>

<style>

	.error404-container{
		width:100%;
		position:fixed;
		top:0;left:0;
		background-image:url("<?php echo esc_url($img404); ?>");
		height: 100vh;
    	background-size: cover;
    	background-position: center center;
    	display:flex;
    	justify-content:center;
    	align-items:center;
	}

	.error404-container a{
		position:absolute;
		bottom:100px;
		background:#43515a;
		color:white;
		padding:10px 40px;
		font-weight:600;
		font-size:18px;
		border:2px solid white;
		box-shadow:0 0 50px 1px rgba(255,255,255,0.4);
		text-shadow:0 0 1px 1px rgba(47,47,47,0.2);
		text-transform:uppercase;
		letter-spacing:1px;
		transition:all 0.18s ease-in-out;
	}

	.error404-container a:hover{
		background:none;
		color:#43515a;
	}



</style>

<div class='error404-container'>
	<a class='hint--top' aria-label='Back Home' href='<?php bloginfo('home'); ?>'>Trang Chủ</a>
</div>
