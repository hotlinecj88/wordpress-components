<div id='single-<?php the_ID(); ?>' class='single-wrapper'>
	<div class='single-content'>
		<?php get_template_part('components/content/content'); ?>
	</div>
</div>