<div class="entry-meta">

	<div class="author">
		<span class='avatar'>
			<?php echo get_avatar(get_the_author_meta('ID'),30);?>
		</span>
		<span class='avatar-name'>
  			<?php $author = ucfirst( get_the_author_meta( 'user_nicename' ) ); 
  				echo esc_html($author); 
  			?>
	  	</span>
	  	<span class='date'>
			<?php echo get_the_date( 'F j, Y' , $post->ID );  ?>
		</span>

	</div>
	
	<?php 
		$view = rand( 0 , 9999 );
	?>
	<div class='view'>
		<i class='fa fa-eye'></i>
		<span><?php echo $view; ?></span>
	</div>


</div>
