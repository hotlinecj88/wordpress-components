<?php 

/*
	TEMPLATE NAME: Blog Default
*/

get_header();

?>

<?php
get_footer();