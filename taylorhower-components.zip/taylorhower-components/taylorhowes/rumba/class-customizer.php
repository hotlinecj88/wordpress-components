<?php 
	
	
class CustomSetting {
	

	public static $banner_active 	= 1;
	public static $sidebar_active = 1;
	
	public static function get_page_layout(){
		return array(
			'no-sidebar'		=> ['src' => THEME_URI . '/assets/images/1c.png'] ,
			'sidebar-content'	=> ['src' => THEME_URI . '/assets/images/2cl.png'],
			'content-sidebar'	=> ['src' => THEME_URI . '/assets/images/2cr.png']
		);
	}


	/**
	*	@access CALL SETTING CUSTOMIZER
	*/
	public static function setting( $name = '' ){
		if( class_exists( 'Kirki' ) ){
			return Kirki::get_option( 'theme' , $name );
		}else{
			return FALSE;
		}
	}

	public static function get_registered_sidebars( $default_option = false ) {
		global $wp_registered_sidebars;
		$sidebars = array();

		if ( $default_option === true ) {
			$sidebars['default'] = __( 'Primary Sidebar', TEXTDOMAIN );
		}
		foreach ( $wp_registered_sidebars as $sidebar ) {
			$sidebars[ $sidebar['name'] ] = $sidebar['id'];
		}

		return $sidebars;
	}

	/**
	*	@access ACTIVE [ BANNER - SIDEBAR ]
	*
	*/

	public static function get_customizer_active( $post_id , $key = '' ){
		$flag = 0;

		if( $key == 'banner' ){
			$page = static::setting( 'banner_access_page' );
		}

		if( $key == 'sidebar' ){
			$page = static::setting('sidebar_except');
		}
		

		if( $post_id == 0 || $post_id == NULL ){
			$post_id = get_the_ID();
		}

		if( in_array( $post_id , $page ) ){

			if( $key == 'banner' ){
				static::$banner_active = 0;
			}

			if( $key == 'sidebar' ){
				static::$sidebar_active = 0;
				return FALSE;
			}

		}else{

			if( $key == 'banner' ){
				ColdFire::header_banner();
				static::$banner_active = 1;
			}

			if( $key == 'sidebar' ){
				static::$sidebar_active = 1;
				return TRUE;
			}

		}

		unset( $page );

	}	
}

