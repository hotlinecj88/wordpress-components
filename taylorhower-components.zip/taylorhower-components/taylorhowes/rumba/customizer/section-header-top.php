<?php
$section = 'header-top';
$prioriy = 1;


Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'label'		=> 'Enable',
	'settings'	=> 'enable_header_top',
	'section'	=> $section,
	'priority'	=> $priority++,
]);

Kirki::add_field( 'theme',[
	'type'		=> 'text',
	'label'		=> 'Phone Number',
	'settings'	=> 'header_top_phone',
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> esc_html__( 'Phone Number' )
]);

Kirki::add_field( 'theme' , [
	'type'		=> 'text',
	'label'		=> 'Email',
	'settings'	=> 'header_top_email',
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> esc_html__( 'Email' )
]);

