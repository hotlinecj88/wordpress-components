<?php 


$priority 	= 1;
$section 	= 'shop';


// mimi cart
Kirki::add_field('theme',[
	'settings'	=> 'show_mini_cart',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Show Mini Cart','customizer'),
	'type'		=> 'toggle',
	'default'	=> false,

]);

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'settings'	=> 'shop_display_excerpt',
	'label'		=> __('Shop Display Excerpt Content','customizer'),
	'type'		=> 'toggle',
	'default'	=> false

]);

Kirki::add_field('theme',[
	'section'	=> $section,
	'priority'	=> $priority++,
	'settings'	=> 'product_actions',
	'label'		=> __('Product Actions','customizer'),
	'description'	=> __('Toggle on for hover , turn off for click button','customizer'),
	'type'		=> 'toggle',
	'default'	=> true
]);

// type product
Kirki::add_field('theme',[
	'settings'	=> 'show_type_product',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Show Type Product','customizer'),
	'type'		=> 'select',
	'choices'	=> [
		'grid'	=> __('Grid','customizer'),
		'list'	=> __('List','customizer')
	],
	'default'	=> 'grid',

]);

  
// total product
Kirki::add_field('theme',[
	'settings'	=> 'total_product',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Total product','customizer'),
	'type'		=> 'number',
	'choices'     => [
		'min'  => 8,
		'max'  => 1000,
		'step' => 4,
	],
	'default'	=> 4

]);

// product per column
Kirki::add_field('theme',[
	'settings'	=> 'product_per_column',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Product per column','customizer'),
	'description'	=> __('Max column is 4','customizer'),
	'type'		=> 'number',
	'choices'     => [
		'min'  => 2,
		'max'  => 4,
		'step' => 1,
	],
	'default'	=> 4
]);




