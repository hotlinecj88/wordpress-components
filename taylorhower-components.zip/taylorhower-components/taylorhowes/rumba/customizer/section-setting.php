<?php 

$priority = 1;
$section = 'setting';

Kirki::add_field('theme',[
	'type'		  	=> 'checkbox',
	'settings'		=>	'enable_languages_multiple',
	'label'			=> 'Enable Languages',
	'priority'	  	=> $priority++,
	'section'     	=> $section,
	'default'		=> false
]);

// BACKGROUND COLOR
Kirki::add_field( 'theme', [
	'type'        => 'color',
	'settings'    => 'background_color',
	'label'       => __( 'Color Control (hex-only)', TEXTDOMAIN ),
	'description' => __( 'This is a color control - without alpha channel.', TEXTDOMAIN ),
	'priority'	  => $priority++,
	'section'     => $section,
	'default'     => '#F9F9F9',
] );

// Background 404;

Kirki::add_field('theme',[
	'type'        => 'image',
	'settings'    => 'background404',
	'label'       => __( 'Background 404', TEXTDOMAIN ),
	'description' => __( 'Select an image file for your background 404', TEXTDOMAIN ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => esc_url( THEME_URI . '/assets/images/404.png' ),
]);

Kirki::add_field('theme',array(
	'type'		=> 'custom',
	'settings'	=> 'header_custom_group_title' . $priority++,
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> '<div class="group_title">'. __('Google Font','customizer') . '</div>',
));

// GOOGLE FONT
Kirki::add_field('theme',[
	'type'		=> 'select',
	'settings'	=> 'google_font',
	'label'		=> __('Google Font','customizer'),
	'description' => sprintf(__( '%s', 'customizer' ),'<a href="https://fonts.google.com/">Google Font Library</a>'),
	'priority'	=> $priority++,
	'section'	=> $section,
	'multiple'	=> 1,
	'choices'	=> ColdFire::list_google_fonts(),
	'default'	=> 'Roboto'
]);



// OR CUSTOM
Kirki::add_field('theme',[
	'type'		=> 'text',
	'settings'	=> 'google_font_custom',
	'label'		=> __('Enter Name Google Font','customizer'),
	'priority'	=> $priority++,
	'section'	=> $section,
	'default'	=> '',
]);

Kirki::add_field('theme',array(
	'type'		=> 'custom',
	'settings'	=> 'header_custom_group_title' . $priority++,
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> '<div class="group_title">'. __('Active Attribute Font','customizer') . '</div>',
));


Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'font_regular',
	'label'		=> __('Regular','customizer'),
	'priority'	=> $priority++,
	'section'	=> $section,
	'default'	=> false
]);

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'font_italic',
	'label'		=> __('Italic','customizer'),
	'priority'	=> $priority++,
	'section'	=> $section,
	'default'	=> false
]);

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'font_bold',
	'label'		=> __('Bold','customizer'),
	'priority'	=> $priority++,
	'section'	=> $section,
	'default'	=> false
]);

