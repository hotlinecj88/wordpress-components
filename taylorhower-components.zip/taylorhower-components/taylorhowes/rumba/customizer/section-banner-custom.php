<?php 


$section 	= 'banner-custom';
$priority 	= 0;


Kirki::add_field('theme',[
	'section' 	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'toggle',
	'settings'	=> 'banner_custom_enable',
	'label'		=> __( 'Banner Custom Enable' , TEXTDOMAIN ),
	'default'	=> FALSE,
]);

Kirki::add_field('theme',[
	'section' 	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'text',
	'settings'	=> 'banner_custom_address',
	'label'		=> __( 'Address' , TEXTDOMAIN ),
	'default'	=> ''
]);

Kirki::add_field('theme',[
	'section' 	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'text',
	'settings'	=> 'banner_custom_tel_o',
	'label'		=> __( 'Phone Number 1' , TEXTDOMAIN ),
	'default'	=> ''
]);

Kirki::add_field('theme',[
	'section' 	=> $section,
	'priority'	=> $priority++,
	'type'		=> 'text',
	'settings'	=> 'banner_custom_tel_t',
	'label'		=> __( 'Phone Number 2' , TEXTDOMAIN ),
	'default'	=> ''
]);

Kirki::add_field( 'theme', array(
	'section'     	=> $section,
	'priority'    	=> $priority++,
	'type'        	=> 'image',
	'settings'    	=> 'banner_logo',
	'label'       	=> __( 'Logo Source', TEXTDOMAIN ),
	'description' 	=> __( 'Pick image from gallery or drop and drag .', TEXTDOMAIN ),
	'default'	  	=> ''
));

Kirki::add_field( 'theme', array(
	'section'     	=> $section,
	'priority'    	=> $priority++,
	'type'        	=> 'image',
	'settings'    	=> 'banner_background',
	'label'       	=> __( 'Background Source', TEXTDOMAIN ),
	'description' 	=> __( 'Pick image from gallery or drop and drag .', TEXTDOMAIN ),
	'default'	  	=> ''
));