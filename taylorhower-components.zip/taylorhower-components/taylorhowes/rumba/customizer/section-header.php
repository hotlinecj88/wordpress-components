<?php

$priority = 1;
$section = 'header';


Kirki::add_field('theme',[
	'type'		=> 'select',
	'label'		=> __( 'Header Layout' , TEXTDOMAIN ),
	'section'	=> $section,
	'priority'	=> $priority++,
	'settings'	=> 'header_layout',
	'choices'	=> [
		'01'	=> 'Left - Mid - Right',
		'02'	=> 'Left - Right (1)',
		'03'	=> 'Left(2) - Right',
		'04'	=> 'Left - Right (2)',
		'05'	=> 'No Logo',
	],
	'default'	=> '01'
]);

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'label'		=> __( 'Header Sticky' , TEXTDOMAIN ),
	'section'	=> $section,
	'priority'	=> $priority,
	'settings'	=> 'header_sticky',
	'default'	=> false,
]);



Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'label'		=> __('Header Wide Mode', TEXTDOMAIN ),
	'section'	=> $section,
	'priority'	=> $priority++,
	'settings'	=> 'header_wide_mode',
	'default'	=> true
]);

// SEARCH HEADER

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'settings'	=> 'header_search',
	'label'		=> __('Active Search Tool',TEXTDOMAIN),
	'description'	=> __('Enable search tool in header navigation',TEXTDOMAIN),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> false
]);

// MENU - NAVIGATION ACTIVE

Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'settings'	=> 'header_navigation',
	'label'		=> __('Active Navigation',TEXTDOMAIN),
	'description'	=> __('Enable menu in header',TEXTDOMAIN),
	'section'	=> $section,
	'priority'	=> $priority++,
	'default'	=> true
]);

Kirki::add_field('theme',[
	'type'			=> 'toggle',
	'settings'		=> 'logo_active',
	'label'			=> __('Logo Active',TEXTDOMAIN),
	'description'	=> __('Enable logo in header',TEXTDOMAIN),
	'section'		=> $section,
	'priority'		=> $priority++,
	'default'		=> true
]);

Kirki::add_field( 'theme', array(
	'type'        => 'text',
	'settings'    => 'logo_title',
	'label'       => __( 'Logo title', TEXTDOMAIN ),
	'description' => __( 'Enter the text used as the title attribute.', TEXTDOMAIN ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => get_bloginfo( 'name' ),
));


Kirki::add_field( 'theme', array(
	'type'        => 'text',
	'settings'    => 'logo_alt',
	'label'       => __( 'Logo alt', TEXTDOMAIN ),
	'description' => __( 'Enter the text used as the alt attribute.', TEXTDOMAIN ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => get_bloginfo( 'description' ),
) );

// Custom Title HomePage

Kirki::add_field( 'theme', [
	'type'			=> 'text',
	'settings'		=> 'title_homepage',
	'label'			=> __('Title HomePage' , TEXTDOMAIN ),
	'section'     	=> $section,
	'priority'    	=> $priority ++,
]);



Kirki::add_field( 'theme', array(
	'type'        => 'image',
	'settings'    => 'logo_url',
	'label'       => __( 'Logo src', TEXTDOMAIN ),
	'description' => __( 'Select an image file for your logo.', TEXTDOMAIN ),
	'section'     => $section,
	'priority'    => $priority ++,
	'default'     => esc_url( THEME_URI . '/assets/images/logo/logo.png' ),
));





