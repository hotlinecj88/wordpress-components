<?php 


$section 	= 'footer';
$priority  	= 1;



Kirki::add_field( 'theme', [
	'type'        => 'custom',
	'settings'    => 'my_setting',
	// 'label'       => esc_html__( 'This is the label', 'kirki' ),
	'section'     => $section,
	'default'     => '<div id="label-custom">' . __( 'Footer Access Only', 'customizer' ) . '</div>',
	'priority'    => $priority++,
]);

/**
*	@access FOOTE ACCESS ONLY CHECK BOX
*/

Kirki::add_field('theme',[
	'type'			=> 'checkbox',
	'section'		=> $section,
	'priority'		=> $priority++,
	'label'			=>	__('All','customizer'),
	'description'	=> __('Access for all page and post','customizer'),
	'settings'		=> 'footer_access_all',
	'default'		=> true,
]);

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=>	__('Page','customizer'),
	'settings'	=> 'footer_access_page',
	'default'	=> false,
]);


Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=>	__('Post','customizer'),
	'settings'	=> 'footer_access_single',
	'default'	=> false,
]);

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=>	__('Shop','customizer'),
	'settings'	=> 'footer_access_shop',
	'default'	=> false,
]);


Kirki::add_field('theme',[
	'type'		=> 'toggle',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Enabled Footer Wide ','customizer'),
	'settings'	=> 'footer_wide',
	'default'	=> true
]);

/**
*	@access END FOOTE ACCESS ONLY CHECK BOX
*/


Kirki::add_field('theme',[
	'type'		=> 'select',
	'section'	=> $section,
	'priority'	=> $priority++,
	'label'		=> __('Select Footer','customizer'),
	'settings'	=> 'footer_layout',
	'choices'	=> display_layout_setting(),
	'default'	=> 'none'
]);