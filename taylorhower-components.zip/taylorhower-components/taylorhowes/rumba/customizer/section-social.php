<?php 


$section    = 'social';
$priority   = 1;


Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_fb_active',
	'label'		=> 'Active Facebook Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);

// FACEBOOK
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_fb',
	'label'    => 'Link Facebook',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));


Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_tw_active',
	'label'		=> 'Active Twitter Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);

// TWITTER
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_tw',
	'label'    => 'Link Twitter',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));


Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_ins_active',
	'label'		=> 'Active Instagram Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);
// INSTAGRAM
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_ins',
	'label'    => 'Link Instagram',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_vimeo_active',
	'label'		=> 'Active Vimeo Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);
// VIMEO
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_vimeo',
	'label'    => 'Link Vimeo',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_utube_active',
	'label'		=> 'Active Youtube Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);
// YOUTUBE 
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_utube',
	'label'    => 'Link Youtube',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));

Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_feed_active',
	'label'		=> 'Active Feed Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);
// FEED
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_feed',
	'label'    => 'Link Feed',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));


Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_pin_active',
	'label'		=> 'Active Pinterest Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);
// Pinterest
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_pinterest',
	'label'    => 'Link Pinterest',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));



Kirki::add_field('theme',[
	'type'		=> 'checkbox',
	'settings'	=> 'social_phonenumber_active',
	'label'		=> 'Active Phone Number Link',
	'section'	=> $section,
	'priority' 	=> $priority++,
	'default'	=> false,
]);
// PHONE NUMBER
Kirki::add_field('theme',array(
	'type'     => 'text',
	'settings' => 'social_phonenumber',
	'label'    => 'Phone Number',
	'section'  => $section,
	'default'  => '#',
	'priority' => $priority++,
));