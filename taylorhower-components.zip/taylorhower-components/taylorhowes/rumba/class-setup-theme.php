<?php

/** Tell WordPress to run Construct_Setup() when the 'after_setup_theme' hook is run. */
add_action( 'after_setup_theme', 'Constructor_Setup' );

// class Setup_Theme{

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook. The init hook is too late for some features, such as indicating
 * support post thumbnails.
 *
 * To override twentytwelve_setup() in a child theme, add your own twentytwelve_setup to your child theme's
 * functions.php file.
 *
 * @uses add_theme_support() To add support for post thumbnails and automatic feed links.
 * @uses register_nav_menus() To add support for navigation menus.
 * @uses add_custom_background() To add support for a custom background.
 * @uses add_editor_style() To style the visual editor.
 * @uses load_theme_textdomain() For translation/localization support.
 * @uses add_custom_image_header() To add support for a custom header.
 * @uses register_default_headers() To register the default custom header images provided with the theme.
 * @uses set_post_thumbnail_size() To set a custom post thumbnail size.
 *
 * @access THEME DEVELOPER CONTRUCTOR SETUP
 * @version 1.0
 * @author CJ88
 */
 
if( ! function_exists('Constructor_Setup') ){
function Constructor_Setup() {

	// This theme styles the visual editor with editor-style.css to match the theme style.
	add_editor_style();

	// Post Format support. You can also use the legacy "gallery" or "asides" (note the plural) categories.
	add_theme_support( 'post-formats', array( 'standard', 'gallery' ,'audio' , 'video' ,'quote') );

	// This theme uses post thumbnails
	add_theme_support( 'post-thumbnails' );

	// Add default posts and comments RSS feed links to head
	add_theme_support( 'automatic-feed-links' );
	// META TAG HEAD 
	add_theme_support('title-tag');

	// WOO ACTIVE TEMPLATE
	add_theme_support('woocommerce');
	
	add_theme_support('html5');

	add_image_size( 'post', 830, 470, true );
	add_image_size( 'post-related', 400, 200, true );
	add_image_size( 'post-grid', 330, 200, true );
	add_image_size( 'post-classic',770,400,true);
	add_image_size( 'post-list', 270,200,true);
	add_image_size( 'post-project',270,300,array('left','top'));


	// Make theme available for translation
	// Translations can be filed in the /languages/ directory
	load_theme_textdomain( 'nhadepviet', THEME_DIR . '/languages' );


	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Navigation', TEXTDOMAIN ),
		'secondary' => __( 'Secondary Navigation', TEXTDOMAIN),
		'thirdly'	=> __( 'Third Navigation', TEXTDOMAIN ),
	) );

	// Register sidebar
	register_sidebar(array(
		'name'	=> __('Primary Sidebar',TEXTDOMAIN),
		'id'		=> 'sidebar-primary',
		'description'	=> __('Widgets in this area will be shown on all posts and pages.',TEXTDOMAIN),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="sidebar-title">',
		'after_title'   => '</h2>',
	));

	register_sidebar(array(
		'name'	=> __('Secondary Sidebar',TEXTDOMAIN),
		'id'		=> 'secondary-primary',
		'description'	=> __('Widgets in this area will be shown on all posts and pages.',TEXTDOMAIN),
		'before_widget' => '<div id="%1$s" class="widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3 class="sidebar-title">',
		'after_title'   => '</h2>',
	));

}


function __stylesheet() {

	wp_enqueue_style('bootstrap-css',THEME_URI.'/assets/libs/bootstrap-4.2.1/dist/css/bootstrap.min.css',false);
	wp_enqueue_script('bootstrap-js',THEME_URI.'/assets/libs/bootstrap-4.2.1/dist/js/bootstrap.min.js',array('jquery'),false);
	wp_enqueue_style('font-awesome',THEME_URI . '/assets/libs/fontawesome/css/all.min.css');
   wp_enqueue_style('main-css', THEME_URI.'/assets/scss/styles.css');
   wp_enqueue_script('main-js', THEME_URI.'/assets/js/index.js',array('jquery'),false);
    // SLICK JS
   wp_enqueue_style( 'slick-css', THEME_URI.'/assets/libs/slick-1.8.1/slick/slick.css');
   wp_enqueue_script('slick-js',THEME_URI.'/assets/libs/slick-1.8.1/slick/slick.min.js',array('jquery'));

	// Try jssorSlider
	// wp_enqueue_script( 'jssorSlider ' , THEME_URI .'/assets/libs/jssor-slider/js/jssor.slider.min.js', array('jquery') );
	// SliderJs
	wp_enqueue_script( 'SliderJs ' , THEME_URI .'/assets/libs/SliderJs/source/jquery.slides.min.js' );

	// WAYPOINTS
	// wp_enqueue_script('waypoints-js',THEME_URI.'/assets/libs/waypoints/lib/jquery.waypoints.min.js');
	// wp_enqueue_script('noframeworks',THEME_URI.'/assets/libs/waypoints/lib/noframework.waypoints.min.js');

   // wp_enqueue_script('waypoints-init',THEME_URI.'/assets/libs/waypoints/lib/init.js',array('jquery'),false);

   // UNITE GALLERY
 //   wp_enqueue_style('unitegallery-css',THEME_URI.'/assets/libs/unitegallery/dist/css/unite-gallery.css');
	// wp_enqueue_script('unitegallery-js',THEME_URI.'/assets/libs/unitegallery/dist/js/unitegallery.min.js',array('jquery'),false);

   // css default
   wp_enqueue_style('photoswipe-css',THEME_URI.'/assets/libs/PhotoSwipe/dist/photoswipe.css');
   // skin
   wp_enqueue_style('photoswipe-skin-css',THEME_URI.'/assets/libs/PhotoSwipe/dist/default-skin/default-skin.css');

   wp_enqueue_script('photoswipe-js',THEME_URI.'/assets/libs/PhotoSwipe/dist/photoswipe.min.js',array('jquery'),false);	
   wp_enqueue_script('photoswipe-ui-js',THEME_URI.'/assets/libs/PhotoSwipe/dist/photoswipe-ui-default.min.js',array('jquery'),false);	

   // INIT PHOTO SWIPE
   wp_enqueue_script('photoswipe-init-js',THEME_URI.'/assets/libs/PhotoSwipe/dist/photoswipe.init.js',array('jquery'),false);	

	wp_enqueue_script('counter-js',THEME_URI.'/assets/libs/counter/jquery.counterup.min.js',array('jquery'),false);

	// HINT CSS
	wp_enqueue_style('hint-css',THEME_URI.'/assets/libs/hint.css/css/hint.min.css');
	// ADD MASONRY
	wp_enqueue_script('masonry-js',THEME_URI.'/assets/libs/isotope/dist/isotope.pkgd.min.js',array('jquery'),false);

	// LIGHT GALLERY
	wp_enqueue_style('lightgallery-css',THEME_URI.'/assets/libs/lightGallery-master/dist/css/lightgallery.min.css');

	wp_enqueue_script('lightgallery-js',THEME_URI.'/assets/libs/lightGallery-master/dist/js/lightgallery-all.min.js',array('jquery'),false);

}

add_action( 'wp_enqueue_scripts', '__stylesheet' );


function __stylesheet_custom_admin(){
	wp_enqueue_style('admin-custom-style',THEME_URI.'/assets/scss/customizer/customizer.css');
}

add_action('admin_enqueue_scripts','__stylesheet_custom_admin');

}