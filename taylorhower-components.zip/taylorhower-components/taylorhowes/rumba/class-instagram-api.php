<?php

/**
*	@access INSTAGRAM API
*	@version 1
*	@author CJ
*	@return CLASS INSTANCE
*/


class Ahlu_Instagram_API{

	static $_instance = null;
	public static $_convert;

	// CLASS INSTANCE SAVE MEMORY
	public static function instace(){
		if(self::$_instance === null){
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	public function __construct(){}



	public static function instagram_api($username , $number_item_feed = 6, $type = 'all' , $options = array()){

		if(empty($username)){
			// user demo
			$username = 'unsplash';
		}else{
			$username = trim(strtolower(esc_html($username)));
		}

		$http = 'https://instagram.com/'.$username;

		// $transient_name = "instagram-media-u-" . sanitize_title_with_dashes( $username );

		//cache image save to memory
		// $cached_images = get_transient( $transient_name );

		// if ( false !== $cached_images ) {
		// 	return $cached_images;
		// }

		$remote = wp_remote_get( $http );

		// echo '<pre> Remote http Request : ';
		// print_r( $remote['body'] );
		// echo '</pre>';

		if ( is_wp_error( $remote ) ) {
			return new WP_Error( 'site_down', __( 'Unable to communicate with Instagram.', TEXTDOMAIN ) );
		}

		if ( 200 != wp_remote_retrieve_response_code( $remote ) ) {
			return new WP_Error( 'invalid_response', __( 'Instagram did not return a 200.', TEXTDOMAIN ) );
		}

		$shards      = explode( 'window._sharedData = ', $remote['body'] );
		$insta_json  = explode( ';</script>', $shards[1] );
		$insta_array = json_decode( $insta_json[0], true );

		if ( ! $insta_array ) {
			return new WP_Error( 'bad_json', __( 'Instagram has returned invalid data.', TEXTDOMAIN ) );
		}
		// GET DATA IMAGES
		if ( isset( $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'] ) ) {
			$datas = $insta_array['entry_data']['ProfilePage'][0]['graphql']['user']['edge_owner_to_timeline_media']['edges'];
		} elseif ( isset( $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'] ) ) {
			$datas = $insta_array['entry_data']['TagPage'][0]['graphql']['hashtag']['edge_hashtag_to_media']['edges'];
		} else {
			return new WP_Error( 'bad_json_2', __( 'Instagram has returned invalid data.', TEXTDOMAIN ) );
		}

		if(empty($datas)){
			return new WP_Error( 'bad_array',__( 'Instagram has returned invalid data.', TEXTDOMAIN ) );
		}


		$photoes = array();

		/**
		*	@access TYPE DATA INSTAGRAM
		*/

		switch($type){
			case 'video':'video';break;
			case 'image':'image';break;
			case 'all'	: 'all'; break;
			default:'image';break;
		}

		foreach($datas as $_data){
			$data = $_data['node'];

			// caption
				// if no cap
			$caption	= __('Instagram Image',TEXTDOMAIN);
				// cap -> user
			if(!empty($data['edge_media_to_caption']['edges'][0]['node']['text'])){
				$caption = esc_html($data['edge_media_to_caption']['edges'][0]['node']['text']);
			}

			// remove https
			$data['thumbnail_src'] = preg_replace( '/^https?\:/i', '', $data['thumbnail_src'] );
			$data['display_url']   = preg_replace( '/^https?\:/i', '', $data['display_url'] );


			if(isset($data['thumbnail_resources']) && !empty($data['thumbnail_resources'])){
				foreach($data['thumbnail_resources'] as $k => $data_src){
					switch($data_src['config_width']){
						case 150 : $data['thumbnail'] = $data_src['src']; break;
						case 240 : $data['small']	  = $data_src['src']; break;
						case 320 : $data['medium']	  = $data_src['src']; break;
						case 480 : $data['large']	  = $data_src['src']; break;
						case 640 : $data['extra']	  = $data_src['src']; break;
					}
				}
			}

			$photoes[] = array(
				'caption'	=> esc_html( $caption ),
				'link'		=> trailingslashit('//instagram.com/p/'. $data['shortcode']),
				'time'		=> $data['taken_at_timestamp'],
				'comments'	=> self::countNumber($data['edge_media_to_comment']['count']),
				'likes'		=> self::countNumber($data['edge_liked_by']['count']),
				'type'		=> $type,
				// SRC IMAGE
				'photo'		=> array(
				// SIZE IMAGE
					'thumbnail'	=> $data['thumbnail'],
					'small'		=> $data['small'] ,
					'medium'	=> $data['medium'],
					'large'		=> $data['large'],
					'extra'		=> $data['extra'],
					// 'original'	=> $data['original'],
				)
			);
			//end loop thumbnail resources
		}

		// IF NO IMAGE TO FEED
		if(empty($photoes)){
			return new WP_Error( 'no_images', __( 'Instagram did not return any images.',TEXTDOMAIN ) );
		}

		$photoes = array_slice($photoes,0,$number_item_feed);

		// disable cache

		// set_transient( $transient_name, $photoes, apply_filters( 'null_instagram_cache_time', HOUR_IN_SECONDS * 2 ) );
		
		return $photoes;

	}

	/**
	*	@access FLOOR NUMBER
	*/

	public static function countNumber( $number ) {
		// limit 999 > k < 999999
		if ( $number > 999 && $number <= 999999 ) {
			$result = floor( $number / 1000 ) . ' K';
		} elseif ( $number > 999999 ) {
			$result = floor( $number / 1000000 ) . ' M';
		} else {
			$result = $number;
		}
		return $result;
	}

	/**
	*	@access FEED IMAGE
	*/

	public static function photo($data , $size){

		if(empty($data[$size])){
			unset($data[$size]);
			foreach($data as $k => $photo){

				if($k == 'original' && !empty($photo)){
					return $photo;
				}
				if($k == 'extra' && !empty($photo)){
					return $photo;
				}
				if($k == 'large' && !empty($photo)){
					return $photo;
				}
				if($k == 'medium' && !empty($photo)){
					return $photo;
				}
				if($k == 'small' && !empty($photo)){
					return $photo;
				}
				if($k == 'thumbnail' && !empty($photo)){
					return $photo;
				}
			}
		}else{
			return $data[$size];
		}
	
	}

}

