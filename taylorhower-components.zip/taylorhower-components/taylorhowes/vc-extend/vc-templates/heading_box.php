<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass = $style . $animation;

$title = isset( $title ) ? $title : '';
$content = isset( $content ) ? $content : '';


if( isset( $add_link ) && $add_link != null ){
   $add_link = 1;
}else{
   $add_link = 0;
}

$link = isset( $link ) ? vc_build_link( $link ) : false;

$link_title = isset( $link['title'] ) ? $link['title'] : 'Title'; 
$link_href = isset( $link['href'] ) ? $link['href'] : '#';
$link_rel   = isset( $link['rel'] ) ? $link['rel'] : 'nofollow';
$link_target = isset( $link['target'] ) ? $link['target'] : '_blank';

?>

<div class='shortcode-heading-box <?php echo esc_html( $elclass ); ?>'>
   <h1> <?php echo $title; ?> </h1>
   <p><?php echo $content; ?></p>
   <?php if( $add_link == 1 ){ ?>
      <a href='<?php echo esc_url( $link_href ); ?>' rel='<?php echo $link_rel; ?>' target='<?php echo $link_target; ?>'> 
         <i class='fa fa-caret-right'></i> <?php echo esc_html( $link_title ); ?>
      </a>
   <?php } ?>
</div>