<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';



$type = isset( $type ) ? $type : 'single';

$elclass .= $style . $animation . ' type-'.$type;

$image_size = isset( $image_size ) ? $image_size : 'full';

$single_image = isset( $single_image ) ? wp_get_attachment_image_url( $single_image , $image_size ) : null;

$multiple_image = isset( $multiple_image ) ? vc_param_group_parse_atts( $multiple_image ) : null;


?>

<div class='shortcode-box-image <?php echo esc_attr( $elclass ); ?>'>
   <?php if( $type == 'single' ){ ?>
      <img src='<?php echo $single_image; ?>'>
   <?php } ?>

   <?php if( $type == 'multiple' ){ ?>

   <?php } ?>
</div>