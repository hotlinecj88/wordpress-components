<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;


$items = isset( $items ) ? vc_param_group_parse_atts( $items ) : false;


?>

<div class='shortcode-project-details <?php echo esc_html( $elclass ); ?>'>
   <div class='container-fluid'>

         <?php 

            foreach( $items as $k => $vl ){

               $image      = $vl['image'];
               $caption    = $vl['image_caption'];
               $add_cap    = $vl['add_caption'];
               $image_size = $vl['image_size'];
               if( $add_cap == true ){
                  $col        = 'col-md-12 col-xl-6 col-lg-6';
               }else{
                  $col        = 'col-12';
               }
         ?>
         <div class='row'>

         <div class='<?php echo $col; ?>'>
            <div class='entry-image'>
               <?php echo wp_get_attachment_image( $image , $image_size ); ?>
            </div>
         </div>
         <?php if( $add_cap == true ){ ?>

         <div class='<?php echo $col; ?>'>
            <div class='entry-caption'>
               <blockquote><?php echo $caption; ?></blockquote>
            </div>
         </div>

         <?php } ?>

         </div>
         <!-- End Row -->

         <?php
            }
         ?>
      

   </div>
   <?php 
   // echo '<pre>';
   // print_r( $items ); 
   // echo '</pre>';
   ?>   

</div>