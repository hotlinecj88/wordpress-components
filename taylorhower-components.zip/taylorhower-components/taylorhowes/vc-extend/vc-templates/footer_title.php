<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$footer_title = isset( $footer_title ) ? $footer_title : '';
?>

<div class='shortcode-footer-title <?php echo esc_html( $elclass ); ?>'>
   <span>&#x00040;<?php echo date('Y'); ?></span>
   <h3><?php echo esc_html( $footer_title ); ?></h3>
</div>