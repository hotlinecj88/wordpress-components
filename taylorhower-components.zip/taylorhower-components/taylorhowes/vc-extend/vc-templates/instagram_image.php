<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset( $css_animation ) ? ' '.Helper::add_animation( $css_animation ) : '';

$elclass = $style . $animation;

$title = isset( $title ) ? $title : '';
$link_instagram = isset( $link_instagram ) ? $link_instagram : '#';
$images = isset( $images ) ? explode( ',', $images ) : false;
?>

<div class='shortcode-instagram-image <?php echo esc_attr( $elclass ); ?>'>

   <h2 class='title'>Instagram</h2>
   <div class='link-instagram' >
      <a href='<?php echo esc_url( $link_instagram ) ?>'><?php echo $title; ?></a>
   </div>
   <div class='gallery'>
   <div class='container-fluid'>
   <div class='row'>
   <?php foreach( $images as $k => $vl ){ 
         $src = wp_get_attachment_image_url( $vl , 'medium' );
      ?>
      <div class='col-image'>
         <img src='<?php echo esc_url( $src ); ?>'>
      </div>
   <?php } ?>
   </div>
   </div>
   </div>

</div>
