<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass    = $this->getExtraClass( $el_class );
$style 	   = isset($style) ? ' '.$style : 'style-01';
$animation  = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;
$carousel_control       = isset( $carousel_control ) ? Helper::get_carousel_control( $carousel_control ) : false;
$images                 = isset( $images ) ? explode( ',' , $images ) : null;
$text_center            = isset( $text_center ) ? $text_center : '';
$text_description       = isset( $text_description ) ? $text_description : '';
$id_carousel            = uniqid('sliders-');

// echo '<pre>';
// print_r( $carousel_control );
// echo '</pre>';

?>

<div class='shortcode-slider <?php echo esc_html( $elclass ); ?>'>
   <div class='carousel-outline'>
      <h2><?php echo $text_center; ?></h2>
      <h5><?php echo $text_description; ?></h5>
   </div>

   <div class='carousel-slider'>
      

      <div id='<?php echo $id_carousel; ?>' class='sliders'>
         <?php 
            foreach( $images as $img ){
               $src = wp_get_attachment_image_url( $img , 'large' );
               echo '<img src="'. $src . '">';
            }
         ?>
            <a href='#' class='slidesjs-previous slidesjs-navigation'><i class='icon-chevron-left icon-large'></i></a>
            <a href='#' class='slidesjs-next slidesjs-navigation'><i class='icon-chevron-right icon-large'></i></a>
      </div>

   </div>
</div>

<script type='text/javascript'>
   (function($){
      $(document).ready(function(){
         var $slides = $('#<?php echo $id_carousel; ?>');
         $slides.slidesjs({
            // width: 940,
            // height: 528,
            navigation: {
               active: true,
               effect: "fade"
            },
            play: {
               active: false,
               auto: true,
               interval: 3000,
               // swap: true,
               effect: "fade",
            },
            effect: {
               fade: {
                  speed: 1000,
                  crossfade: true
               }
            }
         });
      });
   })(jQuery);

</script>

