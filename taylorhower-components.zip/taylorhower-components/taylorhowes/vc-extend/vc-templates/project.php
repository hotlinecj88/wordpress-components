<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation( $css_animation ) : '';

$elclass .= $style . $animation;

$post_number = isset( $post_number ) ? $post_number : -1;
$project = new WP_Query([
   'post_type'       => 'project',
   'posts_per_page'  => $post_number,
   'paged'           => ( get_query_var('paged') ) ? get_query_var('paged') : 1,
   'post_status'     => 'publish'
]);


$add_pagination = ( isset( $add_pagination ) && $add_pagination == true ) ? true : false;
?>

<div class='shortcode-project <?php echo esc_html( $elclass ); ?>'>
   <div class='container'>
      <div class='row grid-filter'>
         <?php 
            if( $project->have_posts() ){
               while( $project->have_posts() ){
                  $project->the_post();
                  $tag = get_the_terms( get_the_ID() , 'tag-project' );
                  // class='col-xl-4 col-lg-4 col-md-6 col-12'
                  ?>

                  <div id='article' <?php post_class('col-xl-4 col-lg-4 col-md-6 col-12'); ?> >
                     <div class='entry-post'>

                        <div class='entry-thumbnail'>
                           <?php echo the_post_thumbnail('medium'); ?>
                        </div>

                        <div class='entry-title'>
                           <h2><a href='<?php echo get_permalink( get_the_ID() ); ?>'><?php echo get_the_title(); ?></a></h2>
                        </div>

                        <?php if( !empty( $tag ) ){ ?>
                        <div class='entry-tag'>
                           <?php foreach( $tag as $k => $vl ){ ?>
                           <h4> <?php echo $vl->name; ?></h4>
                           <?php } ?>
                        </div>

                        <?php } ?>
                     </div>
                  </div>

                  <?php
                  
               }
               wp_reset_postdata();
            }

         ?>
      </div>
   </div>
   <?php if( $add_pagination ==  true ){ ?>
   <div class='container'>
      <div class='row'>
         <?php  Helper::paginate_links( $project ); ?>
      </div>
   </div>
   <?php } ?>
</div>

<script type='text/javascript'>
(function($){
   $(document).ready(function(){
      $('.filter-button-group').on( 'click', 'button', function() {
         var filterValue = $(this).attr('data-filter');
         $('.grid-filter').isotope({ filter: filterValue });
         $('.filter-button-group button').removeClass('is-checked');
         $(this).addClass('is-checked');
      });
   });
})(jQuery);
</script>