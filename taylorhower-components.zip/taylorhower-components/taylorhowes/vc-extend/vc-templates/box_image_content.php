<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';




$layout = isset( $layout ) ? 'layout-'.$layout : 'layout-left';

$title = isset( $title ) ? $title : '';
$content = isset( $content ) ? $content : '';
$image = isset( $image ) ? wp_get_attachment_image_url( $image , 'full' ) : get_bloginfo('home') ;

$link = isset( $link ) ? vc_build_link( $link ) : false;

$link_title    = isset( $link['title'] ) ? $link['title'] : '';
$link_href     = isset( $link['href'] ) ? $link['href'] : '#';
$link_rel      = isset( $link['rel'] ) ? $link['rel'] : 'follow';
$link_target   = isset( $link['target'] ) ? $link['target'] : '_blank';


$elclass .= $style . $animation . ' '.$layout;

?>

<div class='shortcode-box-image-content <?php echo esc_attr( $elclass ); ?>'>
   
   <?php 
   // layout left
   if( $layout == 'layout-left' ){ ?>
      <div class='entry-image'> <img src='<?php echo $image; ?>'> </div>
   <?php } ?>

   <div class='entry-wrapper'>
      <h1 class='entry-title'><?php echo esc_html( $title ); ?></h1>
      <p class='entry-content'><?php echo $content; ?></p>
      <?php 
         // display link
      if( isset( $add_link ) && ( $add_link == true || $add_link == 1 ) ){ ?>
         <a class='entry-link' href='<?php echo esc_url( $link_href) ; ?>' rel='<?php echo $link_rel; ?>' target='<?php echo $link_target; ?>'>
            <i class='fa fa-caret-right'></i>
            <span><?php echo esc_html( $link_title );  ?></span>
         </a>

         <?php 
      }
       ?>
   </div>

   <?php if( $layout == 'layout-right' ){ ?>
      <div class='entry-image'> <img src='<?php echo $image; ?>'> </div>
   <?php } ?>
   
</div>
