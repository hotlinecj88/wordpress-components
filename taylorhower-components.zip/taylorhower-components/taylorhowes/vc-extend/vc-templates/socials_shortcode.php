<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$socials_list = isset( $socials_list ) ? vc_param_group_parse_atts( $socials_list ) : null;

// icon_fontawesome

?>

<div class='shortcode-socials <?php echo esc_html( $elclass ); ?>'>
   <div class='wrapper'>
   <span>Follow Us: </span>
   <?php foreach( $socials_list as $k => $v ){ 
         $label   = $v['icon_label'];
         $icon    = $v['icon_fontawesome'];
         $link    = $v['icon_link'];
      ?>
      <a class='hint--top' aria-label='<?php echo $label; ?>' href='<?php echo esc_url( $link ); ?>' rel='follow' target='_blank' >
         <i class='<?php echo $icon; ?>'></i>
      </a>
   <?php } ?>
   </div>
</div>


