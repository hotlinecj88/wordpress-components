<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset( $css_animation ) ? ' '.Helper::add_animation( $css_animation ) : '';

$elclass = $style . $animation;

$username = isset( $username ) ? $username  : '';

$in = Ahlu_Instagram_API::instagram_api( $username );

echo '<pre>';
print_r( $in );
echo '</pre>';
?>

<div class='shortcode-instagram <?php echo esc_attr( $elclass ); ?>'>

</div>
