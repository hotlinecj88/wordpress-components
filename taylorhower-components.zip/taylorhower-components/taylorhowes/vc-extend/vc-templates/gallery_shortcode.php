<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;

$layout = isset( $layout ) ? $layout : 4;
$elclass .= ' gallery-layout-' . $layout;
$images = isset( $images ) ? explode( ',' , $images ) : false;

?>

<div class='shortcode-gallery <?php echo esc_html( $elclass ); ?>'>
   <?php foreach( $images as $src  ){ 
         $img = wp_get_attachment_image_url( $src , 'full');
      ?>
      <img src='<?php echo $img ?>'>
   <?php } ?>
</div>