<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;


$add_navigation = ( isset( $add_navigation ) || $add_navigation == true ) ? true : flase;
$posts_per_page = isset( $posts_per_page ) ? $posts_per_page : 4;

$post = new WP_Query([
   'post_type'       => 'post',
   'posts_per_page'  => $posts_per_page,
   'paged'           => ( get_query_var('paged') ) ? get_query_var('paged') : 1,
   'post_status'     => 'publish'

]);

$class_post = 'col-12 col-md-6 col-lg-4 col-xl-4 post-blog';

?>

<div class='shortcode-get-posts <?php echo esc_attr( $elclass ); ?>'>
   <div class='container'>
      <div class='row'>
         <?php 
            if( $post->have_posts() ){
               while( $post->have_posts() ){
                  $post->the_post();
                  $tag = get_the_terms( get_the_ID() , 'post_tag' );
                  ?>

                  <div <?php post_class( $class_post ); ?>>
                     <div class='entry-thumbnail'>
                        <?php echo the_post_thumbnail(); ?>
                     </div>
                     <div class='entry-title'>
                        <a href='<?php echo get_permalink(); ?>'>
                           <h1><?php echo get_the_title(); ?></h1>
                        </a>
                        <?php if( !empty( $tag ) ){ ?>
                        <h4>
                           <?php foreach( $tag as $k => $vl){ ?>
                              <span><?php echo $vl->name; ?></span>
                           <?php } ?>
                        </h4>
                        <?php } ?>
                     </div>

                  </div>

                  <?php 
               }
               wp_reset_postdata();
            }

          ?>
      </div>
   </div>

   <?php if( $add_navigation ==  true ){ ?>
   <div class='container'>
      <div class='row'>
         <?php  Helper::paginate_links( $post ); ?>
      </div>
   </div>
   <?php } ?>

</div>