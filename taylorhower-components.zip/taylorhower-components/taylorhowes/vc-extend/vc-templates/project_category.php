<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($animation) ? ' '.Helper::add_animation($animation) : '';

$elclass .= $style . $animation;


$categories = isset( $categories ) ? Helper::explode_categories( explode(',',$categories) ) : null;

krsort( $categories );
?>

<div class='shortcode-project-category <?php echo esc_html( $elclass ); ?>'>
   <div class='wrapper button-group filter-button-group js-radio-button-group'>
      <?php 
         foreach( $categories as $k => $vl ){
            $name = $vl['name'];
            $slug = $vl['slug'];
            $filter = '.category-project-'.$slug;
            ?>
               <button class='button <?php echo ($slug == 'view-all') ? 'is-checked' : '';  ?>' data-filter='<?php echo $filter; ?>'> 
                  <h3> <?php echo $name; ?> </h3> 
               </button>
            <?php
         }
      ?>
   </div>
</div>