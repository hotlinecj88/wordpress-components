<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$items = isset( $items ) ? vc_param_group_parse_atts( $items ) : null;
?>

<div class='shortcode-box-contact-details <?php echo esc_attr( $elclass ); ?>'>
   <?php  if( !empty( $items ) ){
      foreach( $items as $k => $item ){   
   ?>
      <div class='entry-details'>
         <h2><?php echo $item['title']; ?></h2>
         <p><?php echo $item['content']; ?></p>
      </div>
   <?php 
      }
   }

   ?>
</div>