<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass = $this->getExtraClass( $el_class );

$style 	= isset($style) ? ' '.$style : 'style-01';

$animation = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

/*
   frst name
   surname
   email
      box select
   telephone
   message

*/

$title = isset( $title ) ? $title : '';
$content = isset( $content ) ? $content : '';
$image = isset( $image ) ? wp_get_attachment_image_url( $image , 'full') : '';
$form_id = isset( $form_id ) ? $form_id : '';

?>

<div class='shortcode-box-contact <?php echo esc_attr( $elclass ); ?>'>
   <div class='container'>
      <div class='row'>
         <div class='col-12 col-md-8 col-xl-8 col-lg-8 mx-auto'>
            <div class='entry-title'><?php echo $title; ?></div>
         </div>
      </div>
      <div class='row'>
         <div class='col-12 col-md-10 col-xl-9 col-lg-9 mx-auto'>
            <div class='entry-image'><img src='<?php echo $image; ?>'></div>
         </div>
      </div>
      <div class='row'>
         <div class='col-12 col-md-8 col-xl-8 col-lg-8 mx-auto'>
            <div class='entry-content'><?php echo $content; ?></div>
         </div>
      </div>
      <div class='row'>
         <div class='col-12 col-md-8 col-xl-8 col-lg-8 mx-auto'>
            <div class='entry-form'>
               <?php echo do_shortcode('[contact-form-7 id="'.$form_id.'"]'); ?>
            </div>
         </div>
      </div>

      </div>
   </div>
</div>

