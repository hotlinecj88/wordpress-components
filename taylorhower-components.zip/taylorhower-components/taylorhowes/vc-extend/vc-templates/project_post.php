<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

$elclass    = $this->getExtraClass( $el_class );
$style 	   = isset($style) ? ' '.$style : 'style-01';
$animation  = isset($css_animation) ? ' '.Helper::add_animation($css_animation) : '';

$elclass .= $style . $animation;

$class_post = 'col-content col-12 col-md-12 col-xl-6 col-md-6';

$posts_per_page = isset( $posts_per_page ) ? $posts_per_page : 4;


$post = new WP_Query([
   'post_type'       => 'project',
   'posts_per_page'  => $posts_per_page,
   'paged'           => ( get_query_var('paged') ) ? get_query_var('paged') : 1,
   'post_status'     => 'publish'
]);
$add_pagination = ( isset( $add_pagination ) && $add_pagination == true ) ? true : false;

?>

<div class='shortcode-project-post <?php echo esc_attr( $elclass ); ?>'>
   <div class='container-fluid'>
         <?php 
         // loop 
         // reverse
         $reverse = 0;
         if( $post->have_posts() ){ 
            while( $post->have_posts() ){
               $reverse++;

               $post->the_post();
               ?>
               <div class='row row-content <?php echo ( ($reverse + 1) % 2 == 0 ) ? "even" : "oods"; ?>'>
                  <div class='<?php echo $class_post; ?>'>
                     <a class='entry-thumbnail' href='#'>
                        <?php echo the_post_thumbnail( ); ?>
                     </a>
                  </div>
                  <div class='<?php echo $class_post; ?>'>
                     <div class='entry-wrapper'>
                        <div class='entry-post'>
                           <div class='entry-title'>
                              <h1><?php echo get_the_title(); ?></h1>
                           </div>
                           <div class='entry-content'>
                              <?php echo get_the_excerpt( get_the_ID() ); ?>
                           </div>
                           <div class='entry-link'>
                              <i class='fa fa-caret-right'></i>
                              <a href='<?php echo get_the_permalink( get_the_ID() ); ?>'>View Project</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <?php 
            }
         } 
         ?>
      
   </div>

   <?php if( $add_pagination ==  true ){ ?>
   <div class='container'>
      <div class='row'>
         <?php  Helper::paginate_links( ); ?>
      </div>
   </div>
   <?php } ?>

</div>