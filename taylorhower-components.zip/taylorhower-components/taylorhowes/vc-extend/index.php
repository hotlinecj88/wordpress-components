<?php


// add_action( 'init', 'ahlu_vc_extend', 10 );

// add_action( 'vc_before_init', 'ahlu_vc_before_init' );
// add_action( 'vc_after_init', 'ahlu_set_use_theme_fonts_default', 'load' );

// function ahlu_vc_before_init() {vc_set_as_theme();}


// function ahlu_vc_extend() {

	// $map = THEME_DIR . '/vc-extend/vc-maps/';
	// $param = THEME_DIR . '/vc-extend/vc-params/';

	// include_once $param . 'number.php';

	// Load params
	// include_once DIR_DIR . '/vc-extend/vc-params/gradient/gradient.php';
	// include_once DIR_DIR . '/vc-extend/vc-params/image-radio.php';
	// include_once DIR_DIR . '/vc-extend/vc-params/toggle.php';
	// include_once DIR_DIR . '/vc-extend/vc-params/chosen.php';

	
	// include_once DIR_DIR . '/vc-extend/vc-params/ajax-search.php';
	// include_once DIR_DIR . '/vc-extend/vc-params/carousel-control.php';
	// include_once DIR_DIR . '/vc-extend/vc-params/datetime-picker.php';

	// LOAD VC MAPS
	// include_once $map . 'ahlu_box.php';
	// include_once $map . 'ahlu_rev_slider.php';
	// include_once $map . 'ahlu_post.php';
	

	// if ( class_exists( 'WooCommerce' ) ) {
		
	// }
// }



// function ahlu_set_use_theme_fonts_default() {
// 	//Get current values stored in the color param in "Call to Action" element
// 	$param_use_theme_fonts = WPBMap::getParam( 'vc_custom_heading', 'use_theme_fonts' );
// 	//Append new value to the 'value' array
// 	$param_use_theme_fonts['std'] = 'yes';
// 	//Finally "mutate" param with new values
// 	vc_update_shortcode_param( 'vc_custom_heading', $param_use_theme_fonts );
// }
