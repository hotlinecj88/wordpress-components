<?php
/*
 * Example
		array(
			'type'            => 'carousel-control',
			'heading'         => esc_html__( 'Carousel control', 'miimo' ),
			'param_name'      => 'carousel_control',
			'save_always'     => true,
			'admin_label'     => true,
			'slide_to_show'   => array(
				'readonly' => false,
				'value'    => '4',
			),
			'slide_to_scroll' => array(
				'readonly' => false,
				'value'    => '4',
			),
			'auto_play'       => array(
				'readonly' => false,
				'value'    => 'true',
			),
			'infinite'        => array(
				'readonly' => false,
				'value'    => 'true',
			),
			'show_dots'       => array(
				'readonly' => false,
				'value'    => 'false',
			),
			'show_arrows'     => array(
				'readonly' => true,
				'value'    => 'false',
			),
		),
*/
if ( ! class_exists( 'Param_Carousel_Control' ) ) {
	class Param_Carousel_Control {
		function __construct() {
			if ( class_exists( 'WpbakeryShortcodeParams' ) ) {
				WpbakeryShortcodeParams::addField( 'carousel-control', array(
					$this,'param_carousel_control'
				));
			}
		}

		function param_carousel_control( $settings, $value ) {
			$param_name = isset( $settings['param_name'] ) ? $settings['param_name'] : '';

			if ( $value != '' ) {
				$value_items = explode( ',', $value );
			}

			$setting_slide_to_show   = isset( $settings['slide_to_show']['value'] ) ? $settings['slide_to_show']['value'] : 1;
			$setting_slide_to_scroll = isset( $settings['slide_to_scroll']['value'] ) ? $settings['slide_to_scroll']['value'] : 1;
			$setting_infinite        = isset( $settings['infinite']['value'] ) ? $settings['infinite']['value'] : 'true';
			$setting_auto_play       = isset( $settings['auto_play']['value'] ) ? $settings['auto_play']['value'] : 'true';
			$setting_show_dots       = isset( $settings['show_dots']['value'] ) ? $settings['show_dots']['value'] : 'true';
			$setting_show_arrows     = isset( $settings['show_arrows']['value'] ) ? $settings['show_arrows']['value'] : 'true';
			$setting_variable_width  = isset( $settings['variable_width']['value'] ) ? $settings['variable_width']['value'] : 'false';
			$setting_center_mode     = isset( $settings['center_mode']['value'] ) ? $settings['center_mode']['value'] : 'false';

			$slide_to_show   = isset( $value_items[0] ) && $value_items[0] != 'null' ? $value_items[0] : $setting_slide_to_show;
			$slide_to_scroll = isset( $value_items[1] ) && $value_items[1] != 'null' ? $value_items[1] : $setting_slide_to_scroll;
			$auto_play       = isset( $value_items[2] ) && $value_items[2] != 'null' ? $value_items[2] : $setting_auto_play;
			$infinite        = isset( $value_items[3] ) && $value_items[3] != 'null' ? $value_items[3] : $setting_infinite;
			$show_dots       = isset( $value_items[4] ) && $value_items[4] != 'null' ? $value_items[4] : $setting_show_dots;
			$show_arrows     = isset( $value_items[5] ) && $value_items[5] != 'null' ? $value_items[5] : $setting_show_arrows;
			$variable_width  = isset( $value_items[6] ) && $value_items[6] != 'null' ? $value_items[6] : $setting_variable_width;
			$center_mode     = isset( $value_items[7] ) && $value_items[7] != 'null' ? $value_items[7] : $setting_center_mode;

			$new_value = $slide_to_show . ',' . $slide_to_scroll . ',' . $auto_play . ',' . $infinite . ',' . $show_dots . ',' . $show_arrows . ',' . $variable_width . ',' . $center_mode;

			$uid = uniqid( 'carousel-control-' );

			$output = '<div class="carousel-control" id="' . esc_attr( $uid ) . '">';
			$output .= '<input type="hidden" name="' . $param_name . '" value="' . $new_value . '" class="carousel-control-val wpb_vc_param_value" />';
			$output .= '<table>';
			$output .= '<tr><td style="width: 120px; padding-left: 30px">' . esc_html__( 'Slide to show', 'seopro' ) . '</td><td><input type="number" class="carousel-control-onchange" value="' . $slide_to_show . '" min="1" max="20" ' . ( isset( $settings['slide_to_show']['readonly'] ) && $settings['slide_to_show']['readonly'] ? 'readonly' : '' ) . '/></td>';
			$output .= '<td style="width: 120px; padding-left: 30px">' . esc_html__( 'Slide to scroll', 'seopro' ) . '</td><td><input type="number" class="carousel-control-onchange" value="' . $slide_to_scroll . '" min="1" max="20" ' . ( isset( $settings['slide_to_scroll']['readonly'] ) && $settings['slide_to_scroll']['readonly'] ? 'readonly' : '' ) . '/></td></tr>';
			$output .= '<tr><td style="width: 120px; padding-left: 30px">' . esc_html__( 'Auto play', 'seopro' ) . '</td><td><select class="carousel-control-onchange" ' . ( isset( $settings['auto_play']['readonly'] ) && $settings['auto_play']['readonly'] ? 'disabled' : '' ) . '><option value="true" ' . ( $auto_play == 'true' ? 'selected' : '' ) . '>Yes</option><option value="false" ' . ( $auto_play == 'false' ? 'selected' : '' ) . '>No</option></select></td>';
			$output .= '<td style="width: 120px; padding-left: 30px">' . esc_html__( 'Infinite', 'seopro' ) . '</td><td><select class="carousel-control-onchange" ' . ( isset( $settings['infinite']['readonly'] ) && $settings['infinite']['readonly'] ? 'disabled' : '' ) . '><option value="true" ' . ( $infinite == 'true' ? 'selected' : '' ) . '>Yes</option><option value="false" ' . ( $infinite == 'false' ? 'selected' : '' ) . '>No</option></select></td></tr>';
			$output .= '<tr><td style="width: 120px; padding-left: 30px">' . esc_html__( 'Show dots', 'seopro' ) . '</td><td><select class="carousel-control-onchange" ' . ( isset( $settings['show_dots']['readonly'] ) && $settings['show_dots']['readonly'] ? 'disabled' : '' ) . '><option value="true" ' . ( $show_dots == 'true' ? 'selected' : '' ) . '>Yes</option><option value="false" ' . ( $show_dots == 'false' ? 'selected' : '' ) . '>No</option></select></td>';
			$output .= '<td style="width: 120px; padding-left: 30px">' . esc_html__( 'Show arrows', 'seopro' ) . '</td><td><select class="carousel-control-onchange" ' . ( isset( $settings['show_arrows']['readonly'] ) && $settings['show_arrows']['readonly'] ? 'disabled' : '' ) . '><option value="true" ' . ( $show_arrows == 'true' ? 'selected' : '' ) . '>Yes</option><option value="false" ' . ( $show_arrows == 'false' ? 'selected' : '' ) . '>No</option></select></td></tr>';
			$output .= '<tr><td style="width: 120px; padding-left: 30px">' . esc_html__( 'Variable width', 'seopro' ) . '</td><td><select class="carousel-control-onchange" ' . ( isset( $settings['variable_width']['readonly'] ) && $settings['variable_width']['readonly'] ? 'disabled' : '' ) . '><option value="true" ' . ( $variable_width == 'true' ? 'selected' : '' ) . '>Yes</option><option value="false" ' . ( $variable_width == 'false' ? 'selected' : '' ) . '>No</option></select></td>';
			$output .= '<td style="width: 120px; padding-left: 30px">' . esc_html__( 'Center mode', 'seopro' ) . '</td><td><select class="carousel-control-onchange" ' . ( isset( $settings['center_mode']['readonly'] ) && $settings['center_mode']['readonly'] ? 'disabled' : '' ) . '><option value="true" ' . ( $center_mode == 'true' ? 'selected' : '' ) . '>Yes</option><option value="false" ' . ( $center_mode == 'false' ? 'selected' : '' ) . '>No</option></select></td></tr>';
			$output .= '</table>';
			$output .= '</div>';
			$output .= '<script>
							jQuery("#' . $uid . ' .carousel-control-onchange").on("change", function(){
							var carousel_control_val = "";
							var i = 0;
							jQuery("#' . $uid . ' .carousel-control-onchange").each(function(){
								if(i > 0) {
									if(jQuery(this).val() != "") {
										carousel_control_val += ","+jQuery(this).val();
									} else {
										carousel_control_val += ",null";
									}
								} else {
									if(jQuery(this).val() != "") {
										carousel_control_val += jQuery(this).val();
									} else {
										carousel_control_val += "null";
									}
								}
								i++;
							});
							jQuery("#' . $uid . ' .carousel-control-val").val(carousel_control_val);
							});
						</script>';

			return $output;
		}

	}
}

if ( class_exists( 'Param_Carousel_Control' ) ) {
	$Param_Carousel_Control = new Param_Carousel_Control();
}
