<?php 

class WPBakeryShortCode_Box_Image_Content extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'box_image_content',
   'name'   => 'Box Image Content',
   'params' => [
      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      // layout
      [
         'type'         => 'dropdown',
         'heading'      => 'Layout',
         'param_name'   => 'layout',
         'value'        => [
            'Left'      =>    'left',
            'Right'     =>    'right'
         ]
      ],

      // image
      [
         'type'         => 'attach_image',
         'heading'      => 'Image',
         'param_name'   => 'image',
      ],

      // box content
      [
         'type'         => 'textfield',
         'heading'      => 'Box Title',
         'param_name'   => 'title',
      ],

      [
         'type'         => 'textarea',
         'heading'      => 'Box content',
         'param_name'   => 'content',
      ],

      [
         'type'         => 'checkbox',
         'heading'      => 'Add Link?',
         'param_name'   => 'add_link'
      ],

      [
         'type'         => 'vc_link',
         'heading'      => 'Link To',
         'param_name'   => 'link',
         'dependency'   => [ 'element' => 'add_link' , 'value' => ['true'] ],
      ]


   ]
]);