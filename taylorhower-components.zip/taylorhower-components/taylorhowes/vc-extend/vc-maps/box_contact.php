<?php 

class WPBakeryShortCode_Box_Contact extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'box_contact',
   'name'   => 'Box Contact',
   'params' => [
      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      [
         'type'         => 'textfield',
         'heading'      => 'Title',
         'param_name'   => 'title',
      ],

      [
         // apply use html
         'type'         => 'textarea',
         'heading'      => 'Content',
         'param_name'   => 'content',
      ],

      [
         'type'         => 'attach_image',
         'heading'      => 'Image',
         'param_name'   => 'image'
      ],

      Helper::get_cf7_forms(),


   ]
]);