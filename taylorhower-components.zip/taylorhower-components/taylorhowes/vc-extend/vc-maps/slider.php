<?php 

class WPBakeryShortCode_Slider extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'slider',
   'name'   => 'Slider - Carousel',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      Helper::get_param('carousel-control'),

      [
         'type'         => 'textarea',
         'heading'      => 'Text Center',
         'param_name'   => 'text_center',
      ],

      [
         'type'         => 'textarea',
         'heading'      => 'Text Description',
         'param_name'   => 'text_description',
      ],

      [
         'type'         => 'attach_images',
         'heading'      => 'Pick multiple image from library',
         'param_name'   => 'images'
      ]


   ]
]);