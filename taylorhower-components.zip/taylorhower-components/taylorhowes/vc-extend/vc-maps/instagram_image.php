<?php 

class WPBakeryShortCode_Instagram_Image extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'instagram_image',
   'name'   => 'Instagram Image',
   'params' => [
      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02',
         ]
      ],

      [
         'type'         => 'textfield',
         'heading'      => 'Title',
         'param_name'   => 'title'
      ],

      [
         'type'         => 'textfield',
         'heading'      => 'Link Instagram',
         'param_name'   => 'link_instagram',
      ],

      [
         'type'         => 'attach_images',
         'heading'      => 'Pick image from gallery',
         'param_name'   => 'images'
      ]
      
   ]
]);