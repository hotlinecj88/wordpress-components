<?php 

class WPBakeryShortCode_Get_Posts extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'get_posts',
   'name'   => 'Get Posts',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02',
         ]
      ],

      [
         'type'         => 'number',
         'heading'      => 'Posts Per Page',
         'param_name'   => 'posts_per_page',
         'min'          => 8,
         'max'          => 50,
         'std'          => 8
      ],

      [
         'type'         => 'checkbox',
         'heading'      => 'Add Navigation?',
         'param_name'   => 'add_navigation',
      ]

   ]
]);