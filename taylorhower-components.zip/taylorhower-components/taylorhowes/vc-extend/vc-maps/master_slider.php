<?php 

class WPBakeryShortCode_Master_Slider extends WPBakeryShortCode{
}

build_vcmap([
   'name'   => 'Master Slider',
   'base'   => 'master_slider',
   'params' => [

       [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      Helper::get_master_sliders(),

   ]
]);