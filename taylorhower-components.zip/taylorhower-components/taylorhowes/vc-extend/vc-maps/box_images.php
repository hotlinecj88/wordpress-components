<?php 

class WPBakeryShortCode_Box_Images extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'box_images',
   'name'   => 'Box Image',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],


      // single - multiple
      [
         'type'         => 'dropdown',
         'heading'      => 'Type',
         'param_name'   => 'type',
         'value'        => [
            'Single'    => 'single',
            'Multiple'  => 'multiple'
         ],
      ],


      // 4 single

      [
         'type'         => 'attach_image',
         'heading'      => 'Single Image',
         'param_name'   => 'single_image',
         'dependency'   => [ 'element'   => 'type' , 'value' => 'single' ]
      ],
      // image size
      [
         'type'         => 'dropdown',
         'heading'      => 'Image Size',
         'param_name'   => 'image_size',
         'value'        => [
            'Full Size' => 'full',
            'Large'     => 'large',
            'Medium'    => 'medium',
            'Thumbnail' => 'thumbnail'
         ],
         'default'      => 'full',
         'dependency'   => [ 'element'   => 'type' , 'value' => 'single' ]
      ],

      // 4 multiple

      [
         'type'         => 'param_group',
         'heading'      => 'Image with Cap',
         'param_name'   => 'multiple_image',
         'dependency'   => [ 'element'   => 'type' , 'value' => 'multiple' ],
         'params'       => [
            
            [
               'type'         => 'attach_image',
               'heading'      => 'Image',
               'param_name'   => 'image',
            ],
            [
               'type'         => 'textfield',
               'heading'      => 'Caption',
               'param_name'   => 'caption'
            ]
            
         ]
      ]

   ]

]);