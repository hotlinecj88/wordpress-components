<?php 

class WPBakeryShortCode_Project_Post extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'project_post',
   'name'   => 'Project Post',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02',
         ]
      ],

      [
         'type'         => 'number',
         'heading'      => 'Posts Per Page',
         'param_name'   => 'posts_per_page',
         'std'          => 4,
         'min'          => 4,
         'max'          => 100,
      ],

      [
         'type'         => 'checkbox',
         'heading'      => 'Add Pagination?',
         'param_name'   => 'add_pagination',
         'default'      => false
      ]
      
   ]
]);