<?php 

class WPBakeryShortCode_Footer_Title extends WPBakeryShortCode{

}

build_vcmap([
   'base'   => 'footer_title',
   'name'   => 'Footer Title',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      [
         'type'         => 'textfield',
         'heading'      => 'Footer Title',
         'param_name'   => 'footer_title'
      ]
   ]
]);