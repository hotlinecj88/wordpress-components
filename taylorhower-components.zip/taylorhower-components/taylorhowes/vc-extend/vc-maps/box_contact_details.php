<?php 

class WPBakeryShortCode_Box_Contact_Details extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'box_contact_details',
   'name'   => 'Contact - Details',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      // box content
      [
         'type'         => 'param_group',
         'heading'      => 'Contents',
         'param_name'   => 'items',
         'params'       => [
            [
               'type'         => 'textfield',
               'heading'      => 'Box Title',
               'param_name'   => 'title',
               'admin_label'  => true
            ],

            [
               'type'         => 'textarea',
               'heading'      => 'Box content',
               'param_name'   => 'content',
            ],
         ]

      ],
   

   ]
]);