<?php 

class WPBakeryShortCode_Gallery_Shortcode extends WPBakeryShortCode{}

build_vcmap([

   'name'   => 'Gallery',
   'base'   => 'gallery_shortcode',
   'params' => [
      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      [
         'type'         => 'dropdown',
         'heading'      => 'Layout',
         'param_name'   => 'layout',
         'value'        => [
            '4 Column'  => 4,
            '6 Column'  => 6,
            '8 Column'  => 8
         ]
      ],

      [
         'type'         => 'attach_images',
         'heading'      => 'Pick image from library',
         'param_name'   => 'images',
      ]


   ]
]);