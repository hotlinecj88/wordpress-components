<?php 


class WPBakeryShortCode_Project extends WPBakeryShortCode{

}

build_vcmap([
   'base'   => 'project',
   'name'   => 'Project - Portfolio',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02',
         ]
      ],

      [
         'type'         => 'number',
         'heading'      => 'Post Number?',
         'min'          => 8,
         'max'          => 100,
         'std'          => 8,
         'param_name'   => 'post_number'
      ],

      [
         'type'         => 'checkbox',
         'heading'      => 'Add Pagination?',
         'param_name'   => 'add_pagination',
         'default'      => false
      ]

   ]
]);