<?php 

class WPBakeryShortCode_Socials_Shortcode extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'socials_shortcode',
   'name'   => 'Socials',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      [
         'type'         => 'param_group',
         'heading'      => 'Socials List',
         'param_name'   => 'socials_list',
         'params'       => [
            [
               'type'         => 'textfield',
               'heading'      => 'Icon Label',
               'param_name'   => 'icon_label',
               'admin_label'  => true
            ],
            [
               'type'         => 'textfield',
               'heading'      => 'Icon Link',
               'param_name'   => 'icon_link',
               'default'      => '#'
            ],
            Helper::get_font( 'fontawesome' , false )
         ]
      ]

   ]

]);