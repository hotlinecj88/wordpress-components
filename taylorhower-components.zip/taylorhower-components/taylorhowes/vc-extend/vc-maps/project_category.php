<?php 

class WPBakeryShortCode_Project_Category extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'project_category',
   'name'   => 'Display Project Category',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02',
         ]
      ],

      // display category from helper class
      Helper::get_post_categories( 'checkbox' , 'category-project' ),

      // Helper::get_post_categories( 'dropdown' , 'category-project' , 'cat-name' , 'Category Primary' ),

   ]
]);