<?php 

class WPBakeryShortCode_Instagram_Api extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'instagram_api',
   'name'   => 'Instagram',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02',
         ]
      ],

      [
         'type'         => 'textfield',
         'heading'      => 'Username',
         'param_name'   => 'username'
      ]

   ]
]);