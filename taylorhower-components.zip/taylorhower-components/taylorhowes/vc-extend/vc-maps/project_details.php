<?php 

class WPBakeryShortCode_Project_Details extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'project_details',
   'name'   => 'Project Details',
   'params' => [

      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      // Items ->>
      [
         'type'         => 'param_group',
         'heading'      => 'Contents',
         'param_name'   => 'items',
         'params'       => [
            // first style - image with caption

            [
               'type'         => 'attach_image',
               'heading'      => 'Image',
               'param_name'   => 'image',
            ],

            [
               'type'         => 'dropdown',
               'heading'      => 'Image Size',
               'param_name'   => 'image_size',
               'value'        => [
                  'Full'      => 'full',
                  'Large'     => 'large',
                  'Medium'    => 'medium',
                  'Thumbnail' => 'thumbnail'
               ],
               'default'      => 'large'

            ],

            [
               'type'         => 'checkbox',
               'heading'      => 'Add Caption?',
               'param_name'   => 'add_caption',
            ],

            [
               'type'         => 'textarea',
               'heading'      => 'Image Caption',
               'param_name'   => 'image_caption',
               'dependency'   => [
                  'element'   => 'add_caption' , 'value' => ['true']
               ]
            ]

         ]
      ]

   ]
]);