<?php 

/**
 * @access Heading Box
 */


class WPBakeryShortCode_Heading_Box extends WPBakeryShortCode{}

build_vcmap([
   'base'   => 'heading_box',
   'name'   => 'Heading Box',
   'params' => [
      
      [
         'type'         => 'dropdown',
         'heading'      => 'Style',
         'param_name'   => 'style',
         'value'        => [
            'Style 01'  => 'style-01',
            'Style 02'  => 'style-02'
         ]
      ],

      [
         'type'         => 'textfield',
         'heading'      => 'Title',
         'param_name'   => 'title',
         'admin_label'  => true
      ],

      [
         'type'         => 'textarea',
         'heading'      => 'Content',
         'param_name'   => 'content'
      ],

      [
         'type'         => 'checkbox',
         'heading'      => 'Add Link?',
         'param_name'   => 'add_link',
      ],


      [
         'type'         => 'vc_link',
         'heading'      => 'Link To',
         'param_name'   => 'link',
         'dependency'   => [
            'element'   => 'add_link' , 'value' => ['true']
         ]
      ],



   ]
]);