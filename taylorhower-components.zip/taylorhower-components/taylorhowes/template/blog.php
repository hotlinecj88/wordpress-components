<?php 

/*
	TEMPLATE NAME: Casting Call
*/

get_header();


?>


<?php 

get_footer();
?>