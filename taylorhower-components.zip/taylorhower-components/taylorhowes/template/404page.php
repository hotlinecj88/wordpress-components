<?php 

/* TEMPLATE NAME: 404Page */

get_header();

get_footer();