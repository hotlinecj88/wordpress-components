<?php

if ( post_password_required() ) {
	return;
}

// change comment form fields order
add_filter( 'comment_form_fields', 'remove_fields_form_comment' );
function remove_fields_form_comment( $fields ) {
	// $comment_field = $fields['comment'];
	// $author_field = $fields['author'];
	// $email_field = $fields['email'];
	// $url_field = $fields['url'];

	// unset( $fields['comment'] );
	unset( $fields['author'] );
	unset( $fields['email'] );
	unset( $fields['url'] );
	
	return $fields;
}

?>

<div id='ahlu-comments' class='ahlu-comments'>
	<h3 class='comments-form-title'><?php echo __('Đăng Ký Nhận Job',TEXTDOMAIN); ?></h3>
	<p>Cần Điền Thông Tin Cụ Thể : Tên - Số Điện Thoại - Email</p>
	<?php comment_form(); ?>
</div>