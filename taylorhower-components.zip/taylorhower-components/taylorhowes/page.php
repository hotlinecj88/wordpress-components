<?php

$page_layout = CustomSetting::setting('page_layout');
$page_wide   = CustomSetting::setting('page_wide');

get_header();


// $class_container = $page_wide == 1 ? 'container-fluid' : 'container';

$class_container ='container';

// $class_inner_page_wrapper = $page_layout == 'no-sidebar' ? 'col-12' : 'col-9';

$class_inner_page_wrapper = 'col-12 col-xl-12 col-lg-12';

// no sidebar
if ( CustomSetting::get_customizer_active( get_the_ID() , 'sidebar' ) == 0 ){
	$class_inner_page_wrapper = 'col-12';
}


?>


<div class='page-content <?php echo esc_attr( $class_container ); ?>'>

	<div class='row'>


	<?php

		// get_sidebar();


		if(have_posts()){
			while(have_posts()){
				the_post();
				?>
				<div class='<?php echo esc_attr( $class_inner_page_wrapper ); ?>'>
					
				<div id='page-<?php the_ID(); ?>' class='page-wrapper '>

					<div class='page-content-inner'>
						<?php the_content(); ?>
					</div>

				</div>

				</div>
				<?php
			}
			// RESET POST
		}
	?>
</div>

</div>


<?php
	get_footer();
?>
