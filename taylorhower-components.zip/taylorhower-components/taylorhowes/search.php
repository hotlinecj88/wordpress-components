<?php 

get_header();

if(isset($_GET['s'])){
	$search_title = $_GET['s'];
}else{
	$search_title = 'Không tìm thấy kết quả nào !';
}
?>
	
<div id='page-search' class='page-search'>
	<div class='container'>
		<div class='row'>

			<!-- 
<div class='col-12 col-md-12 col-xl-8 col-lg-10 mx-auto'>
				<div class='search-title'>
					<h1>
						<span><?php //echo __('Tìm kết quả cho :',TEXTDOMAIN); ?></span>
						<span><?php //echo esc_html($search_title); ?></span>
					</h1>
				</div>	
			</div>
 -->
			
			<div class='col-12 col-md-12 col-xl-8 col-lg-10 mx-auto'>
				<?php if(have_posts()){ while(have_posts()){the_post(); ?>
					<a class='row entry-post <?php echo (has_post_thumbnail()) ? "entry-post-thumbnail" : "entry-post-nothumbnail"; ?>' href='<?php the_permalink(); ?>'>
						<?php if(has_post_thumbnail()){ ?>
							<div class='col-12 col-md-4 col-left'>
								<div class='entry-thumbnail' style='background-image:url("<?php echo get_the_post_thumbnail_url(get_the_ID(),'large'); ?>");'>
									<?php //the_post_thumbnail('medium');?>
								</div>
							</div>
						<?php } ?>
						
						<div class='col-12  col-right <?php echo (has_post_thumbnail()) ? "col-md-8" : ""; ?>'>

							<div class='entry-content'>
								<div class='entry-title'><?php the_title(); ?></div>
								<time>Post in <?php echo get_post_time('d F Y'); ?></time>
							</div>

						</div>
					</a>
				<?php }}?>
			</div>

			<div class='col-12 col-md-12 col-xl-8 col-lg-10 mx-auto'>
				<?php Helper::ahlu_pagination();?>
			</div>
			
	</div>	
</div>

<?php 
get_footer();